var require = meteorInstall({"server":{"collections.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/collections.js                                                                           //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
// Create a Collection to store data
RequestStudies = new Meteor.Collection('requestStudies'); // Remove all previous data

RequestStudies.remove({});
const testDataFiles = ['sample.json', 'testDICOMs.json', 'CRStudy.json', 'CTStudy.json', 'DXStudy.json', 'MGStudy.json', 'MRStudy.json', 'PTCTStudy.json', 'RFStudy.json'];
testDataFiles.forEach(file => {
  if (file.indexOf('.json') === -1) {
    return;
  } // Read JSON files and save the content in the database


  const jsonData = Assets.getText(`testData/${file}`);
  const data = JSON.parse(jsonData);
  RequestStudies.insert(data);
});
/////////////////////////////////////////////////////////////////////////////////////////////////////

}},"routes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// routes.js                                                                                       //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Router;
module.watch(require("meteor/iron:router"), {
  Router(v) {
    Router = v;
  }

}, 1);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 2);

if (Meteor.isClient) {
  // Disconnect from the Meteor Server since we don't need it
  OHIF.log.info('Disconnecting from the Meteor server');
  Meteor.disconnect();
  Router.configure({
    loadingTemplate: 'loading'
  });
  Router.onBeforeAction('loading');
  Router.route('/:id?', {
    onRun: function () {
      console.warn('onRun'); // Retrieve the query from the URL the user has entered

      const query = this.params.query;
      const id = this.params.id;

      if (!id && !query.url) {
        console.log('No URL was specified. Use ?url=${yourURL}');
        return;
      }

      const next = this.next;
      const idUrl = `/api/${id}`;
      const url = query.url || idUrl; // Define a request to the server to retrieve the study data
      // as JSON, given a URL that was in the Route

      const oReq = new XMLHttpRequest(); // Add event listeners for request failure

      oReq.addEventListener('error', () => {
        OHIF.log.warn('An error occurred while retrieving the JSON data');
        next();
      }); // When the JSON has been returned, parse it into a JavaScript Object
      // and render the OHIF Viewer with this data

      oReq.addEventListener('load', () => {
        // Parse the response content
        // https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/responseText
        if (!oReq.responseText) {
          OHIF.log.warn('Response was undefined');
          return;
        }

        OHIF.log.info(JSON.stringify(oReq.responseText, null, 2));
        this.data = JSON.parse(oReq.responseText);
        next();
      }); // Open the Request to the server for the JSON data
      // In this case we have a server-side route called /api/
      // which responds to GET requests with the study data

      OHIF.log.info(`Sending Request to: ${url}`);
      oReq.open('GET', url);
      oReq.setRequestHeader('Accept', 'application/json'); // Fire the request to the server

      oReq.send();
    },

    action() {
      // Render the Viewer with this data
      this.render('standaloneViewer', {
        data: () => this.data
      });
    }

  });
} // This is ONLY for demo purposes.


if (Meteor.isServer) {
  // You can test this with:
  // curl -v -H "Content-Type: application/json" -X GET 'http://localhost:3000/getData/testId'
  //
  // Or by going to:
  // http://localhost:3000/api/testId
  Router.route('/api/:id', {
    where: 'server'
  }).get(function () {
    // "this" is the RouteController instance.
    // "this.response" is the Connect response object
    // "this.request" is the Connect request object
    const id = this.params.id; // Find the relevant study data from the Collection given the ID

    const data = RequestStudies.findOne({
      transactionId: id
    }); // Set the response headers to return JSON to any server

    this.response.setHeader('Content-Type', 'application/json');
    this.response.setHeader('Access-Control-Allow-Origin', '*');
    this.response.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept'); // Change the response text depending on the available study data

    if (!data) {
      this.response.write('No Data Found');
    } else {
      // Stringify the JavaScript object to JSON for the response
      this.response.write(JSON.stringify(data));
    } // Finalize the response


    this.response.end();
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/collections.js");
require("/routes.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9yb3V0ZXMuanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIlJlcXVlc3RTdHVkaWVzIiwiQ29sbGVjdGlvbiIsInJlbW92ZSIsInRlc3REYXRhRmlsZXMiLCJmb3JFYWNoIiwiZmlsZSIsImluZGV4T2YiLCJqc29uRGF0YSIsIkFzc2V0cyIsImdldFRleHQiLCJkYXRhIiwiSlNPTiIsInBhcnNlIiwiaW5zZXJ0IiwiUm91dGVyIiwiT0hJRiIsImlzQ2xpZW50IiwibG9nIiwiaW5mbyIsImRpc2Nvbm5lY3QiLCJjb25maWd1cmUiLCJsb2FkaW5nVGVtcGxhdGUiLCJvbkJlZm9yZUFjdGlvbiIsInJvdXRlIiwib25SdW4iLCJjb25zb2xlIiwid2FybiIsInF1ZXJ5IiwicGFyYW1zIiwiaWQiLCJ1cmwiLCJuZXh0IiwiaWRVcmwiLCJvUmVxIiwiWE1MSHR0cFJlcXVlc3QiLCJhZGRFdmVudExpc3RlbmVyIiwicmVzcG9uc2VUZXh0Iiwic3RyaW5naWZ5Iiwib3BlbiIsInNldFJlcXVlc3RIZWFkZXIiLCJzZW5kIiwiYWN0aW9uIiwicmVuZGVyIiwiaXNTZXJ2ZXIiLCJ3aGVyZSIsImdldCIsImZpbmRPbmUiLCJ0cmFuc2FjdGlvbklkIiwicmVzcG9uc2UiLCJzZXRIZWFkZXIiLCJ3cml0ZSIsImVuZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsU0FBT0ksQ0FBUCxFQUFTO0FBQUNKLGFBQU9JLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFFWDtBQUNBQyxpQkFBaUIsSUFBSUwsT0FBT00sVUFBWCxDQUFzQixnQkFBdEIsQ0FBakIsQyxDQUVBOztBQUNBRCxlQUFlRSxNQUFmLENBQXNCLEVBQXRCO0FBRUEsTUFBTUMsZ0JBQWdCLENBQ2xCLGFBRGtCLEVBRWxCLGlCQUZrQixFQUdsQixjQUhrQixFQUlsQixjQUprQixFQUtsQixjQUxrQixFQU1sQixjQU5rQixFQU9sQixjQVBrQixFQVFsQixnQkFSa0IsRUFTbEIsY0FUa0IsQ0FBdEI7QUFZQUEsY0FBY0MsT0FBZCxDQUFzQkMsUUFBUTtBQUMxQixNQUFJQSxLQUFLQyxPQUFMLENBQWEsT0FBYixNQUEwQixDQUFDLENBQS9CLEVBQWtDO0FBQzlCO0FBQ0gsR0FIeUIsQ0FLMUI7OztBQUNBLFFBQU1DLFdBQVdDLE9BQU9DLE9BQVAsQ0FBZ0IsWUFBV0osSUFBSyxFQUFoQyxDQUFqQjtBQUNBLFFBQU1LLE9BQU9DLEtBQUtDLEtBQUwsQ0FBV0wsUUFBWCxDQUFiO0FBRUFQLGlCQUFlYSxNQUFmLENBQXNCSCxJQUF0QjtBQUNILENBVkQsRTs7Ozs7Ozs7Ozs7QUNwQkEsSUFBSWYsTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNILFNBQU9JLENBQVAsRUFBUztBQUFDSixhQUFPSSxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUllLE1BQUo7QUFBV2xCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUNnQixTQUFPZixDQUFQLEVBQVM7QUFBQ2UsYUFBT2YsQ0FBUDtBQUFTOztBQUFwQixDQUEzQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJZ0IsSUFBSjtBQUFTbkIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ2lCLE9BQUtoQixDQUFMLEVBQU87QUFBQ2dCLFdBQUtoQixDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEOztBQUlsSyxJQUFJSixPQUFPcUIsUUFBWCxFQUFxQjtBQUNqQjtBQUNBRCxPQUFLRSxHQUFMLENBQVNDLElBQVQsQ0FBYyxzQ0FBZDtBQUNBdkIsU0FBT3dCLFVBQVA7QUFFQUwsU0FBT00sU0FBUCxDQUFpQjtBQUNiQyxxQkFBaUI7QUFESixHQUFqQjtBQUlBUCxTQUFPUSxjQUFQLENBQXNCLFNBQXRCO0FBRUFSLFNBQU9TLEtBQVAsQ0FBYSxPQUFiLEVBQXNCO0FBQ2xCQyxXQUFPLFlBQVc7QUFDZEMsY0FBUUMsSUFBUixDQUFhLE9BQWIsRUFEYyxDQUVkOztBQUNBLFlBQU1DLFFBQVEsS0FBS0MsTUFBTCxDQUFZRCxLQUExQjtBQUNBLFlBQU1FLEtBQUssS0FBS0QsTUFBTCxDQUFZQyxFQUF2Qjs7QUFFQSxVQUFJLENBQUNBLEVBQUQsSUFBTyxDQUFDRixNQUFNRyxHQUFsQixFQUF1QjtBQUNuQkwsZ0JBQVFSLEdBQVIsQ0FBWSwyQ0FBWjtBQUNBO0FBQ0g7O0FBRUQsWUFBTWMsT0FBTyxLQUFLQSxJQUFsQjtBQUNBLFlBQU1DLFFBQVMsUUFBT0gsRUFBRyxFQUF6QjtBQUNBLFlBQU1DLE1BQU1ILE1BQU1HLEdBQU4sSUFBYUUsS0FBekIsQ0FiYyxDQWVkO0FBQ0E7O0FBQ0EsWUFBTUMsT0FBTyxJQUFJQyxjQUFKLEVBQWIsQ0FqQmMsQ0FtQmQ7O0FBQ0FELFdBQUtFLGdCQUFMLENBQXNCLE9BQXRCLEVBQStCLE1BQU07QUFDakNwQixhQUFLRSxHQUFMLENBQVNTLElBQVQsQ0FBYyxrREFBZDtBQUNBSztBQUNILE9BSEQsRUFwQmMsQ0F5QmQ7QUFDQTs7QUFDQUUsV0FBS0UsZ0JBQUwsQ0FBc0IsTUFBdEIsRUFBOEIsTUFBTTtBQUNoQztBQUNBO0FBQ0EsWUFBSSxDQUFDRixLQUFLRyxZQUFWLEVBQXdCO0FBQ3BCckIsZUFBS0UsR0FBTCxDQUFTUyxJQUFULENBQWMsd0JBQWQ7QUFDQTtBQUNIOztBQUVEWCxhQUFLRSxHQUFMLENBQVNDLElBQVQsQ0FBY1AsS0FBSzBCLFNBQUwsQ0FBZUosS0FBS0csWUFBcEIsRUFBa0MsSUFBbEMsRUFBd0MsQ0FBeEMsQ0FBZDtBQUNBLGFBQUsxQixJQUFMLEdBQVlDLEtBQUtDLEtBQUwsQ0FBV3FCLEtBQUtHLFlBQWhCLENBQVo7QUFFQUw7QUFDSCxPQVpELEVBM0JjLENBeUNkO0FBQ0E7QUFDQTs7QUFDQWhCLFdBQUtFLEdBQUwsQ0FBU0MsSUFBVCxDQUFlLHVCQUFzQlksR0FBSSxFQUF6QztBQUNBRyxXQUFLSyxJQUFMLENBQVUsS0FBVixFQUFpQlIsR0FBakI7QUFDQUcsV0FBS00sZ0JBQUwsQ0FBc0IsUUFBdEIsRUFBZ0Msa0JBQWhDLEVBOUNjLENBZ0RkOztBQUNBTixXQUFLTyxJQUFMO0FBQ0gsS0FuRGlCOztBQW9EbEJDLGFBQVM7QUFDTDtBQUNBLFdBQUtDLE1BQUwsQ0FBWSxrQkFBWixFQUFnQztBQUM1QmhDLGNBQU0sTUFBTSxLQUFLQTtBQURXLE9BQWhDO0FBR0g7O0FBekRpQixHQUF0QjtBQTJESCxDLENBRUQ7OztBQUNBLElBQUlmLE9BQU9nRCxRQUFYLEVBQXFCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTdCLFNBQU9TLEtBQVAsQ0FBYSxVQUFiLEVBQXlCO0FBQUVxQixXQUFPO0FBQVQsR0FBekIsRUFBOENDLEdBQTlDLENBQWtELFlBQVc7QUFDekQ7QUFDQTtBQUNBO0FBQ0EsVUFBTWhCLEtBQUssS0FBS0QsTUFBTCxDQUFZQyxFQUF2QixDQUp5RCxDQU16RDs7QUFDQSxVQUFNbkIsT0FBT1YsZUFBZThDLE9BQWYsQ0FBdUI7QUFBRUMscUJBQWVsQjtBQUFqQixLQUF2QixDQUFiLENBUHlELENBU3pEOztBQUNBLFNBQUttQixRQUFMLENBQWNDLFNBQWQsQ0FBd0IsY0FBeEIsRUFBd0Msa0JBQXhDO0FBQ0EsU0FBS0QsUUFBTCxDQUFjQyxTQUFkLENBQXdCLDZCQUF4QixFQUF1RCxHQUF2RDtBQUNBLFNBQUtELFFBQUwsQ0FBY0MsU0FBZCxDQUF3Qiw4QkFBeEIsRUFBd0QsZ0RBQXhELEVBWnlELENBY3pEOztBQUNBLFFBQUksQ0FBQ3ZDLElBQUwsRUFBVztBQUNQLFdBQUtzQyxRQUFMLENBQWNFLEtBQWQsQ0FBb0IsZUFBcEI7QUFDSCxLQUZELE1BRU87QUFDSDtBQUNBLFdBQUtGLFFBQUwsQ0FBY0UsS0FBZCxDQUFvQnZDLEtBQUswQixTQUFMLENBQWUzQixJQUFmLENBQXBCO0FBQ0gsS0FwQndELENBc0J6RDs7O0FBQ0EsU0FBS3NDLFFBQUwsQ0FBY0csR0FBZDtBQUNILEdBeEJEO0FBeUJILEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG4vLyBDcmVhdGUgYSBDb2xsZWN0aW9uIHRvIHN0b3JlIGRhdGFcblJlcXVlc3RTdHVkaWVzID0gbmV3IE1ldGVvci5Db2xsZWN0aW9uKCdyZXF1ZXN0U3R1ZGllcycpO1xuXG4vLyBSZW1vdmUgYWxsIHByZXZpb3VzIGRhdGFcblJlcXVlc3RTdHVkaWVzLnJlbW92ZSh7fSk7XG5cbmNvbnN0IHRlc3REYXRhRmlsZXMgPSBbXG4gICAgJ3NhbXBsZS5qc29uJyxcbiAgICAndGVzdERJQ09Ncy5qc29uJyxcbiAgICAnQ1JTdHVkeS5qc29uJyxcbiAgICAnQ1RTdHVkeS5qc29uJyxcbiAgICAnRFhTdHVkeS5qc29uJyxcbiAgICAnTUdTdHVkeS5qc29uJyxcbiAgICAnTVJTdHVkeS5qc29uJyxcbiAgICAnUFRDVFN0dWR5Lmpzb24nLFxuICAgICdSRlN0dWR5Lmpzb24nXG5dO1xuXG50ZXN0RGF0YUZpbGVzLmZvckVhY2goZmlsZSA9PiB7XG4gICAgaWYgKGZpbGUuaW5kZXhPZignLmpzb24nKSA9PT0gLTEpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFJlYWQgSlNPTiBmaWxlcyBhbmQgc2F2ZSB0aGUgY29udGVudCBpbiB0aGUgZGF0YWJhc2VcbiAgICBjb25zdCBqc29uRGF0YSA9IEFzc2V0cy5nZXRUZXh0KGB0ZXN0RGF0YS8ke2ZpbGV9YCk7XG4gICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UoanNvbkRhdGEpO1xuXG4gICAgUmVxdWVzdFN0dWRpZXMuaW5zZXJ0KGRhdGEpO1xufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ21ldGVvci9pcm9uOnJvdXRlcic7XG5pbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG5cbmlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgICAvLyBEaXNjb25uZWN0IGZyb20gdGhlIE1ldGVvciBTZXJ2ZXIgc2luY2Ugd2UgZG9uJ3QgbmVlZCBpdFxuICAgIE9ISUYubG9nLmluZm8oJ0Rpc2Nvbm5lY3RpbmcgZnJvbSB0aGUgTWV0ZW9yIHNlcnZlcicpO1xuICAgIE1ldGVvci5kaXNjb25uZWN0KCk7XG5cbiAgICBSb3V0ZXIuY29uZmlndXJlKHtcbiAgICAgICAgbG9hZGluZ1RlbXBsYXRlOiAnbG9hZGluZydcbiAgICB9KTtcblxuICAgIFJvdXRlci5vbkJlZm9yZUFjdGlvbignbG9hZGluZycpO1xuXG4gICAgUm91dGVyLnJvdXRlKCcvOmlkPycsIHtcbiAgICAgICAgb25SdW46IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdvblJ1bicpO1xuICAgICAgICAgICAgLy8gUmV0cmlldmUgdGhlIHF1ZXJ5IGZyb20gdGhlIFVSTCB0aGUgdXNlciBoYXMgZW50ZXJlZFxuICAgICAgICAgICAgY29uc3QgcXVlcnkgPSB0aGlzLnBhcmFtcy5xdWVyeTtcbiAgICAgICAgICAgIGNvbnN0IGlkID0gdGhpcy5wYXJhbXMuaWQ7XG5cbiAgICAgICAgICAgIGlmICghaWQgJiYgIXF1ZXJ5LnVybCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdObyBVUkwgd2FzIHNwZWNpZmllZC4gVXNlID91cmw9JHt5b3VyVVJMfScpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgbmV4dCA9IHRoaXMubmV4dDtcbiAgICAgICAgICAgIGNvbnN0IGlkVXJsID0gYC9hcGkvJHtpZH1gO1xuICAgICAgICAgICAgY29uc3QgdXJsID0gcXVlcnkudXJsIHx8IGlkVXJsO1xuXG4gICAgICAgICAgICAvLyBEZWZpbmUgYSByZXF1ZXN0IHRvIHRoZSBzZXJ2ZXIgdG8gcmV0cmlldmUgdGhlIHN0dWR5IGRhdGFcbiAgICAgICAgICAgIC8vIGFzIEpTT04sIGdpdmVuIGEgVVJMIHRoYXQgd2FzIGluIHRoZSBSb3V0ZVxuICAgICAgICAgICAgY29uc3Qgb1JlcSA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuXG4gICAgICAgICAgICAvLyBBZGQgZXZlbnQgbGlzdGVuZXJzIGZvciByZXF1ZXN0IGZhaWx1cmVcbiAgICAgICAgICAgIG9SZXEuYWRkRXZlbnRMaXN0ZW5lcignZXJyb3InLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgT0hJRi5sb2cud2FybignQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgcmV0cmlldmluZyB0aGUgSlNPTiBkYXRhJyk7XG4gICAgICAgICAgICAgICAgbmV4dCgpO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vIFdoZW4gdGhlIEpTT04gaGFzIGJlZW4gcmV0dXJuZWQsIHBhcnNlIGl0IGludG8gYSBKYXZhU2NyaXB0IE9iamVjdFxuICAgICAgICAgICAgLy8gYW5kIHJlbmRlciB0aGUgT0hJRiBWaWV3ZXIgd2l0aCB0aGlzIGRhdGFcbiAgICAgICAgICAgIG9SZXEuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsICgpID0+IHtcbiAgICAgICAgICAgICAgICAvLyBQYXJzZSB0aGUgcmVzcG9uc2UgY29udGVudFxuICAgICAgICAgICAgICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9YTUxIdHRwUmVxdWVzdC9yZXNwb25zZVRleHRcbiAgICAgICAgICAgICAgICBpZiAoIW9SZXEucmVzcG9uc2VUZXh0KSB7XG4gICAgICAgICAgICAgICAgICAgIE9ISUYubG9nLndhcm4oJ1Jlc3BvbnNlIHdhcyB1bmRlZmluZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIE9ISUYubG9nLmluZm8oSlNPTi5zdHJpbmdpZnkob1JlcS5yZXNwb25zZVRleHQsIG51bGwsIDIpKTtcbiAgICAgICAgICAgICAgICB0aGlzLmRhdGEgPSBKU09OLnBhcnNlKG9SZXEucmVzcG9uc2VUZXh0KTtcblxuICAgICAgICAgICAgICAgIG5leHQoKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyBPcGVuIHRoZSBSZXF1ZXN0IHRvIHRoZSBzZXJ2ZXIgZm9yIHRoZSBKU09OIGRhdGFcbiAgICAgICAgICAgIC8vIEluIHRoaXMgY2FzZSB3ZSBoYXZlIGEgc2VydmVyLXNpZGUgcm91dGUgY2FsbGVkIC9hcGkvXG4gICAgICAgICAgICAvLyB3aGljaCByZXNwb25kcyB0byBHRVQgcmVxdWVzdHMgd2l0aCB0aGUgc3R1ZHkgZGF0YVxuICAgICAgICAgICAgT0hJRi5sb2cuaW5mbyhgU2VuZGluZyBSZXF1ZXN0IHRvOiAke3VybH1gKTtcbiAgICAgICAgICAgIG9SZXEub3BlbignR0VUJywgdXJsKTtcbiAgICAgICAgICAgIG9SZXEuc2V0UmVxdWVzdEhlYWRlcignQWNjZXB0JywgJ2FwcGxpY2F0aW9uL2pzb24nKVxuXG4gICAgICAgICAgICAvLyBGaXJlIHRoZSByZXF1ZXN0IHRvIHRoZSBzZXJ2ZXJcbiAgICAgICAgICAgIG9SZXEuc2VuZCgpO1xuICAgICAgICB9LFxuICAgICAgICBhY3Rpb24oKSB7XG4gICAgICAgICAgICAvLyBSZW5kZXIgdGhlIFZpZXdlciB3aXRoIHRoaXMgZGF0YVxuICAgICAgICAgICAgdGhpcy5yZW5kZXIoJ3N0YW5kYWxvbmVWaWV3ZXInLCB7XG4gICAgICAgICAgICAgICAgZGF0YTogKCkgPT4gdGhpcy5kYXRhXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG4vLyBUaGlzIGlzIE9OTFkgZm9yIGRlbW8gcHVycG9zZXMuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgLy8gWW91IGNhbiB0ZXN0IHRoaXMgd2l0aDpcbiAgICAvLyBjdXJsIC12IC1IIFwiQ29udGVudC1UeXBlOiBhcHBsaWNhdGlvbi9qc29uXCIgLVggR0VUICdodHRwOi8vbG9jYWxob3N0OjMwMDAvZ2V0RGF0YS90ZXN0SWQnXG4gICAgLy9cbiAgICAvLyBPciBieSBnb2luZyB0bzpcbiAgICAvLyBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Rlc3RJZFxuXG4gICAgUm91dGVyLnJvdXRlKCcvYXBpLzppZCcsIHsgd2hlcmU6ICdzZXJ2ZXInIH0pLmdldChmdW5jdGlvbigpIHtcbiAgICAgICAgLy8gXCJ0aGlzXCIgaXMgdGhlIFJvdXRlQ29udHJvbGxlciBpbnN0YW5jZS5cbiAgICAgICAgLy8gXCJ0aGlzLnJlc3BvbnNlXCIgaXMgdGhlIENvbm5lY3QgcmVzcG9uc2Ugb2JqZWN0XG4gICAgICAgIC8vIFwidGhpcy5yZXF1ZXN0XCIgaXMgdGhlIENvbm5lY3QgcmVxdWVzdCBvYmplY3RcbiAgICAgICAgY29uc3QgaWQgPSB0aGlzLnBhcmFtcy5pZDtcblxuICAgICAgICAvLyBGaW5kIHRoZSByZWxldmFudCBzdHVkeSBkYXRhIGZyb20gdGhlIENvbGxlY3Rpb24gZ2l2ZW4gdGhlIElEXG4gICAgICAgIGNvbnN0IGRhdGEgPSBSZXF1ZXN0U3R1ZGllcy5maW5kT25lKHsgdHJhbnNhY3Rpb25JZDogaWQgfSk7XG5cbiAgICAgICAgLy8gU2V0IHRoZSByZXNwb25zZSBoZWFkZXJzIHRvIHJldHVybiBKU09OIHRvIGFueSBzZXJ2ZXJcbiAgICAgICAgdGhpcy5yZXNwb25zZS5zZXRIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi9qc29uJyk7XG4gICAgICAgIHRoaXMucmVzcG9uc2Uuc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nLCAnKicpO1xuICAgICAgICB0aGlzLnJlc3BvbnNlLnNldEhlYWRlcignQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycycsICdPcmlnaW4sIFgtUmVxdWVzdGVkLVdpdGgsIENvbnRlbnQtVHlwZSwgQWNjZXB0Jyk7XG5cbiAgICAgICAgLy8gQ2hhbmdlIHRoZSByZXNwb25zZSB0ZXh0IGRlcGVuZGluZyBvbiB0aGUgYXZhaWxhYmxlIHN0dWR5IGRhdGFcbiAgICAgICAgaWYgKCFkYXRhKSB7XG4gICAgICAgICAgICB0aGlzLnJlc3BvbnNlLndyaXRlKCdObyBEYXRhIEZvdW5kJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBTdHJpbmdpZnkgdGhlIEphdmFTY3JpcHQgb2JqZWN0IHRvIEpTT04gZm9yIHRoZSByZXNwb25zZVxuICAgICAgICAgICAgdGhpcy5yZXNwb25zZS53cml0ZShKU09OLnN0cmluZ2lmeShkYXRhKSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBGaW5hbGl6ZSB0aGUgcmVzcG9uc2VcbiAgICAgICAgdGhpcy5yZXNwb25zZS5lbmQoKTtcbiAgICB9KTtcbn1cbiJdfQ==
