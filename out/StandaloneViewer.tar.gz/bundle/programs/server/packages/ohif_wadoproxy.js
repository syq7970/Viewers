(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Iron = Package['iron:core'].Iron;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var WADOProxy, Settings;

var require = meteorInstall({"node_modules":{"meteor":{"ohif:wadoproxy":{"server":{"namespace.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/ohif_wadoproxy/server/namespace.js                                                                  //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
WADOProxy = {};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"initialize.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/ohif_wadoproxy/server/initialize.js                                                                 //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);
Settings = Object.assign({
  uri: OHIF.utils.absoluteUrl("/__wado_proxy"),
  enabled: true
}, Meteor.settings && Meteor.settings.proxy ? Meteor.settings.proxy : {});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/ohif_wadoproxy/server/routes.js                                                                     //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Router;
module.watch(require("meteor/iron:router"), {
  Router(v) {
    Router = v;
  }

}, 1);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 2);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 3);
let Servers;
module.watch(require("meteor/ohif:servers/both/collections"), {
  Servers(v) {
    Servers = v;
  }

}, 4);

const url = require('url');

const http = require('http');

const https = require('https');

const now = require('performance-now');

const doAuth = Meteor.users.find().count() ? true : false;

const authenticateUser = request => {
  // Only allow logged-in users to access this route
  const userId = request.headers['x-user-id'];
  const loginToken = request.headers['x-auth-token'];

  if (!userId || !loginToken) {
    return;
  }

  const hashedToken = Accounts._hashLoginToken(loginToken);

  return Meteor.users.findOne({
    _id: userId,
    'services.resume.loginTokens.hashedToken': hashedToken
  });
}; // Setup a Route using Iron Router to avoid Cross-origin resource sharing
// (CORS) errors. We only handle this route on the Server.


Router.route(Settings.uri.replace(OHIF.utils.absoluteUrl(), ''), function () {
  const request = this.request;
  const response = this.response;
  const params = this.params;
  let start = now();
  let user;

  if (doAuth) {
    user = authenticateUser(request);

    if (!user) {
      response.writeHead(401);
      response.end('Error: You must be logged in to perform this action.\n');
      return;
    }
  }

  let end = now();
  const authenticationTime = end - start;
  start = now();
  const server = Servers.findOne(params.query.serverId);

  if (!server) {
    response.writeHead(500);
    response.end('Error: No Server with the specified Server ID was found.\n');
    return;
  }

  const requestOpt = server.requestOptions; // If no Web Access to DICOM Objects (WADO) Service URL is provided
  // return an error for the request.

  const wadoUrl = params.query.url;

  if (!wadoUrl) {
    response.writeHead(500);
    response.end('Error: No WADO URL was provided.\n');
    return;
  }

  if (requestOpt.logRequests) {
    console.log(request.url);
  }

  start = now();

  if (requestOpt.logTiming) {
    console.time(request.url);
  } // Use Node's URL parse to decode the query URL


  const parsed = url.parse(wadoUrl); // Create an object to hold the information required
  // for the request to the PACS.

  let options = {
    headers: {},
    method: request.method,
    hostname: parsed.hostname,
    path: parsed.path
  };
  let requester;

  if (parsed.protocol === 'https:') {
    requester = https.request;
    const allowUnauthorizedAgent = new https.Agent({
      rejectUnauthorized: false
    });
    options.agent = allowUnauthorizedAgent;
  } else {
    requester = http.request;
  }

  if (parsed.port) {
    options.port = parsed.port;
  }

  Object.keys(request.headers).forEach(entry => {
    const value = request.headers[entry];

    if (entry) {
      options.headers[entry] = value;
    }
  }); // Retrieve the authorization user:password string for the PACS,
  // if one is required, and include it in the request to the PACS.

  if (requestOpt.auth) {
    options.auth = requestOpt.auth;
  }

  end = now();
  const prepRequestTime = end - start; // Use Node's HTTP API to send a request to the PACS

  const proxyRequest = requester(options, proxyResponse => {
    // When we receive data from the PACS, stream it as the
    // response to the original request.
    // console.log(`Got response: ${proxyResponse.statusCode}`);
    end = now();
    const proxyReqTime = end - start;
    const totalProxyTime = authenticationTime + prepRequestTime + proxyReqTime;
    const serverTimingHeaders = `
            auth=${authenticationTime}; "Authenticate User",
            prep-req=${prepRequestTime}; "Prepare Request Headers",
            proxy-req=${proxyReqTime}; "Request to WADO URI",
            total-proxy=${totalProxyTime}; "Total",
        `.replace(/\n/g, '');
    proxyResponse.headers['Server-Timing'] = serverTimingHeaders;
    response.writeHead(proxyResponse.statusCode, proxyResponse.headers);

    if (requestOpt.logTiming) {
      console.timeEnd(request.url);
    }

    return proxyResponse.pipe(response, {
      end: true
    });
  }); // If our request to the PACS fails, log the error message

  proxyRequest.on('error', error => {
    end = now();
    const proxyReqTime = end - start;
    const totalProxyTime = authenticationTime + prepRequestTime + proxyReqTime;
    console.timeEnd(request.url);
    const serverTimingHeaders = {
      'Server-Timing': `
                auth=${authenticationTime}; "Authenticate User",
                prep-req=${prepRequestTime}; "Prepare Request Headers",
                proxy-req=${proxyReqTime}; "Request to WADO URI",
                total-proxy=${totalProxyTime}; "Total",
            `.replace(/\n/g, '')
    };
    response.writeHead(500, serverTimingHeaders);
    response.end(`Error: Problem with request to PACS: ${error.message}\n`);
  }); // Stream the original request information into the request
  // to the PACS

  request.pipe(proxyRequest);
}, {
  where: 'server'
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"convertURL.js":function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/ohif_wadoproxy/server/convertURL.js                                                                 //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
const querystring = require("querystring");

WADOProxy.convertURL = (url, serverConfiguration) => {
  if (!Settings.enabled) {
    return url;
  }

  if (!url) {
    return null;
  }

  const serverId = serverConfiguration._id;
  const query = querystring.stringify({
    url,
    serverId
  });
  return `${Settings.uri}?${query}`;
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"node_modules":{"performance-now":{"package.json":function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// node_modules/meteor/ohif_wadoproxy/node_modules/performance-now/package.json                                 //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
exports.name = "performance-now";
exports.version = "2.1.0";
exports.main = "lib/performance-now.js";

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"performance-now.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// node_modules/meteor/ohif_wadoproxy/node_modules/performance-now/lib/performance-now.js                       //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
// Generated by CoffeeScript 1.12.2
(function() {
  var getNanoSeconds, hrtime, loadTime, moduleLoadTime, nodeLoadTime, upTime;

  if ((typeof performance !== "undefined" && performance !== null) && performance.now) {
    module.exports = function() {
      return performance.now();
    };
  } else if ((typeof process !== "undefined" && process !== null) && process.hrtime) {
    module.exports = function() {
      return (getNanoSeconds() - nodeLoadTime) / 1e6;
    };
    hrtime = process.hrtime;
    getNanoSeconds = function() {
      var hr;
      hr = hrtime();
      return hr[0] * 1e9 + hr[1];
    };
    moduleLoadTime = getNanoSeconds();
    upTime = process.uptime() * 1e9;
    nodeLoadTime = moduleLoadTime - upTime;
  } else if (Date.now) {
    module.exports = function() {
      return Date.now() - loadTime;
    };
    loadTime = Date.now();
  } else {
    module.exports = function() {
      return new Date().getTime() - loadTime;
    };
    loadTime = new Date().getTime();
  }

}).call(this);



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/node_modules/meteor/ohif:wadoproxy/server/namespace.js");
require("/node_modules/meteor/ohif:wadoproxy/server/initialize.js");
require("/node_modules/meteor/ohif:wadoproxy/server/routes.js");
require("/node_modules/meteor/ohif:wadoproxy/server/convertURL.js");

/* Exports */
Package._define("ohif:wadoproxy", {
  WADOProxy: WADOProxy
});

})();

//# sourceURL=meteor://💻app/packages/ohif_wadoproxy.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjp3YWRvcHJveHkvc2VydmVyL25hbWVzcGFjZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjp3YWRvcHJveHkvc2VydmVyL2luaXRpYWxpemUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6d2Fkb3Byb3h5L3NlcnZlci9yb3V0ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6d2Fkb3Byb3h5L3NlcnZlci9jb252ZXJ0VVJMLmpzIl0sIm5hbWVzIjpbIldBRE9Qcm94eSIsIk1ldGVvciIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsInYiLCJPSElGIiwiU2V0dGluZ3MiLCJPYmplY3QiLCJhc3NpZ24iLCJ1cmkiLCJ1dGlscyIsImFic29sdXRlVXJsIiwiZW5hYmxlZCIsInNldHRpbmdzIiwicHJveHkiLCJSb3V0ZXIiLCJBY2NvdW50cyIsIlNlcnZlcnMiLCJ1cmwiLCJodHRwIiwiaHR0cHMiLCJub3ciLCJkb0F1dGgiLCJ1c2VycyIsImZpbmQiLCJjb3VudCIsImF1dGhlbnRpY2F0ZVVzZXIiLCJyZXF1ZXN0IiwidXNlcklkIiwiaGVhZGVycyIsImxvZ2luVG9rZW4iLCJoYXNoZWRUb2tlbiIsIl9oYXNoTG9naW5Ub2tlbiIsImZpbmRPbmUiLCJfaWQiLCJyb3V0ZSIsInJlcGxhY2UiLCJyZXNwb25zZSIsInBhcmFtcyIsInN0YXJ0IiwidXNlciIsIndyaXRlSGVhZCIsImVuZCIsImF1dGhlbnRpY2F0aW9uVGltZSIsInNlcnZlciIsInF1ZXJ5Iiwic2VydmVySWQiLCJyZXF1ZXN0T3B0IiwicmVxdWVzdE9wdGlvbnMiLCJ3YWRvVXJsIiwibG9nUmVxdWVzdHMiLCJjb25zb2xlIiwibG9nIiwibG9nVGltaW5nIiwidGltZSIsInBhcnNlZCIsInBhcnNlIiwib3B0aW9ucyIsIm1ldGhvZCIsImhvc3RuYW1lIiwicGF0aCIsInJlcXVlc3RlciIsInByb3RvY29sIiwiYWxsb3dVbmF1dGhvcml6ZWRBZ2VudCIsIkFnZW50IiwicmVqZWN0VW5hdXRob3JpemVkIiwiYWdlbnQiLCJwb3J0Iiwia2V5cyIsImZvckVhY2giLCJlbnRyeSIsInZhbHVlIiwiYXV0aCIsInByZXBSZXF1ZXN0VGltZSIsInByb3h5UmVxdWVzdCIsInByb3h5UmVzcG9uc2UiLCJwcm94eVJlcVRpbWUiLCJ0b3RhbFByb3h5VGltZSIsInNlcnZlclRpbWluZ0hlYWRlcnMiLCJzdGF0dXNDb2RlIiwidGltZUVuZCIsInBpcGUiLCJvbiIsImVycm9yIiwibWVzc2FnZSIsIndoZXJlIiwicXVlcnlzdHJpbmciLCJjb252ZXJ0VVJMIiwic2VydmVyQ29uZmlndXJhdGlvbiIsInN0cmluZ2lmeSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLFlBQVksRUFBWixDOzs7Ozs7Ozs7OztBQ0FBLElBQUlDLE1BQUo7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxJQUFKO0FBQVNKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNFLE9BQUtELENBQUwsRUFBTztBQUFDQyxXQUFLRCxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBR25GRSxXQUFXQyxPQUFPQyxNQUFQLENBQWM7QUFDckJDLE9BQU1KLEtBQUtLLEtBQUwsQ0FBV0MsV0FBWCxDQUF1QixlQUF2QixDQURlO0FBRXJCQyxXQUFTO0FBRlksQ0FBZCxFQUdQWixPQUFPYSxRQUFQLElBQW1CYixPQUFPYSxRQUFQLENBQWdCQyxLQUFwQyxHQUE2Q2QsT0FBT2EsUUFBUCxDQUFnQkMsS0FBN0QsR0FBcUUsRUFIN0QsQ0FBWCxDOzs7Ozs7Ozs7OztBQ0hBLElBQUlkLE1BQUo7QUFBV0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJVyxNQUFKO0FBQVdkLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUNZLFNBQU9YLENBQVAsRUFBUztBQUFDVyxhQUFPWCxDQUFQO0FBQVM7O0FBQXBCLENBQTNDLEVBQWlFLENBQWpFO0FBQW9FLElBQUlZLFFBQUo7QUFBYWYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRUFBNkM7QUFBQ2EsV0FBU1osQ0FBVCxFQUFXO0FBQUNZLGVBQVNaLENBQVQ7QUFBVzs7QUFBeEIsQ0FBN0MsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSUMsSUFBSjtBQUFTSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDRSxPQUFLRCxDQUFMLEVBQU87QUFBQ0MsV0FBS0QsQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUE4RCxJQUFJYSxPQUFKO0FBQVloQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0NBQVIsQ0FBYixFQUE2RDtBQUFDYyxVQUFRYixDQUFSLEVBQVU7QUFBQ2EsY0FBUWIsQ0FBUjtBQUFVOztBQUF0QixDQUE3RCxFQUFxRixDQUFyRjs7QUFNblUsTUFBTWMsTUFBTWYsUUFBUSxLQUFSLENBQVo7O0FBQ0EsTUFBTWdCLE9BQU9oQixRQUFRLE1BQVIsQ0FBYjs7QUFDQSxNQUFNaUIsUUFBUWpCLFFBQVEsT0FBUixDQUFkOztBQUNBLE1BQU1rQixNQUFNbEIsUUFBUSxpQkFBUixDQUFaOztBQUVBLE1BQU1tQixTQUFTdEIsT0FBT3VCLEtBQVAsQ0FBYUMsSUFBYixHQUFvQkMsS0FBcEIsS0FBOEIsSUFBOUIsR0FBcUMsS0FBcEQ7O0FBRUEsTUFBTUMsbUJBQW1CQyxXQUFXO0FBQ2hDO0FBQ0EsUUFBTUMsU0FBU0QsUUFBUUUsT0FBUixDQUFnQixXQUFoQixDQUFmO0FBQ0EsUUFBTUMsYUFBYUgsUUFBUUUsT0FBUixDQUFnQixjQUFoQixDQUFuQjs7QUFDQSxNQUFJLENBQUNELE1BQUQsSUFBVyxDQUFDRSxVQUFoQixFQUE0QjtBQUN4QjtBQUNIOztBQUVELFFBQU1DLGNBQWNmLFNBQVNnQixlQUFULENBQXlCRixVQUF6QixDQUFwQjs7QUFFQSxTQUFPOUIsT0FBT3VCLEtBQVAsQ0FBYVUsT0FBYixDQUFxQjtBQUN4QkMsU0FBS04sTUFEbUI7QUFFeEIsK0NBQTJDRztBQUZuQixHQUFyQixDQUFQO0FBSUgsQ0FkRCxDLENBZ0JBO0FBQ0E7OztBQUNBaEIsT0FBT29CLEtBQVAsQ0FBYTdCLFNBQVNHLEdBQVQsQ0FBYTJCLE9BQWIsQ0FBcUIvQixLQUFLSyxLQUFMLENBQVdDLFdBQVgsRUFBckIsRUFBK0MsRUFBL0MsQ0FBYixFQUFpRSxZQUFXO0FBQ3hFLFFBQU1nQixVQUFVLEtBQUtBLE9BQXJCO0FBQ0EsUUFBTVUsV0FBVyxLQUFLQSxRQUF0QjtBQUNBLFFBQU1DLFNBQVMsS0FBS0EsTUFBcEI7QUFFQSxNQUFJQyxRQUFRbEIsS0FBWjtBQUNBLE1BQUltQixJQUFKOztBQUNBLE1BQUlsQixNQUFKLEVBQVk7QUFDUmtCLFdBQU9kLGlCQUFpQkMsT0FBakIsQ0FBUDs7QUFDQSxRQUFJLENBQUNhLElBQUwsRUFBVztBQUNQSCxlQUFTSSxTQUFULENBQW1CLEdBQW5CO0FBQ0FKLGVBQVNLLEdBQVQsQ0FBYSx3REFBYjtBQUNBO0FBQ0g7QUFDSjs7QUFFRCxNQUFJQSxNQUFNckIsS0FBVjtBQUNBLFFBQU1zQixxQkFBcUJELE1BQU1ILEtBQWpDO0FBRUFBLFVBQVFsQixLQUFSO0FBRUEsUUFBTXVCLFNBQVMzQixRQUFRZ0IsT0FBUixDQUFnQkssT0FBT08sS0FBUCxDQUFhQyxRQUE3QixDQUFmOztBQUNBLE1BQUksQ0FBQ0YsTUFBTCxFQUFhO0FBQ1RQLGFBQVNJLFNBQVQsQ0FBbUIsR0FBbkI7QUFDQUosYUFBU0ssR0FBVCxDQUFhLDREQUFiO0FBQ0E7QUFDSDs7QUFFRCxRQUFNSyxhQUFhSCxPQUFPSSxjQUExQixDQTVCd0UsQ0E4QnhFO0FBQ0E7O0FBQ0EsUUFBTUMsVUFBVVgsT0FBT08sS0FBUCxDQUFhM0IsR0FBN0I7O0FBQ0EsTUFBSSxDQUFDK0IsT0FBTCxFQUFjO0FBQ1ZaLGFBQVNJLFNBQVQsQ0FBbUIsR0FBbkI7QUFDQUosYUFBU0ssR0FBVCxDQUFhLG9DQUFiO0FBQ0E7QUFDSDs7QUFFRCxNQUFJSyxXQUFXRyxXQUFmLEVBQTRCO0FBQ3hCQyxZQUFRQyxHQUFSLENBQVl6QixRQUFRVCxHQUFwQjtBQUNIOztBQUVEcUIsVUFBUWxCLEtBQVI7O0FBQ0EsTUFBSTBCLFdBQVdNLFNBQWYsRUFBMEI7QUFDdEJGLFlBQVFHLElBQVIsQ0FBYTNCLFFBQVFULEdBQXJCO0FBQ0gsR0E5Q3VFLENBZ0R4RTs7O0FBQ0EsUUFBTXFDLFNBQVNyQyxJQUFJc0MsS0FBSixDQUFVUCxPQUFWLENBQWYsQ0FqRHdFLENBbUR4RTtBQUNBOztBQUNBLE1BQUlRLFVBQVU7QUFDVjVCLGFBQVMsRUFEQztBQUVWNkIsWUFBUS9CLFFBQVErQixNQUZOO0FBR1ZDLGNBQVVKLE9BQU9JLFFBSFA7QUFJVkMsVUFBTUwsT0FBT0s7QUFKSCxHQUFkO0FBT0EsTUFBSUMsU0FBSjs7QUFDQSxNQUFJTixPQUFPTyxRQUFQLEtBQW9CLFFBQXhCLEVBQWtDO0FBQzlCRCxnQkFBWXpDLE1BQU1PLE9BQWxCO0FBRUEsVUFBTW9DLHlCQUF5QixJQUFJM0MsTUFBTTRDLEtBQVYsQ0FBZ0I7QUFBRUMsMEJBQW9CO0FBQXRCLEtBQWhCLENBQS9CO0FBQ0FSLFlBQVFTLEtBQVIsR0FBZ0JILHNCQUFoQjtBQUNILEdBTEQsTUFLTztBQUNIRixnQkFBWTFDLEtBQUtRLE9BQWpCO0FBQ0g7O0FBRUQsTUFBSTRCLE9BQU9ZLElBQVgsRUFBaUI7QUFDYlYsWUFBUVUsSUFBUixHQUFlWixPQUFPWSxJQUF0QjtBQUNIOztBQUVENUQsU0FBTzZELElBQVAsQ0FBWXpDLFFBQVFFLE9BQXBCLEVBQTZCd0MsT0FBN0IsQ0FBcUNDLFNBQVM7QUFDMUMsVUFBTUMsUUFBUTVDLFFBQVFFLE9BQVIsQ0FBZ0J5QyxLQUFoQixDQUFkOztBQUNBLFFBQUlBLEtBQUosRUFBVztBQUNQYixjQUFRNUIsT0FBUixDQUFnQnlDLEtBQWhCLElBQXlCQyxLQUF6QjtBQUNIO0FBQ0osR0FMRCxFQTFFd0UsQ0FpRnhFO0FBQ0E7O0FBQ0EsTUFBSXhCLFdBQVd5QixJQUFmLEVBQXFCO0FBQ2pCZixZQUFRZSxJQUFSLEdBQWV6QixXQUFXeUIsSUFBMUI7QUFDSDs7QUFFRDlCLFFBQU1yQixLQUFOO0FBQ0EsUUFBTW9ELGtCQUFrQi9CLE1BQU1ILEtBQTlCLENBeEZ3RSxDQTBGeEU7O0FBQ0EsUUFBTW1DLGVBQWViLFVBQVVKLE9BQVYsRUFBbUJrQixpQkFBaUI7QUFDckQ7QUFDQTtBQUNBO0FBQ0FqQyxVQUFNckIsS0FBTjtBQUNBLFVBQU11RCxlQUFlbEMsTUFBTUgsS0FBM0I7QUFDQSxVQUFNc0MsaUJBQWlCbEMscUJBQXFCOEIsZUFBckIsR0FBdUNHLFlBQTlEO0FBQ0EsVUFBTUUsc0JBQXVCO21CQUNsQm5DLGtCQUFtQjt1QkFDZjhCLGVBQWdCO3dCQUNmRyxZQUFhOzBCQUNYQyxjQUFlO1NBSkwsQ0FLMUJ6QyxPQUwwQixDQUtsQixLQUxrQixFQUtYLEVBTFcsQ0FBNUI7QUFPQXVDLGtCQUFjOUMsT0FBZCxDQUFzQixlQUF0QixJQUF5Q2lELG1CQUF6QztBQUVBekMsYUFBU0ksU0FBVCxDQUFtQmtDLGNBQWNJLFVBQWpDLEVBQTZDSixjQUFjOUMsT0FBM0Q7O0FBRUEsUUFBSWtCLFdBQVdNLFNBQWYsRUFBMEI7QUFDdEJGLGNBQVE2QixPQUFSLENBQWdCckQsUUFBUVQsR0FBeEI7QUFDSDs7QUFFRCxXQUFPeUQsY0FBY00sSUFBZCxDQUFtQjVDLFFBQW5CLEVBQTZCO0FBQUVLLFdBQUs7QUFBUCxLQUE3QixDQUFQO0FBQ0gsR0F2Qm9CLENBQXJCLENBM0Z3RSxDQW9IeEU7O0FBQ0FnQyxlQUFhUSxFQUFiLENBQWdCLE9BQWhCLEVBQXlCQyxTQUFTO0FBQzlCekMsVUFBTXJCLEtBQU47QUFDQSxVQUFNdUQsZUFBZWxDLE1BQU1ILEtBQTNCO0FBQ0EsVUFBTXNDLGlCQUFpQmxDLHFCQUFxQjhCLGVBQXJCLEdBQXVDRyxZQUE5RDtBQUNBekIsWUFBUTZCLE9BQVIsQ0FBZ0JyRCxRQUFRVCxHQUF4QjtBQUNBLFVBQU00RCxzQkFBc0I7QUFDeEIsdUJBQWtCO3VCQUNQbkMsa0JBQW1COzJCQUNmOEIsZUFBZ0I7NEJBQ2ZHLFlBQWE7OEJBQ1hDLGNBQWU7YUFKaEIsQ0FLZnpDLE9BTGUsQ0FLUCxLQUxPLEVBS0EsRUFMQTtBQURPLEtBQTVCO0FBU0FDLGFBQVNJLFNBQVQsQ0FBbUIsR0FBbkIsRUFBd0JxQyxtQkFBeEI7QUFDQXpDLGFBQVNLLEdBQVQsQ0FBYyx3Q0FBdUN5QyxNQUFNQyxPQUFRLElBQW5FO0FBQ0gsR0FoQkQsRUFySHdFLENBdUl4RTtBQUNBOztBQUNBekQsVUFBUXNELElBQVIsQ0FBYVAsWUFBYjtBQUNILENBMUlELEVBMElHO0FBQ0NXLFNBQU87QUFEUixDQTFJSCxFOzs7Ozs7Ozs7OztBQy9CQSxNQUFNQyxjQUFjbkYsUUFBUSxhQUFSLENBQXBCOztBQUVBSixVQUFVd0YsVUFBVixHQUF1QixDQUFDckUsR0FBRCxFQUFNc0UsbUJBQU4sS0FBOEI7QUFDakQsTUFBSSxDQUFDbEYsU0FBU00sT0FBZCxFQUF1QjtBQUNuQixXQUFPTSxHQUFQO0FBQ0g7O0FBRUQsTUFBSSxDQUFDQSxHQUFMLEVBQVU7QUFDTixXQUFPLElBQVA7QUFDSDs7QUFFRCxRQUFNNEIsV0FBVzBDLG9CQUFvQnRELEdBQXJDO0FBQ0EsUUFBTVcsUUFBUXlDLFlBQVlHLFNBQVosQ0FBc0I7QUFBQ3ZFLE9BQUQ7QUFBTTRCO0FBQU4sR0FBdEIsQ0FBZDtBQUNBLFNBQVEsR0FBRXhDLFNBQVNHLEdBQUksSUFBR29DLEtBQU0sRUFBaEM7QUFDSCxDQVpELEMiLCJmaWxlIjoiL3BhY2thZ2VzL29oaWZfd2Fkb3Byb3h5LmpzIiwic291cmNlc0NvbnRlbnQiOlsiV0FET1Byb3h5ID0ge307IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcclxuXHJcblNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7XHJcbiAgICB1cmkgOiBPSElGLnV0aWxzLmFic29sdXRlVXJsKFwiL19fd2Fkb19wcm94eVwiKSxcclxuICAgIGVuYWJsZWQ6IHRydWVcclxufSwgKE1ldGVvci5zZXR0aW5ncyAmJiBNZXRlb3Iuc2V0dGluZ3MucHJveHkpID8gTWV0ZW9yLnNldHRpbmdzLnByb3h5IDoge30pOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnbWV0ZW9yL2lyb246cm91dGVyJztcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuaW1wb3J0IHsgT0hJRiB9IGZyb20gJ21ldGVvci9vaGlmOmNvcmUnO1xuaW1wb3J0IHsgU2VydmVycyB9IGZyb20gJ21ldGVvci9vaGlmOnNlcnZlcnMvYm90aC9jb2xsZWN0aW9ucyc7XG5cbmNvbnN0IHVybCA9IHJlcXVpcmUoJ3VybCcpO1xuY29uc3QgaHR0cCA9IHJlcXVpcmUoJ2h0dHAnKTtcbmNvbnN0IGh0dHBzID0gcmVxdWlyZSgnaHR0cHMnKTtcbmNvbnN0IG5vdyA9IHJlcXVpcmUoJ3BlcmZvcm1hbmNlLW5vdycpO1xuXG5jb25zdCBkb0F1dGggPSBNZXRlb3IudXNlcnMuZmluZCgpLmNvdW50KCkgPyB0cnVlIDogZmFsc2U7XG5cbmNvbnN0IGF1dGhlbnRpY2F0ZVVzZXIgPSByZXF1ZXN0ID0+IHtcbiAgICAvLyBPbmx5IGFsbG93IGxvZ2dlZC1pbiB1c2VycyB0byBhY2Nlc3MgdGhpcyByb3V0ZVxuICAgIGNvbnN0IHVzZXJJZCA9IHJlcXVlc3QuaGVhZGVyc1sneC11c2VyLWlkJ107XG4gICAgY29uc3QgbG9naW5Ub2tlbiA9IHJlcXVlc3QuaGVhZGVyc1sneC1hdXRoLXRva2VuJ107XG4gICAgaWYgKCF1c2VySWQgfHwgIWxvZ2luVG9rZW4pIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGhhc2hlZFRva2VuID0gQWNjb3VudHMuX2hhc2hMb2dpblRva2VuKGxvZ2luVG9rZW4pO1xuXG4gICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kT25lKHtcbiAgICAgICAgX2lkOiB1c2VySWQsXG4gICAgICAgICdzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMuaGFzaGVkVG9rZW4nOiBoYXNoZWRUb2tlblxuICAgIH0pO1xufTtcblxuLy8gU2V0dXAgYSBSb3V0ZSB1c2luZyBJcm9uIFJvdXRlciB0byBhdm9pZCBDcm9zcy1vcmlnaW4gcmVzb3VyY2Ugc2hhcmluZ1xuLy8gKENPUlMpIGVycm9ycy4gV2Ugb25seSBoYW5kbGUgdGhpcyByb3V0ZSBvbiB0aGUgU2VydmVyLlxuUm91dGVyLnJvdXRlKFNldHRpbmdzLnVyaS5yZXBsYWNlKE9ISUYudXRpbHMuYWJzb2x1dGVVcmwoKSwgJycpLCBmdW5jdGlvbigpIHtcbiAgICBjb25zdCByZXF1ZXN0ID0gdGhpcy5yZXF1ZXN0O1xuICAgIGNvbnN0IHJlc3BvbnNlID0gdGhpcy5yZXNwb25zZTtcbiAgICBjb25zdCBwYXJhbXMgPSB0aGlzLnBhcmFtcztcblxuICAgIGxldCBzdGFydCA9IG5vdygpO1xuICAgIGxldCB1c2VyO1xuICAgIGlmIChkb0F1dGgpIHtcbiAgICAgICAgdXNlciA9IGF1dGhlbnRpY2F0ZVVzZXIocmVxdWVzdCk7XG4gICAgICAgIGlmICghdXNlcikge1xuICAgICAgICAgICAgcmVzcG9uc2Uud3JpdGVIZWFkKDQwMSk7XG4gICAgICAgICAgICByZXNwb25zZS5lbmQoJ0Vycm9yOiBZb3UgbXVzdCBiZSBsb2dnZWQgaW4gdG8gcGVyZm9ybSB0aGlzIGFjdGlvbi5cXG4nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGxldCBlbmQgPSBub3coKTtcbiAgICBjb25zdCBhdXRoZW50aWNhdGlvblRpbWUgPSBlbmQgLSBzdGFydDtcblxuICAgIHN0YXJ0ID0gbm93KCk7XG5cbiAgICBjb25zdCBzZXJ2ZXIgPSBTZXJ2ZXJzLmZpbmRPbmUocGFyYW1zLnF1ZXJ5LnNlcnZlcklkKTtcbiAgICBpZiAoIXNlcnZlcikge1xuICAgICAgICByZXNwb25zZS53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgcmVzcG9uc2UuZW5kKCdFcnJvcjogTm8gU2VydmVyIHdpdGggdGhlIHNwZWNpZmllZCBTZXJ2ZXIgSUQgd2FzIGZvdW5kLlxcbicpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcmVxdWVzdE9wdCA9IHNlcnZlci5yZXF1ZXN0T3B0aW9ucztcblxuICAgIC8vIElmIG5vIFdlYiBBY2Nlc3MgdG8gRElDT00gT2JqZWN0cyAoV0FETykgU2VydmljZSBVUkwgaXMgcHJvdmlkZWRcbiAgICAvLyByZXR1cm4gYW4gZXJyb3IgZm9yIHRoZSByZXF1ZXN0LlxuICAgIGNvbnN0IHdhZG9VcmwgPSBwYXJhbXMucXVlcnkudXJsO1xuICAgIGlmICghd2Fkb1VybCkge1xuICAgICAgICByZXNwb25zZS53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgcmVzcG9uc2UuZW5kKCdFcnJvcjogTm8gV0FETyBVUkwgd2FzIHByb3ZpZGVkLlxcbicpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHJlcXVlc3RPcHQubG9nUmVxdWVzdHMpIHtcbiAgICAgICAgY29uc29sZS5sb2cocmVxdWVzdC51cmwpO1xuICAgIH1cblxuICAgIHN0YXJ0ID0gbm93KCk7XG4gICAgaWYgKHJlcXVlc3RPcHQubG9nVGltaW5nKSB7XG4gICAgICAgIGNvbnNvbGUudGltZShyZXF1ZXN0LnVybCk7XG4gICAgfVxuXG4gICAgLy8gVXNlIE5vZGUncyBVUkwgcGFyc2UgdG8gZGVjb2RlIHRoZSBxdWVyeSBVUkxcbiAgICBjb25zdCBwYXJzZWQgPSB1cmwucGFyc2Uod2Fkb1VybCk7XG5cbiAgICAvLyBDcmVhdGUgYW4gb2JqZWN0IHRvIGhvbGQgdGhlIGluZm9ybWF0aW9uIHJlcXVpcmVkXG4gICAgLy8gZm9yIHRoZSByZXF1ZXN0IHRvIHRoZSBQQUNTLlxuICAgIGxldCBvcHRpb25zID0ge1xuICAgICAgICBoZWFkZXJzOiB7fSxcbiAgICAgICAgbWV0aG9kOiByZXF1ZXN0Lm1ldGhvZCxcbiAgICAgICAgaG9zdG5hbWU6IHBhcnNlZC5ob3N0bmFtZSxcbiAgICAgICAgcGF0aDogcGFyc2VkLnBhdGhcbiAgICB9O1xuXG4gICAgbGV0IHJlcXVlc3RlcjtcbiAgICBpZiAocGFyc2VkLnByb3RvY29sID09PSAnaHR0cHM6Jykge1xuICAgICAgICByZXF1ZXN0ZXIgPSBodHRwcy5yZXF1ZXN0O1xuXG4gICAgICAgIGNvbnN0IGFsbG93VW5hdXRob3JpemVkQWdlbnQgPSBuZXcgaHR0cHMuQWdlbnQoeyByZWplY3RVbmF1dGhvcml6ZWQ6IGZhbHNlIH0pO1xuICAgICAgICBvcHRpb25zLmFnZW50ID0gYWxsb3dVbmF1dGhvcml6ZWRBZ2VudDtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXF1ZXN0ZXIgPSBodHRwLnJlcXVlc3Q7XG4gICAgfVxuXG4gICAgaWYgKHBhcnNlZC5wb3J0KSB7XG4gICAgICAgIG9wdGlvbnMucG9ydCA9IHBhcnNlZC5wb3J0O1xuICAgIH1cblxuICAgIE9iamVjdC5rZXlzKHJlcXVlc3QuaGVhZGVycykuZm9yRWFjaChlbnRyeSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gcmVxdWVzdC5oZWFkZXJzW2VudHJ5XTtcbiAgICAgICAgaWYgKGVudHJ5KSB7XG4gICAgICAgICAgICBvcHRpb25zLmhlYWRlcnNbZW50cnldID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIFJldHJpZXZlIHRoZSBhdXRob3JpemF0aW9uIHVzZXI6cGFzc3dvcmQgc3RyaW5nIGZvciB0aGUgUEFDUyxcbiAgICAvLyBpZiBvbmUgaXMgcmVxdWlyZWQsIGFuZCBpbmNsdWRlIGl0IGluIHRoZSByZXF1ZXN0IHRvIHRoZSBQQUNTLlxuICAgIGlmIChyZXF1ZXN0T3B0LmF1dGgpIHtcbiAgICAgICAgb3B0aW9ucy5hdXRoID0gcmVxdWVzdE9wdC5hdXRoO1xuICAgIH1cblxuICAgIGVuZCA9IG5vdygpO1xuICAgIGNvbnN0IHByZXBSZXF1ZXN0VGltZSA9IGVuZCAtIHN0YXJ0O1xuXG4gICAgLy8gVXNlIE5vZGUncyBIVFRQIEFQSSB0byBzZW5kIGEgcmVxdWVzdCB0byB0aGUgUEFDU1xuICAgIGNvbnN0IHByb3h5UmVxdWVzdCA9IHJlcXVlc3RlcihvcHRpb25zLCBwcm94eVJlc3BvbnNlID0+IHtcbiAgICAgICAgLy8gV2hlbiB3ZSByZWNlaXZlIGRhdGEgZnJvbSB0aGUgUEFDUywgc3RyZWFtIGl0IGFzIHRoZVxuICAgICAgICAvLyByZXNwb25zZSB0byB0aGUgb3JpZ2luYWwgcmVxdWVzdC5cbiAgICAgICAgLy8gY29uc29sZS5sb2coYEdvdCByZXNwb25zZTogJHtwcm94eVJlc3BvbnNlLnN0YXR1c0NvZGV9YCk7XG4gICAgICAgIGVuZCA9IG5vdygpO1xuICAgICAgICBjb25zdCBwcm94eVJlcVRpbWUgPSBlbmQgLSBzdGFydDtcbiAgICAgICAgY29uc3QgdG90YWxQcm94eVRpbWUgPSBhdXRoZW50aWNhdGlvblRpbWUgKyBwcmVwUmVxdWVzdFRpbWUgKyBwcm94eVJlcVRpbWU7XG4gICAgICAgIGNvbnN0IHNlcnZlclRpbWluZ0hlYWRlcnMgPSBgXG4gICAgICAgICAgICBhdXRoPSR7YXV0aGVudGljYXRpb25UaW1lfTsgXCJBdXRoZW50aWNhdGUgVXNlclwiLFxuICAgICAgICAgICAgcHJlcC1yZXE9JHtwcmVwUmVxdWVzdFRpbWV9OyBcIlByZXBhcmUgUmVxdWVzdCBIZWFkZXJzXCIsXG4gICAgICAgICAgICBwcm94eS1yZXE9JHtwcm94eVJlcVRpbWV9OyBcIlJlcXVlc3QgdG8gV0FETyBVUklcIixcbiAgICAgICAgICAgIHRvdGFsLXByb3h5PSR7dG90YWxQcm94eVRpbWV9OyBcIlRvdGFsXCIsXG4gICAgICAgIGAucmVwbGFjZSgvXFxuL2csICcnKTtcblxuICAgICAgICBwcm94eVJlc3BvbnNlLmhlYWRlcnNbJ1NlcnZlci1UaW1pbmcnXSA9IHNlcnZlclRpbWluZ0hlYWRlcnM7XG5cbiAgICAgICAgcmVzcG9uc2Uud3JpdGVIZWFkKHByb3h5UmVzcG9uc2Uuc3RhdHVzQ29kZSwgcHJveHlSZXNwb25zZS5oZWFkZXJzKTtcblxuICAgICAgICBpZiAocmVxdWVzdE9wdC5sb2dUaW1pbmcpIHtcbiAgICAgICAgICAgIGNvbnNvbGUudGltZUVuZChyZXF1ZXN0LnVybCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcHJveHlSZXNwb25zZS5waXBlKHJlc3BvbnNlLCB7IGVuZDogdHJ1ZSB9KTtcbiAgICB9KTtcblxuICAgIC8vIElmIG91ciByZXF1ZXN0IHRvIHRoZSBQQUNTIGZhaWxzLCBsb2cgdGhlIGVycm9yIG1lc3NhZ2VcbiAgICBwcm94eVJlcXVlc3Qub24oJ2Vycm9yJywgZXJyb3IgPT4ge1xuICAgICAgICBlbmQgPSBub3coKTtcbiAgICAgICAgY29uc3QgcHJveHlSZXFUaW1lID0gZW5kIC0gc3RhcnQ7XG4gICAgICAgIGNvbnN0IHRvdGFsUHJveHlUaW1lID0gYXV0aGVudGljYXRpb25UaW1lICsgcHJlcFJlcXVlc3RUaW1lICsgcHJveHlSZXFUaW1lO1xuICAgICAgICBjb25zb2xlLnRpbWVFbmQocmVxdWVzdC51cmwpO1xuICAgICAgICBjb25zdCBzZXJ2ZXJUaW1pbmdIZWFkZXJzID0ge1xuICAgICAgICAgICAgJ1NlcnZlci1UaW1pbmcnOiBgXG4gICAgICAgICAgICAgICAgYXV0aD0ke2F1dGhlbnRpY2F0aW9uVGltZX07IFwiQXV0aGVudGljYXRlIFVzZXJcIixcbiAgICAgICAgICAgICAgICBwcmVwLXJlcT0ke3ByZXBSZXF1ZXN0VGltZX07IFwiUHJlcGFyZSBSZXF1ZXN0IEhlYWRlcnNcIixcbiAgICAgICAgICAgICAgICBwcm94eS1yZXE9JHtwcm94eVJlcVRpbWV9OyBcIlJlcXVlc3QgdG8gV0FETyBVUklcIixcbiAgICAgICAgICAgICAgICB0b3RhbC1wcm94eT0ke3RvdGFsUHJveHlUaW1lfTsgXCJUb3RhbFwiLFxuICAgICAgICAgICAgYC5yZXBsYWNlKC9cXG4vZywgJycpXG4gICAgICAgIH07XG5cbiAgICAgICAgcmVzcG9uc2Uud3JpdGVIZWFkKDUwMCwgc2VydmVyVGltaW5nSGVhZGVycyk7XG4gICAgICAgIHJlc3BvbnNlLmVuZChgRXJyb3I6IFByb2JsZW0gd2l0aCByZXF1ZXN0IHRvIFBBQ1M6ICR7ZXJyb3IubWVzc2FnZX1cXG5gKTtcbiAgICB9KTtcblxuICAgIC8vIFN0cmVhbSB0aGUgb3JpZ2luYWwgcmVxdWVzdCBpbmZvcm1hdGlvbiBpbnRvIHRoZSByZXF1ZXN0XG4gICAgLy8gdG8gdGhlIFBBQ1NcbiAgICByZXF1ZXN0LnBpcGUocHJveHlSZXF1ZXN0KTtcbn0sIHtcbiAgICB3aGVyZTogJ3NlcnZlcidcbn0pO1xuIiwiY29uc3QgcXVlcnlzdHJpbmcgPSByZXF1aXJlKFwicXVlcnlzdHJpbmdcIik7XG5cbldBRE9Qcm94eS5jb252ZXJ0VVJMID0gKHVybCwgc2VydmVyQ29uZmlndXJhdGlvbikgPT4ge1xuICAgIGlmICghU2V0dGluZ3MuZW5hYmxlZCkge1xuICAgICAgICByZXR1cm4gdXJsO1xuICAgIH1cblxuICAgIGlmICghdXJsKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGNvbnN0IHNlcnZlcklkID0gc2VydmVyQ29uZmlndXJhdGlvbi5faWQ7XG4gICAgY29uc3QgcXVlcnkgPSBxdWVyeXN0cmluZy5zdHJpbmdpZnkoe3VybCwgc2VydmVySWR9KTtcbiAgICByZXR1cm4gYCR7U2V0dGluZ3MudXJpfT8ke3F1ZXJ5fWA7XG59Il19
