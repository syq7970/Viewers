(function () {



/* Exports */
Package._define("ohif:hotkeys");

})();
