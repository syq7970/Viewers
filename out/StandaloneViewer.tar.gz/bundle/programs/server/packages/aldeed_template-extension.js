(function () {



/* Exports */
Package._define("aldeed:template-extension");

})();
