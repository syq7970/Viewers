(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var DICOMWeb = Package['ohif:dicom-services'].DICOMWeb;
var DIMSE = Package['ohif:dicom-services'].DIMSE;
var WADOProxy = Package['ohif:wadoproxy'].WADOProxy;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var encodeQueryData, remoteGetValue;

var require = meteorInstall({"node_modules":{"meteor":{"ohif:studies":{"both":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/both/main.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
OHIF.studies = {};

require('../imports/both');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/server/main.js                                                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
require('../imports/server');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"both":{"index.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/both/index.js                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/index.js                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.watch(require("./lib"));
module.watch(require("./methods"));
module.watch(require("./services"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"encodeQueryData.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/lib/encodeQueryData.js                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
/**
 * Converts the properties to URL query parameters.  Based on:
 * http://stackoverflow.com/questions/111529/create-query-parameters-in-javascript
 *
 * @param data
 * @returns {string}
 */
encodeQueryData = function (data) {
  var ret = [];

  for (var d in data) {
    if (data[d]) {
      ret.push(encodeURIComponent(d) + '=' + encodeURIComponent(data[d]));
    }
  }

  return ret.join('&');
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/lib/index.js                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.watch(require("./remoteGetValue.js"));
module.watch(require("./encodeQueryData.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"parseFloatArray.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/lib/parseFloatArray.js                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  parseFloatArray: () => parseFloatArray
});

const parseFloatArray = function (obj) {
  var result = [];

  if (!obj) {
    return result;
  }

  var objs = obj.split("\\");

  for (var i = 0; i < objs.length; i++) {
    result.push(parseFloat(objs[i]));
  }

  return result;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remoteGetValue.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/lib/remoteGetValue.js                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  remoteGetValue: () => remoteGetValue
});

const remoteGetValue = function (obj) {
  return obj ? obj.Value : null;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"getStudyMetadata.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/methods/getStudyMetadata.js                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);
Meteor.methods({
  /**
   * Retrieves Study metadata given a Study Instance UID
   * This Meteor method is available from both the client and the server
   */
  GetStudyMetadata: function (studyInstanceUid) {
    OHIF.log.info('GetStudyMetadata(%s)', studyInstanceUid); // Get the server data. This is user-defined in the config.json files or through servers
    // configuration modal

    const server = OHIF.servers.getCurrentServer();

    if (!server) {
      throw new Meteor.Error('improper-server-config', 'No properly configured server was available over DICOMWeb or DIMSE.');
    }

    try {
      if (server.type === 'dicomWeb') {
        return OHIF.studies.services.WADO.RetrieveMetadata(server, studyInstanceUid);
      } else if (server.type === 'dimse') {
        return OHIF.studies.services.DIMSE.RetrieveMetadata(studyInstanceUid);
      }
    } catch (error) {
      OHIF.log.trace();
      throw error;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/methods/index.js                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.watch(require("./getStudyMetadata.js"));
module.watch(require("./studylistSearch.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"studylistSearch.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/methods/studylistSearch.js                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);
Meteor.methods({
  /**
   * Use the specified filter to conduct a search from the DICOM server
   *
   * @param filter
   */
  StudyListSearch(filter) {
    // Get the server data. This is user-defined in the config.json files or through servers
    // configuration modal
    const server = OHIF.servers.getCurrentServer();

    if (!server) {
      throw new Meteor.Error('improper-server-config', 'No properly configured server was available over DICOMWeb or DIMSE.');
    }

    try {
      if (server.type === 'dicomWeb') {
        return OHIF.studies.services.QIDO.Studies(server, filter);
      } else if (server.type === 'dimse') {
        return OHIF.studies.services.DIMSE.Studies(filter);
      }
    } catch (error) {
      OHIF.log.trace();
      throw error;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"services":{"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/index.js                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.watch(require("./namespace.js"));
module.watch(require("./qido/instances.js"));
module.watch(require("./qido/studies.js"));
module.watch(require("./wado/retrieveMetadata.js"));
module.watch(require("./dimse/instances.js"));
module.watch(require("./dimse/studies.js"));
module.watch(require("./dimse/retrieveMetadata.js"));
module.watch(require("./dimse/setup.js"));
module.watch(require("./remote/instances.js"));
module.watch(require("./remote/studies.js"));
module.watch(require("./remote/retrieveMetadata.js"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"namespace.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/namespace.js                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
const Services = {};
Services.QIDO = {};
Services.WADO = {};
Services.DIMSE = {};
Services.REMOTE = {};
OHIF.studies.services = Services;

remoteGetValue = function (obj) {
  return obj ? obj.Value : null;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dimse":{"instances.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/dimse/instances.js                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);

/**
 * Parses data returned from a study search and transforms it into
 * an array of series that are present in the study
 *
 * @param resultData
 * @returns {Array} Series List
 */
function resultDataToStudyMetadata(resultData, studyInstanceUid) {
  const seriesMap = {};
  const seriesList = [];
  resultData.forEach(function (instanceRaw) {
    const instance = instanceRaw.toObject(); // Use seriesMap to cache series data
    // If the series instance UID has already been used to
    // process series data, continue using that series

    const seriesInstanceUid = instance[0x0020000E];
    let series = seriesMap[seriesInstanceUid]; // If no series data exists in the seriesMap cache variable,
    // process any available series data

    if (!series) {
      series = {
        seriesInstanceUid: seriesInstanceUid,
        seriesNumber: instance[0x00200011],
        instances: []
      }; // Save this data in the seriesMap cache variable

      seriesMap[seriesInstanceUid] = series;
      seriesList.push(series);
    } // TODO: Check which peer it should point to


    const server = OHIF.servers.getCurrentServer().peers[0];
    const serverRoot = server.host + ':' + server.port;
    const sopInstanceUid = instance[0x00080018];
    const uri = serverRoot + '/studies/' + studyInstanceUid + '/series/' + seriesInstanceUid + '/instances/' + sopInstanceUid + '/frames/1'; // Add this instance to the current series

    series.instances.push({
      sopClassUid: instance[0x00080016],
      sopInstanceUid,
      uri,
      instanceNumber: instance[0x00200013]
    });
  });
  return seriesList;
}
/**
 * Retrieve a set of instances using a DIMSE call
 * @param studyInstanceUid
 * @returns {{wadoUriRoot: String, studyInstanceUid: String, seriesList: Array}}
 */


OHIF.studies.services.DIMSE.Instances = function (studyInstanceUid) {
  //var url = buildUrl(server, studyInstanceUid);
  const result = DIMSE.retrieveInstances(studyInstanceUid);
  return {
    studyInstanceUid: studyInstanceUid,
    seriesList: resultDataToStudyMetadata(result, studyInstanceUid)
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"retrieveMetadata.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/dimse/retrieveMetadata.js                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
let parseFloatArray;
module.watch(require("meteor/ohif:studies/imports/server/lib/parseFloatArray"), {
  parseFloatArray(v) {
    parseFloatArray = v;
  }

}, 1);

/**
 * Returns the value of the element (e.g. '00280009')
 *
 * @param element - The group/element of the element (e.g. '00280009')
 * @param defaultValue - The default value to return if the element does not exist
 * @returns {*}
 */
function getValue(element, defaultValue) {
  if (!element || !element.value) {
    return defaultValue;
  }

  return element.value;
}
/**
 * Parses the SourceImageSequence, if it exists, in order
 * to return a ReferenceSOPInstanceUID. The ReferenceSOPInstanceUID
 * is used to refer to this image in any accompanying DICOM-SR documents.
 *
 * @param instance
 * @returns {String} The ReferenceSOPInstanceUID
 */


function getSourceImageInstanceUid(instance) {
  // TODO= Parse the whole Source Image Sequence
  // This is a really poor workaround for now.
  // Later we should probably parse the whole sequence.
  const SourceImageSequence = instance[0x00082112];

  if (SourceImageSequence && SourceImageSequence.length) {
    return SourceImageSequence[0][0x00081155];
  }
}
/**
 * Parses result data from a DIMSE search into Study MetaData
 * Returns an object populated with study metadata, including the
 * series list.
 *
 * @param studyInstanceUid
 * @param resultData
 * @returns {{seriesList: Array, patientName: *, patientId: *, accessionNumber: *, studyDate: *, modalities: *, studyDescription: *, imageCount: *, studyInstanceUid: *}}
 */


function resultDataToStudyMetadata(studyInstanceUid, resultData) {
  OHIF.log.info('resultDataToStudyMetadata');
  const seriesMap = {};
  const seriesList = [];

  if (!resultData.length) {
    return;
  }

  const anInstance = resultData[0].toObject();

  if (!anInstance) {
    return;
  }

  const studyData = {
    seriesList: seriesList,
    patientName: anInstance[0x00100010],
    patientId: anInstance[0x00100020],
    patientBirthDate: anInstance[0x00100030],
    patientSex: anInstance[0x00100040],
    accessionNumber: anInstance[0x00080050],
    studyDate: anInstance[0x00080020],
    modalities: anInstance[0x00080061],
    studyDescription: anInstance[0x00081030],
    imageCount: anInstance[0x00201208],
    studyInstanceUid: anInstance[0x0020000D],
    institutionName: anInstance[0x00080080]
  };
  resultData.forEach(function (instanceRaw) {
    const instance = instanceRaw.toObject();
    const seriesInstanceUid = instance[0x0020000E];
    let series = seriesMap[seriesInstanceUid];

    if (!series) {
      series = {
        seriesDescription: instance[0x0008103E],
        modality: instance[0x00080060],
        seriesInstanceUid: seriesInstanceUid,
        seriesNumber: parseFloat(instance[0x00200011]),
        instances: []
      };
      seriesMap[seriesInstanceUid] = series;
      seriesList.push(series);
    }

    const sopInstanceUid = instance[0x00080018];
    const instanceSummary = {
      imageType: instance[0x00080008],
      sopClassUid: instance[0x00080016],
      modality: instance[0x00080060],
      sopInstanceUid: sopInstanceUid,
      instanceNumber: parseFloat(instance[0x00200013]),
      imagePositionPatient: instance[0x00200032],
      imageOrientationPatient: instance[0x00200037],
      frameOfReferenceUID: instance[0x00200052],
      sliceThickness: parseFloat(instance[0x00180050]),
      sliceLocation: parseFloat(instance[0x00201041]),
      tablePosition: parseFloat(instance[0x00189327]),
      samplesPerPixel: parseFloat(instance[0x00280002]),
      photometricInterpretation: instance[0x00280004],
      planarConfiguration: parseFloat(instance[0x00280006]),
      rows: parseFloat(instance[0x00280010]),
      columns: parseFloat(instance[0x00280011]),
      pixelSpacing: instance[0x00280030],
      bitsAllocated: parseFloat(instance[0x00280100]),
      bitsStored: parseFloat(instance[0x00280101]),
      highBit: parseFloat(instance[0x00280102]),
      pixelRepresentation: parseFloat(instance[0x00280103]),
      windowCenter: instance[0x00281050],
      windowWidth: instance[0x00281051],
      rescaleIntercept: parseFloat(instance[0x00281052]),
      rescaleSlope: parseFloat(instance[0x00281053]),
      sourceImageInstanceUid: getSourceImageInstanceUid(instance),
      laterality: instance[0x00200062],
      viewPosition: instance[0x00185101],
      acquisitionDateTime: instance[0x0008002A],
      numberOfFrames: parseFloat(instance[0x00280008]),
      frameIncrementPointer: getValue(instance[0x00280009]),
      frameTime: parseFloat(instance[0x00181063]),
      frameTimeVector: parseFloatArray(instance[0x00181065]),
      lossyImageCompression: instance[0x00282110],
      derivationDescription: instance[0x00282111],
      lossyImageCompressionRatio: instance[0x00282112],
      lossyImageCompressionMethod: instance[0x00282114],
      spacingBetweenSlices: instance[0x00180088],
      echoNumber: instance[0x00180086],
      contrastBolusAgent: instance[0x00180010]
    }; // Retrieve the actual data over WADO-URI

    const server = OHIF.servers.getCurrentServer();
    const wadouri = `${server.wadoUriRoot}?requestType=WADO&studyUID=${studyInstanceUid}&seriesUID=${seriesInstanceUid}&objectUID=${sopInstanceUid}&contentType=application%2Fdicom`;
    instanceSummary.wadouri = WADOProxy.convertURL(wadouri, server);
    series.instances.push(instanceSummary);
  });
  studyData.studyInstanceUid = studyInstanceUid;
  return studyData;
}
/**
 * Retrieved Study MetaData from a DICOM server using DIMSE
 * @param studyInstanceUid
 * @returns {{seriesList: Array, patientName: *, patientId: *, accessionNumber: *, studyDate: *, modalities: *, studyDescription: *, imageCount: *, studyInstanceUid: *}}
 */


OHIF.studies.services.DIMSE.RetrieveMetadata = function (studyInstanceUid) {
  // TODO: Check which peer it should point to
  const activeServer = OHIF.servers.getCurrentServer().peers[0];
  const supportsInstanceRetrievalByStudyUid = activeServer.supportsInstanceRetrievalByStudyUid;
  let results; // Check explicitly for a value of false, since this property
  // may be left undefined in config files

  if (supportsInstanceRetrievalByStudyUid === false) {
    results = DIMSE.retrieveInstancesByStudyOnly(studyInstanceUid);
  } else {
    results = DIMSE.retrieveInstances(studyInstanceUid);
  }

  return resultDataToStudyMetadata(studyInstanceUid, results);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"setup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/dimse/setup.js                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);
let CurrentServer;
module.watch(require("meteor/ohif:servers/both/collections"), {
  CurrentServer(v) {
    CurrentServer = v;
  }

}, 2);

const setupDIMSE = () => {
  // Terminate existing DIMSE servers and sockets and clean up the connection object
  DIMSE.connection.reset(); // Get the new server configuration

  const server = OHIF.servers.getCurrentServer(); // Stop here if the new server is not of DIMSE type

  if (server.type !== 'dimse') {
    return;
  } // Check if peers were defined in the server configuration and throw an error if not


  const peers = server.peers;

  if (!peers || !peers.length) {
    OHIF.log.error('dimse-config: ' + 'No DIMSE Peers provided.');
    throw new Meteor.Error('dimse-config', 'No DIMSE Peers provided.');
  } // Add all the DIMSE peers, establishing the connections


  OHIF.log.info('Adding DIMSE peers');

  try {
    peers.forEach(peer => DIMSE.connection.addPeer(peer));
  } catch (error) {
    OHIF.log.error('dimse-addPeers: ' + error);
    throw new Meteor.Error('dimse-addPeers', error);
  }
}; // Setup the DIMSE connections on startup or when the current server is changed


Meteor.startup(() => {
  CurrentServer.find().observe({
    added: setupDIMSE,
    changed: setupDIMSE
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"studies.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/dimse/studies.js                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let moment;
module.watch(require("meteor/momentjs:moment"), {
  moment(v) {
    moment = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);

/**
 * Parses resulting data from a QIDO call into a set of Study MetaData
 *
 * @param resultData
 * @returns {Array} An array of Study MetaData objects
 */
function resultDataToStudies(resultData) {
  const studies = [];
  resultData.forEach(function (studyRaw) {
    const study = studyRaw.toObject();
    studies.push({
      studyInstanceUid: study[0x0020000D],
      // 00080005 = SpecificCharacterSet
      studyDate: study[0x00080020],
      studyTime: study[0x00080030],
      accessionNumber: study[0x00080050],
      referringPhysicianName: study[0x00080090],
      // 00081190 = URL
      patientName: study[0x00100010],
      patientId: study[0x00100020],
      patientBirthdate: study[0x00100030],
      patientSex: study[0x00100040],
      imageCount: study[0x00201208],
      studyId: study[0x00200010],
      studyDescription: study[0x00081030],
      modalities: study[0x00080061]
    });
  });
  return studies;
}

OHIF.studies.services.DIMSE.Studies = function (filter) {
  OHIF.log.info('Services.DIMSE.Studies');
  let filterStudyDate = '';

  if (filter.studyDateFrom && filter.studyDateTo) {
    const convertDate = date => moment(date, 'MM/DD/YYYY').format('YYYYMMDD');

    const dateFrom = convertDate(filter.studyDateFrom);
    const dateTo = convertDate(filter.studyDateTo);
    filterStudyDate = `${dateFrom}-${dateTo}`;
  } // Build the StudyInstanceUID parameter


  let studyUids = filter.studyInstanceUid || '';

  if (studyUids) {
    studyUids = Array.isArray(studyUids) ? studyUids.join() : studyUids;
    studyUids = studyUids.replace(/[^0-9.]+/g, '\\');
  }

  const parameters = {
    0x0020000D: studyUids,
    0x00100010: filter.patientName,
    0x00100020: filter.patientId,
    0x00080050: filter.accessionNumber,
    0x00080020: filterStudyDate,
    0x00081030: filter.studyDescription,
    0x00100040: '',
    0x00201208: '',
    0x00080061: filter.modalitiesInStudy
  };
  const results = DIMSE.retrieveStudies(parameters);
  return resultDataToStudies(results);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"qido":{"instances.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/qido/instances.js                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);

/**
 * Creates a QIDO URL given the server settings and a study instance UID
 * @param server
 * @param studyInstanceUid
 * @returns {string} URL to be used for QIDO calls
 */
function buildUrl(server, studyInstanceUid) {
  return server.qidoRoot + '/studies/' + studyInstanceUid + '/instances';
}
/**
 * Parses data returned from a QIDO search and transforms it into
 * an array of series that are present in the study
 *
 * @param server The DICOM server
 * @param studyInstanceUid
 * @param resultData
 * @returns {Array} Series List
 */


function resultDataToStudyMetadata(server, studyInstanceUid, resultData) {
  var seriesMap = {};
  var seriesList = [];
  resultData.forEach(function (instance) {
    // Use seriesMap to cache series data
    // If the series instance UID has already been used to
    // process series data, continue using that series
    var seriesInstanceUid = DICOMWeb.getString(instance['0020000E']);
    var series = seriesMap[seriesInstanceUid]; // If no series data exists in the seriesMap cache variable,
    // process any available series data

    if (!series) {
      series = {
        seriesInstanceUid: seriesInstanceUid,
        seriesNumber: DICOMWeb.getString(instance['00200011']),
        instances: []
      }; // Save this data in the seriesMap cache variable

      seriesMap[seriesInstanceUid] = series;
      seriesList.push(series);
    } // The uri for the dicomweb
    // NOTE: DCM4CHEE seems to return the data zipped
    // NOTE: Orthanc returns the data with multi-part mime which cornerstoneWADOImageLoader doesn't
    //       know how to parse yet
    //var uri = DICOMWeb.getString(instance['00081190']);
    //uri = uri.replace('wado-rs', 'dicom-web');
    // manually create a WADO-URI from the UIDs
    // NOTE: Haven't been able to get Orthanc's WADO-URI to work yet - maybe its not configured?


    var sopInstanceUid = DICOMWeb.getString(instance['00080018']);
    var uri = server.wadoUriRoot + '?requestType=WADO&studyUID=' + studyInstanceUid + '&seriesUID=' + seriesInstanceUid + '&objectUID=' + sopInstanceUid + '&contentType=application%2Fdicom'; // Add this instance to the current series

    series.instances.push({
      sopClassUid: DICOMWeb.getString(instance['00080016']),
      sopInstanceUid: sopInstanceUid,
      uri: uri,
      instanceNumber: DICOMWeb.getString(instance['00200013'])
    });
  });
  return seriesList;
}
/**
 * Retrieve a set of instances using a QIDO call
 * @param server
 * @param studyInstanceUid
 * @throws ECONNREFUSED
 * @returns {{wadoUriRoot: String, studyInstanceUid: String, seriesList: Array}}
 */


OHIF.studies.services.QIDO.Instances = function (server, studyInstanceUid) {
  var url = buildUrl(server, studyInstanceUid);

  try {
    var result = DICOMWeb.getJSON(url, server.requestOptions);
    return {
      wadoUriRoot: server.wadoUriRoot,
      studyInstanceUid: studyInstanceUid,
      seriesList: resultDataToStudyMetadata(server, studyInstanceUid, result.data)
    };
  } catch (error) {
    OHIF.log.trace();
    throw error;
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"studies.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/qido/studies.js                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);

/**
 * Creates a QIDO date string for a date range query
 * Assumes the year is positive, at most 4 digits long.
 *
 * @param date The Date object to be formatted
 * @returns {string} The formatted date string
 */
function dateToString(date) {
  if (!date) return '';
  let year = date.getFullYear().toString();
  let month = (date.getMonth() + 1).toString();
  let day = date.getDate().toString();
  year = '0'.repeat(4 - year.length).concat(year);
  month = '0'.repeat(2 - month.length).concat(month);
  day = '0'.repeat(2 - day.length).concat(day);
  return ''.concat(year, month, day);
}
/**
 * Produces a QIDO URL given server details and a set of specified search filter
 * items
 *
 * @param server
 * @param filter
 * @returns {string} The URL with encoded filter query data
 */


function filterToQIDOURL(server, filter) {
  const commaSeparatedFields = ['00081030', // Study Description
  '00080060' //Modality
  // Add more fields here if you want them in the result
  ].join(',');
  const parameters = {
    PatientName: filter.patientName,
    PatientID: filter.patientId,
    AccessionNumber: filter.accessionNumber,
    StudyDescription: filter.studyDescription,
    ModalitiesInStudy: filter.modalitiesInStudy,
    limit: filter.limit,
    includefield: server.qidoSupportsIncludeField ? 'all' : commaSeparatedFields
  }; // build the StudyDate range parameter

  if (filter.studyDateFrom || filter.studyDateTo) {
    const dateFrom = dateToString(new Date(filter.studyDateFrom));
    const dateTo = dateToString(new Date(filter.studyDateTo));
    parameters.StudyDate = `${dateFrom}-${dateTo}`;
  } // Build the StudyInstanceUID parameter


  if (filter.studyInstanceUid) {
    let studyUids = filter.studyInstanceUid;
    studyUids = Array.isArray(studyUids) ? studyUids.join() : studyUids;
    studyUids = studyUids.replace(/[^0-9.]+/g, '\\');
    parameters.StudyInstanceUID = studyUids;
  }

  return server.qidoRoot + '/studies?' + encodeQueryData(parameters);
}
/**
 * Parses resulting data from a QIDO call into a set of Study MetaData
 *
 * @param resultData
 * @returns {Array} An array of Study MetaData objects
 */


function resultDataToStudies(resultData) {
  const studies = [];
  if (!resultData || !resultData.length) return;
  resultData.forEach(study => studies.push({
    studyInstanceUid: DICOMWeb.getString(study['0020000D']),
    // 00080005 = SpecificCharacterSet
    studyDate: DICOMWeb.getString(study['00080020']),
    studyTime: DICOMWeb.getString(study['00080030']),
    accessionNumber: DICOMWeb.getString(study['00080050']),
    referringPhysicianName: DICOMWeb.getString(study['00080090']),
    // 00081190 = URL
    patientName: DICOMWeb.getName(study['00100010']),
    patientId: DICOMWeb.getString(study['00100020']),
    patientBirthdate: DICOMWeb.getString(study['00100030']),
    patientSex: DICOMWeb.getString(study['00100040']),
    studyId: DICOMWeb.getString(study['00200010']),
    numberOfStudyRelatedSeries: DICOMWeb.getString(study['00201206']),
    numberOfStudyRelatedInstances: DICOMWeb.getString(study['00201208']),
    studyDescription: DICOMWeb.getString(study['00081030']),
    // modality: DICOMWeb.getString(study['00080060']),
    // modalitiesInStudy: DICOMWeb.getString(study['00080061']),
    modalities: DICOMWeb.getString(DICOMWeb.getModalities(study['00080060'], study['00080061']))
  }));
  return studies;
}

OHIF.studies.services.QIDO.Studies = (server, filter) => {
  const url = filterToQIDOURL(server, filter);

  try {
    const result = DICOMWeb.getJSON(url, server.requestOptions);
    return resultDataToStudies(result.data);
  } catch (error) {
    OHIF.log.trace();
    throw error;
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"remote":{"instances.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/remote/instances.js                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
let remoteGetValue;
module.watch(require("../../lib/remoteGetValue"), {
  remoteGetValue(v) {
    remoteGetValue = v;
  }

}, 1);

/**
 * Parses data returned from a QIDO search and transforms it into
 * an array of series that are present in the study
 *
 * @param server The DICOM server
 * @param studyInstanceUid
 * @param resultData
 * @returns {Array} Series List
 */
function resultDataToStudyMetadata(server, studyInstanceUid, resultData) {
  var seriesMap = {};
  var seriesList = [];
  resultData.forEach(function (instance) {
    // Use seriesMap to cache series data
    // If the series instance UID has already been used to
    // process series data, continue using that series
    var seriesInstanceUid = remoteGetValue(instance['0020,000e']);
    var series = seriesMap[seriesInstanceUid]; // If no series data exists in the seriesMap cache variable,
    // process any available series data

    if (!series) {
      series = {
        seriesInstanceUid: seriesInstanceUid,
        seriesNumber: parseFloat(remoteGetValue(instance['0020,0011'])),
        instances: []
      }; // Save this data in the seriesMap cache variable

      seriesMap[seriesInstanceUid] = series;
      seriesList.push(series);
    } // The uri for the dicomweb
    // NOTE: DCM4CHEE seems to return the data zipped
    // NOTE: Orthanc returns the data with multi-part mime which cornerstoneWADOImageLoader doesn't
    //       know how to parse yet
    //var uri = DICOMWeb.getString(instance['00081190']);
    //uri = uri.replace('wado-rs', 'dicom-web');
    // manually create a WADO-URI from the UIDs
    // NOTE: Haven't been able to get Orthanc's WADO-URI to work yet - maybe its not configured?


    var sopInstanceUid = remoteGetValue(instance['0008,0018']);
    var uri = server.wadoUriRoot + '?requestType=WADO&studyUID=' + studyInstanceUid + '&seriesUID=' + seriesInstanceUid + '&objectUID=' + sopInstanceUid + "&contentType=application%2Fdicom"; // Add this instance to the current series

    series.instances.push({
      sopClassUid: remoteGetValue(instance['0008,0016']),
      sopInstanceUid: sopInstanceUid,
      uri: uri,
      instanceNumber: parseFloat(remoteGetValue(instance['0020,0013']))
    });
  });
  return seriesList;
}
/**
 * Retrieve a set of instances using a QIDO call
 * @param server
 * @param studyInstanceUid
 * @returns {{wadoUriRoot: String, studyInstanceUid: String, seriesList: Array}}
 */


OHIF.studies.services.REMOTE.Instances = function (server, studyInstanceUid) {
  var parameters = {
    PatientName: "",
    PatientID: "",
    AccessionNumber: "",
    SeriesInstanceUID: "",
    SeriesNumber: "",
    SOPClassUID: "",
    InstanceNumber: ""
  };
  var remote = new OrthancRemote(server.root, server.sourceAE);
  return {
    wadoUriRoot: server.wadoUriRoot,
    studyInstanceUid: studyInstanceUid,
    seriesList: resultDataToStudyMetadata(server, studyInstanceUid, remote.findInstances(server.modality, studyInstanceUid, null, parameters))
  };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"retrieveMetadata.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/remote/retrieveMetadata.js                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
let remoteGetValue;
module.watch(require("../../lib/remoteGetValue"), {
  remoteGetValue(v) {
    remoteGetValue = v;
  }

}, 1);
let parseFloatArray;
module.watch(require("../../lib/parseFloatArray"), {
  parseFloatArray(v) {
    parseFloatArray = v;
  }

}, 2);

/**
 * Parses the SourceImageSequence, if it exists, in order
 * to return a ReferenceSOPInstanceUID. The ReferenceSOPInstanceUID
 * is used to refer to this image in any accompanying DICOM-SR documents.
 *
 * @param instance
 * @returns {String} The ReferenceSOPInstanceUID
 */
function getSourceImageInstanceUid(instance) {
  // TODO= Parse the whole Source Image Sequence
  // This is a really poor workaround for now.
  // Later we should probably parse the whole sequence.
  var SourceImageSequence = remoteGetValue(instance['0008,2112']);

  if (SourceImageSequence && SourceImageSequence.Value && SourceImageSequence.Value.length) {
    return SourceImageSequence.Value[0]['0008,1155'].Value[0];
  }
}
/**
 * Parses result data from a WADO search into Study MetaData
 * Returns an object populated with study metadata, including the
 * series list.
 *
 * @param server
 * @param studyInstanceUid
 * @param resultData
 * @returns {{seriesList: Array, patientName: *, patientId: *, accessionNumber: *, studyDate: *, modalities: *, studyDescription: *, imageCount: *, studyInstanceUid: *}}
 */


function resultDataToStudyMetadata(server, studyInstanceUid, resultData) {
  var seriesMap = {};
  var seriesList = [];

  if (!resultData.length) {
    return;
  }

  var anInstance = resultData[0];

  if (!anInstance) {
    return;
  }

  var studyData = {
    seriesList: seriesList,
    patientName: remoteGetValue(anInstance['0010,0010']),
    patientId: remoteGetValue(anInstance['0010,0020']),
    accessionNumber: remoteGetValue(anInstance['0008,0050']),
    studyDate: remoteGetValue(anInstance['0008,0020']),
    modalities: remoteGetValue(anInstance['0008,0061']),
    studyDescription: remoteGetValue(anInstance['0008,1030']),
    imageCount: remoteGetValue(anInstance['0020,1208']),
    studyInstanceUid: remoteGetValue(anInstance['0020,000d'])
  };
  resultData.forEach(function (instance) {
    var seriesInstanceUid = remoteGetValue(instance['0020,000e']);
    var series = seriesMap[seriesInstanceUid];

    if (!series) {
      series = {
        seriesDescription: remoteGetValue(instance['0008,103e']),
        modality: remoteGetValue(instance['0008,0060']),
        seriesInstanceUid: seriesInstanceUid,
        seriesNumber: parseFloat(remoteGetValue(instance['0020,0011'])),
        instances: []
      };
      seriesMap[seriesInstanceUid] = series;
      seriesList.push(series);
    }

    var sopInstanceUid = remoteGetValue(instance['0008,0018']);
    var instanceSummary = {
      imageType: remoteGetValue(instance['0008,0008']),
      sopClassUid: remoteGetValue(instance['0008,0016']),
      sopInstanceUid: sopInstanceUid,
      instanceNumber: parseFloat(remoteGetValue(instance['0020,0013'])),
      imagePositionPatient: remoteGetValue(instance['0020,0032']),
      imageOrientationPatient: remoteGetValue(instance['0020,0037']),
      frameOfReferenceUID: remoteGetValue(instance['0020,0052']),
      sliceLocation: parseFloat(remoteGetValue(instance['0020,1041'])),
      samplesPerPixel: parseFloat(remoteGetValue(instance['0028,0002'])),
      photometricInterpretation: remoteGetValue(instance['0028,0004']),
      rows: parseFloat(remoteGetValue(instance['0028,0010'])),
      columns: parseFloat(remoteGetValue(instance['0028,0011'])),
      pixelSpacing: remoteGetValue(instance['0028,0030']),
      bitsAllocated: parseFloat(remoteGetValue(instance['0028,0100'])),
      bitsStored: parseFloat(remoteGetValue(instance['0028,0101'])),
      highBit: parseFloat(remoteGetValue(instance['0028,0102'])),
      pixelRepresentation: parseFloat(remoteGetValue(instance['0028,0103'])),
      windowCenter: remoteGetValue(instance['0028,1050']),
      windowWidth: remoteGetValue(instance['0028,1051']),
      rescaleIntercept: parseFloat(remoteGetValue(instance['0028,1052'])),
      rescaleSlope: parseFloat(remoteGetValue(instance['0028,1053'])),
      sourceImageInstanceUid: getSourceImageInstanceUid(instance),
      laterality: remoteGetValue(instance['0020,0062']),
      viewPosition: remoteGetValue(instance['0018,5101']),
      acquisitionDateTime: remoteGetValue(instance['0008,002A']),
      numberOfFrames: parseFloat(remoteGetValue(instance['0028,0008'])),
      frameIncrementPointer: remoteGetValue(instance['0028,0009']),
      frameTime: parseFloat(remoteGetValue(instance['0018,1063'])),
      frameTimeVector: parseFloatArray(remoteGetValue(instance['0018,1065'])),
      echoNumber: remoteGetValue(instance['0018,0086']),
      contrastBolusAgent: remoteGetValue(instance['0018,0010'])
    };
    var iid = instance['xxxx,0001'].Value;

    if (server.imageRendering === 'wadouri') {
      instanceSummary.wadouri = server.wadoUriRoot + '?requestType=WADO&studyUID=' + studyInstanceUid + '&seriesUID=' + seriesInstanceUid + '&objectUID=' + sopInstanceUid + "&contentType=application%2Fdicom";
    } else if (server.imageRendering == 'orthanc') {
      instanceSummary.wadouri = server.root + '/instances/' + iid + '/file';
    } else {
      instanceSummary.wadorsuri = server.wadoRoot + '/studies/' + studyInstanceUid + '/series/' + seriesInstanceUid + '/instances/' + sopInstanceUid + '/frames/1';
    }

    series.instances.push(instanceSummary);
  });
  console.log(studyData.seriesList[0].instances);
  return studyData;
}
/**
 * Retrieved Study MetaData from a DICOM server using a WADO call
 * @param server
 * @param studyInstanceUid
 * @returns {{seriesList: Array, patientName: *, patientId: *, accessionNumber: *, studyDate: *, modalities: *, studyDescription: *, imageCount: *, studyInstanceUid: *}}
 */


OHIF.studies.services.REMOTE.RetrieveMetadata = function (server, studyInstanceUid) {
  var remote = new OrthancRemote(server.root, server.sourceAE);
  var study = resultDataToStudyMetadata(server, studyInstanceUid, remote.retrieveMetadata(server.modality, studyInstanceUid));

  if (!study) {
    study = {};
  }

  study.wadoUriRoot = server.wadoUriRoot;
  study.studyInstanceUid = studyInstanceUid;
  return study;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"studies.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/remote/studies.js                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
let remoteGetValue;
module.watch(require("../../lib/remoteGetValue"), {
  remoteGetValue(v) {
    remoteGetValue = v;
  }

}, 1);

function resultDataToStudies(resultData) {
  const studies = [];
  resultData.forEach(function (study) {
    studies.push({
      studyInstanceUid: remoteGetValue(study['0020,000d']),
      // 00080005 = SpecificCharacterSet
      studyDate: remoteGetValue(study['0008,0020']),
      studyTime: remoteGetValue(study['0008,0030']),
      accessionNumber: remoteGetValue(study['0008,0050']),
      referringPhysicianName: remoteGetValue(study['0008,0090']),
      // 00081190 = URL
      patientName: remoteGetValue(study['0010,0010']),
      patientId: remoteGetValue(study['0010,0020']),
      patientBirthdate: remoteGetValue(study['0010,0030']),
      patientSex: remoteGetValue(study['0010,0040']),
      studyId: remoteGetValue(study['0020,0010']),
      numberOfStudyRelatedSeries: parseFloat(remoteGetValue(study['0020,1206'])),
      numberOfStudyRelatedInstances: parseFloat(remoteGetValue(study['0020,1208'])),
      studyDescription: remoteGetValue(study['0008,1030']),
      modalities: remoteGetValue(study['0008,0061'])
    });
  });
  return studies;
}

OHIF.studies.services.REMOTE.Studies = function (server, filter) {
  const parameters = {
    studyInstanceUID: filter.studyInstanceUid || '',
    PatientName: filter.patientName ? filter.patientName : '',
    PatientID: filter.patientId,
    AccessionNumber: filter.accessionNumber ? filter.accessionNumber : '',
    StudyDescription: '',
    StudyDate: '',
    StudyTime: '',
    ReferringPhysicianName: '',
    PatientBirthDate: '',
    PatientSex: '',
    StudyID: '',
    NumberOfStudyRelatedSeries: '',
    NumberOfStudyRelatedInstances: '',
    ModalitiesInStudy: ''
  };
  const remote = new OrthancRemote(server.root, server.sourceAE);
  const data = remote.findStudies(server.modality, parameters);
  return resultDataToStudies(data.results);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"wado":{"retrieveMetadata.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/ohif_studies/imports/server/services/wado/retrieveMetadata.js                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
let parseFloatArray;
module.watch(require("../../lib/parseFloatArray"), {
  parseFloatArray(v) {
    parseFloatArray = v;
  }

}, 1);

/**
 * Simple cache schema for retrieved color palettes.
 */
const paletteColorCache = {
  count: 0,
  maxAge: 24 * 60 * 60 * 1000,
  // 24h cache?
  entries: {},
  isValidUID: function (paletteUID) {
    return typeof paletteUID === 'string' && paletteUID.length > 0;
  },
  get: function (paletteUID) {
    let entry = null;

    if (this.entries.hasOwnProperty(paletteUID)) {
      entry = this.entries[paletteUID]; // check how the entry is...

      if (Date.now() - entry.time > this.maxAge) {
        // entry is too old... remove entry.
        delete this.entries[paletteUID];
        this.count--;
        entry = null;
      }
    }

    return entry;
  },
  add: function (entry) {
    if (this.isValidUID(entry.uid)) {
      let paletteUID = entry.uid;

      if (this.entries.hasOwnProperty(paletteUID) !== true) {
        this.count++; // increment cache entry count...
      }

      entry.time = Date.now();
      this.entries[paletteUID] = entry; // @TODO: Add logic to get rid of old entries and reduce memory usage...
    }
  }
};
/**
 * Creates a URL for a WADO search
 *
 * @param server
 * @param studyInstanceUid
 * @returns {string}
 */

function buildUrl(server, studyInstanceUid) {
  return server.wadoRoot + '/studies/' + studyInstanceUid + '/metadata';
}
/** Returns a WADO url for an instance
 *
 * @param studyInstanceUid
 * @param seriesInstanceUid
 * @param sopInstanceUid
 * @returns  {string}
 */


function buildInstanceWadoUrl(server, studyInstanceUid, seriesInstanceUid, sopInstanceUid) {
  const params = [];
  params.push('requestType=WADO');
  params.push(`studyUID=${studyInstanceUid}`);
  params.push(`seriesUID=${seriesInstanceUid}`);
  params.push(`objectUID=${sopInstanceUid}`);
  params.push('contentType=application%2Fdicom');
  params.push('transferSyntax=*');
  return `${server.wadoUriRoot}?${params.join('&')}`;
}

function buildInstanceWadoRsUri(server, studyInstanceUid, seriesInstanceUid, sopInstanceUid) {
  return `${server.wadoRoot}/studies/${studyInstanceUid}/series/${seriesInstanceUid}/instances/${sopInstanceUid}`;
}

function buildInstanceFrameWadoRsUri(server, studyInstanceUid, seriesInstanceUid, sopInstanceUid, frame) {
  const baseWadoRsUri = buildInstanceWadoRsUri(server, studyInstanceUid, seriesInstanceUid, sopInstanceUid);
  frame = frame != null || 1;
  return `${baseWadoRsUri}/frames/${frame}`;
}
/**
 * Parses the SourceImageSequence, if it exists, in order
 * to return a ReferenceSOPInstanceUID. The ReferenceSOPInstanceUID
 * is used to refer to this image in any accompanying DICOM-SR documents.
 *
 * @param instance
 * @returns {String} The ReferenceSOPInstanceUID
 */


function getSourceImageInstanceUid(instance) {
  // TODO= Parse the whole Source Image Sequence
  // This is a really poor workaround for now.
  // Later we should probably parse the whole sequence.
  var SourceImageSequence = instance['00082112'];

  if (SourceImageSequence && SourceImageSequence.Value && SourceImageSequence.Value.length) {
    return SourceImageSequence.Value[0]['00081155'].Value[0];
  }
}

function getPaletteColor(server, instance, tag, lutDescriptor) {
  const lut = [];
  const numLutEntries = lutDescriptor[0];
  const bits = lutDescriptor[2];
  const uri = WADOProxy.convertURL(instance[tag].BulkDataURI, server);
  const data = DICOMWeb.getBulkData(uri);

  for (var i = 0; i < numLutEntries; i++) {
    if (bits === 16) {
      lut[i] = data.readUInt16LE(i * 2);
    } else {
      lut[i] = data.readUInt8(i);
    }
  }

  return lut;
}
/**
 * Fetch palette colors for instances with "PALETTE COLOR" photometricInterpretation.
 *
 * @param server {Object} Current server;
 * @param instance {Object} The retrieved instance metadata;
 * @returns {String} The ReferenceSOPInstanceUID
 */


function getPaletteColors(server, instance, lutDescriptor) {
  let entry = null,
      paletteUID = DICOMWeb.getString(instance['00281199']);

  if (paletteColorCache.isValidUID(paletteUID)) {
    entry = paletteColorCache.get(paletteUID);
  } else {
    paletteUID = null;
  }

  if (!entry) {
    // no entry on cache... Fetch remote data.
    try {
      let r, g, b;
      r = getPaletteColor(server, instance, '00281201', lutDescriptor);
      g = getPaletteColor(server, instance, '00281202', lutDescriptor);
      ;
      b = getPaletteColor(server, instance, '00281203', lutDescriptor);
      ;
      entry = {
        red: r,
        green: g,
        blue: b
      };

      if (paletteUID !== null) {
        // when paletteUID is present, the entry can be cached...
        entry.uid = paletteUID;
        paletteColorCache.add(entry);
      }
    } catch (error) {
      OHIF.log.error(`(${error.name}) ${error.message}`);
    }
  }

  return entry;
}

function getFrameIncrementPointer(element) {
  const frameIncrementPointerNames = {
    '00181065': 'frameTimeVector',
    '00181063': 'frameTime'
  };

  if (!element || !element.Value || !element.Value.length) {
    return;
  }

  const value = element.Value[0];
  return frameIncrementPointerNames[value];
}

function getRadiopharmaceuticalInfo(instance) {
  const modality = DICOMWeb.getString(instance['00080060']);

  if (modality !== 'PT') {
    return;
  }

  const radiopharmaceuticalInfo = instance['00540016'];

  if (radiopharmaceuticalInfo === undefined || !radiopharmaceuticalInfo.Value || !radiopharmaceuticalInfo.Value.length) {
    return;
  }

  const firstPetRadiopharmaceuticalInfo = radiopharmaceuticalInfo.Value[0];
  return {
    radiopharmaceuticalStartTime: DICOMWeb.getString(firstPetRadiopharmaceuticalInfo['00181072']),
    radionuclideTotalDose: DICOMWeb.getNumber(firstPetRadiopharmaceuticalInfo['00181074']),
    radionuclideHalfLife: DICOMWeb.getNumber(firstPetRadiopharmaceuticalInfo['00181075'])
  };
}
/**
 * Parses result data from a WADO search into Study MetaData
 * Returns an object populated with study metadata, including the
 * series list.
 *
 * @param server
 * @param studyInstanceUid
 * @param resultData
 * @returns {{seriesList: Array, patientName: *, patientId: *, accessionNumber: *, studyDate: *, modalities: *, studyDescription: *, imageCount: *, studyInstanceUid: *}}
 */


function resultDataToStudyMetadata(server, studyInstanceUid, resultData) {
  var seriesMap = {};
  var seriesList = [];

  if (!resultData.length) {
    return;
  }

  var anInstance = resultData[0];

  if (!anInstance) {
    return;
  }

  var studyData = {
    seriesList: seriesList,
    patientName: DICOMWeb.getName(anInstance['00100010']),
    patientId: DICOMWeb.getString(anInstance['00100020']),
    patientAge: DICOMWeb.getNumber(anInstance['00101010']),
    patientSize: DICOMWeb.getNumber(anInstance['00101020']),
    patientWeight: DICOMWeb.getNumber(anInstance['00101030']),
    accessionNumber: DICOMWeb.getString(anInstance['00080050']),
    studyDate: DICOMWeb.getString(anInstance['00080020']),
    modalities: DICOMWeb.getString(anInstance['00080061']),
    studyDescription: DICOMWeb.getString(anInstance['00081030']),
    imageCount: DICOMWeb.getString(anInstance['00201208']),
    studyInstanceUid: DICOMWeb.getString(anInstance['0020000D']),
    institutionName: DICOMWeb.getString(anInstance['00080080'])
  };
  resultData.forEach(function (instance) {
    var seriesInstanceUid = DICOMWeb.getString(instance['0020000E']);
    var series = seriesMap[seriesInstanceUid];

    if (!series) {
      series = {
        seriesDescription: DICOMWeb.getString(instance['0008103E']),
        modality: DICOMWeb.getString(instance['00080060']),
        seriesInstanceUid: seriesInstanceUid,
        seriesNumber: DICOMWeb.getNumber(instance['00200011']),
        seriesDate: DICOMWeb.getString(instance['00080021']),
        seriesTime: DICOMWeb.getString(instance['00080031']),
        instances: []
      };
      seriesMap[seriesInstanceUid] = series;
      seriesList.push(series);
    }

    var sopInstanceUid = DICOMWeb.getString(instance['00080018']);
    const wadouri = buildInstanceWadoUrl(server, studyInstanceUid, seriesInstanceUid, sopInstanceUid);
    const baseWadoRsUri = buildInstanceWadoRsUri(server, studyInstanceUid, seriesInstanceUid, sopInstanceUid);
    const wadorsuri = buildInstanceFrameWadoRsUri(server, studyInstanceUid, seriesInstanceUid, sopInstanceUid);
    var instanceSummary = {
      imageType: DICOMWeb.getString(instance['00080008']),
      sopClassUid: DICOMWeb.getString(instance['00080016']),
      modality: DICOMWeb.getString(instance['00080060']),
      sopInstanceUid: sopInstanceUid,
      instanceNumber: DICOMWeb.getNumber(instance['00200013']),
      imagePositionPatient: DICOMWeb.getString(instance['00200032']),
      imageOrientationPatient: DICOMWeb.getString(instance['00200037']),
      frameOfReferenceUID: DICOMWeb.getString(instance['00200052']),
      sliceLocation: DICOMWeb.getNumber(instance['00201041']),
      samplesPerPixel: DICOMWeb.getNumber(instance['00280002']),
      photometricInterpretation: DICOMWeb.getString(instance['00280004']),
      planarConfiguration: DICOMWeb.getNumber(instance['00280006']),
      rows: DICOMWeb.getNumber(instance['00280010']),
      columns: DICOMWeb.getNumber(instance['00280011']),
      pixelSpacing: DICOMWeb.getString(instance['00280030']),
      pixelAspectRatio: DICOMWeb.getString(instance['00280034']),
      bitsAllocated: DICOMWeb.getNumber(instance['00280100']),
      bitsStored: DICOMWeb.getNumber(instance['00280101']),
      highBit: DICOMWeb.getNumber(instance['00280102']),
      pixelRepresentation: DICOMWeb.getNumber(instance['00280103']),
      smallestPixelValue: DICOMWeb.getNumber(instance['00280106']),
      largestPixelValue: DICOMWeb.getNumber(instance['00280107']),
      windowCenter: DICOMWeb.getString(instance['00281050']),
      windowWidth: DICOMWeb.getString(instance['00281051']),
      rescaleIntercept: DICOMWeb.getNumber(instance['00281052']),
      rescaleSlope: DICOMWeb.getNumber(instance['00281053']),
      rescaleType: DICOMWeb.getNumber(instance['00281054']),
      sourceImageInstanceUid: getSourceImageInstanceUid(instance),
      laterality: DICOMWeb.getString(instance['00200062']),
      viewPosition: DICOMWeb.getString(instance['00185101']),
      acquisitionDateTime: DICOMWeb.getString(instance['0008002A']),
      numberOfFrames: DICOMWeb.getNumber(instance['00280008']),
      frameIncrementPointer: getFrameIncrementPointer(instance['00280009']),
      frameTime: DICOMWeb.getNumber(instance['00181063']),
      frameTimeVector: parseFloatArray(DICOMWeb.getString(instance['00181065'])),
      sliceThickness: DICOMWeb.getNumber(instance['00180050']),
      lossyImageCompression: DICOMWeb.getString(instance['00282110']),
      derivationDescription: DICOMWeb.getString(instance['00282111']),
      lossyImageCompressionRatio: DICOMWeb.getString(instance['00282112']),
      lossyImageCompressionMethod: DICOMWeb.getString(instance['00282114']),
      echoNumber: DICOMWeb.getString(instance['00180086']),
      contrastBolusAgent: DICOMWeb.getString(instance['00180010']),
      radiopharmaceuticalInfo: getRadiopharmaceuticalInfo(instance),
      baseWadoRsUri: baseWadoRsUri,
      wadouri: WADOProxy.convertURL(wadouri, server),
      wadorsuri: WADOProxy.convertURL(wadorsuri, server),
      imageRendering: server.imageRendering,
      thumbnailRendering: server.thumbnailRendering
    }; // Get additional information if the instance uses "PALETTE COLOR" photometric interpretation

    if (instanceSummary.photometricInterpretation === 'PALETTE COLOR') {
      const redPaletteColorLookupTableDescriptor = parseFloatArray(DICOMWeb.getString(instance['00281101']));
      const greenPaletteColorLookupTableDescriptor = parseFloatArray(DICOMWeb.getString(instance['00281102']));
      const bluePaletteColorLookupTableDescriptor = parseFloatArray(DICOMWeb.getString(instance['00281103']));
      const palettes = getPaletteColors(server, instance, redPaletteColorLookupTableDescriptor);

      if (palettes) {
        if (palettes.uid) {
          instanceSummary.paletteColorLookupTableUID = palettes.uid;
        }

        instanceSummary.redPaletteColorLookupTableData = palettes.red;
        instanceSummary.greenPaletteColorLookupTableData = palettes.green;
        instanceSummary.bluePaletteColorLookupTableData = palettes.blue;
        instanceSummary.redPaletteColorLookupTableDescriptor = redPaletteColorLookupTableDescriptor;
        instanceSummary.greenPaletteColorLookupTableDescriptor = greenPaletteColorLookupTableDescriptor;
        instanceSummary.bluePaletteColorLookupTableDescriptor = bluePaletteColorLookupTableDescriptor;
      }
    }

    series.instances.push(instanceSummary);
  });
  return studyData;
}
/**
 * Retrieved Study MetaData from a DICOM server using a WADO call
 * @param server
 * @param studyInstanceUid
 * @returns {{seriesList: Array, patientName: *, patientId: *, accessionNumber: *, studyDate: *, modalities: *, studyDescription: *, imageCount: *, studyInstanceUid: *}}
 */


OHIF.studies.services.WADO.RetrieveMetadata = function (server, studyInstanceUid) {
  var url = buildUrl(server, studyInstanceUid);

  try {
    var result = DICOMWeb.getJSON(url, server.requestOptions);
    var study = resultDataToStudyMetadata(server, studyInstanceUid, result.data);

    if (!study) {
      study = {};
    }

    study.wadoUriRoot = server.wadoUriRoot;
    study.studyInstanceUid = studyInstanceUid;
    return study;
  } catch (error) {
    OHIF.log.trace();
    throw error;
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/node_modules/meteor/ohif:studies/both/main.js");
require("/node_modules/meteor/ohif:studies/server/main.js");

/* Exports */
Package._define("ohif:studies");

})();

//# sourceURL=meteor://💻app/packages/ohif_studies.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL2JvdGgvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6c3R1ZGllcy9pbXBvcnRzL3NlcnZlci9saWIvZW5jb2RlUXVlcnlEYXRhLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvbGliL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvbGliL3BhcnNlRmxvYXRBcnJheS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL2ltcG9ydHMvc2VydmVyL2xpYi9yZW1vdGVHZXRWYWx1ZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL2ltcG9ydHMvc2VydmVyL21ldGhvZHMvZ2V0U3R1ZHlNZXRhZGF0YS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL2ltcG9ydHMvc2VydmVyL21ldGhvZHMvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6c3R1ZGllcy9pbXBvcnRzL3NlcnZlci9tZXRob2RzL3N0dWR5bGlzdFNlYXJjaC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL2ltcG9ydHMvc2VydmVyL3NlcnZpY2VzL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvc2VydmljZXMvbmFtZXNwYWNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvc2VydmljZXMvZGltc2UvaW5zdGFuY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvc2VydmljZXMvZGltc2UvcmV0cmlldmVNZXRhZGF0YS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL2ltcG9ydHMvc2VydmVyL3NlcnZpY2VzL2RpbXNlL3NldHVwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvc2VydmljZXMvZGltc2Uvc3R1ZGllcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL2ltcG9ydHMvc2VydmVyL3NlcnZpY2VzL3FpZG8vaW5zdGFuY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvc2VydmljZXMvcWlkby9zdHVkaWVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvc2VydmljZXMvcmVtb3RlL2luc3RhbmNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzdHVkaWVzL2ltcG9ydHMvc2VydmVyL3NlcnZpY2VzL3JlbW90ZS9yZXRyaWV2ZU1ldGFkYXRhLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnN0dWRpZXMvaW1wb3J0cy9zZXJ2ZXIvc2VydmljZXMvcmVtb3RlL3N0dWRpZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6c3R1ZGllcy9pbXBvcnRzL3NlcnZlci9zZXJ2aWNlcy93YWRvL3JldHJpZXZlTWV0YWRhdGEuanMiXSwibmFtZXMiOlsiT0hJRiIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsInYiLCJzdHVkaWVzIiwiZW5jb2RlUXVlcnlEYXRhIiwiZGF0YSIsInJldCIsImQiLCJwdXNoIiwiZW5jb2RlVVJJQ29tcG9uZW50Iiwiam9pbiIsImV4cG9ydCIsInBhcnNlRmxvYXRBcnJheSIsIm9iaiIsInJlc3VsdCIsIm9ianMiLCJzcGxpdCIsImkiLCJsZW5ndGgiLCJwYXJzZUZsb2F0IiwicmVtb3RlR2V0VmFsdWUiLCJWYWx1ZSIsIk1ldGVvciIsIm1ldGhvZHMiLCJHZXRTdHVkeU1ldGFkYXRhIiwic3R1ZHlJbnN0YW5jZVVpZCIsImxvZyIsImluZm8iLCJzZXJ2ZXIiLCJzZXJ2ZXJzIiwiZ2V0Q3VycmVudFNlcnZlciIsIkVycm9yIiwidHlwZSIsInNlcnZpY2VzIiwiV0FETyIsIlJldHJpZXZlTWV0YWRhdGEiLCJESU1TRSIsImVycm9yIiwidHJhY2UiLCJTdHVkeUxpc3RTZWFyY2giLCJmaWx0ZXIiLCJRSURPIiwiU3R1ZGllcyIsIlNlcnZpY2VzIiwiUkVNT1RFIiwicmVzdWx0RGF0YVRvU3R1ZHlNZXRhZGF0YSIsInJlc3VsdERhdGEiLCJzZXJpZXNNYXAiLCJzZXJpZXNMaXN0IiwiZm9yRWFjaCIsImluc3RhbmNlUmF3IiwiaW5zdGFuY2UiLCJ0b09iamVjdCIsInNlcmllc0luc3RhbmNlVWlkIiwic2VyaWVzIiwic2VyaWVzTnVtYmVyIiwiaW5zdGFuY2VzIiwicGVlcnMiLCJzZXJ2ZXJSb290IiwiaG9zdCIsInBvcnQiLCJzb3BJbnN0YW5jZVVpZCIsInVyaSIsInNvcENsYXNzVWlkIiwiaW5zdGFuY2VOdW1iZXIiLCJJbnN0YW5jZXMiLCJyZXRyaWV2ZUluc3RhbmNlcyIsImdldFZhbHVlIiwiZWxlbWVudCIsImRlZmF1bHRWYWx1ZSIsInZhbHVlIiwiZ2V0U291cmNlSW1hZ2VJbnN0YW5jZVVpZCIsIlNvdXJjZUltYWdlU2VxdWVuY2UiLCJhbkluc3RhbmNlIiwic3R1ZHlEYXRhIiwicGF0aWVudE5hbWUiLCJwYXRpZW50SWQiLCJwYXRpZW50QmlydGhEYXRlIiwicGF0aWVudFNleCIsImFjY2Vzc2lvbk51bWJlciIsInN0dWR5RGF0ZSIsIm1vZGFsaXRpZXMiLCJzdHVkeURlc2NyaXB0aW9uIiwiaW1hZ2VDb3VudCIsImluc3RpdHV0aW9uTmFtZSIsInNlcmllc0Rlc2NyaXB0aW9uIiwibW9kYWxpdHkiLCJpbnN0YW5jZVN1bW1hcnkiLCJpbWFnZVR5cGUiLCJpbWFnZVBvc2l0aW9uUGF0aWVudCIsImltYWdlT3JpZW50YXRpb25QYXRpZW50IiwiZnJhbWVPZlJlZmVyZW5jZVVJRCIsInNsaWNlVGhpY2tuZXNzIiwic2xpY2VMb2NhdGlvbiIsInRhYmxlUG9zaXRpb24iLCJzYW1wbGVzUGVyUGl4ZWwiLCJwaG90b21ldHJpY0ludGVycHJldGF0aW9uIiwicGxhbmFyQ29uZmlndXJhdGlvbiIsInJvd3MiLCJjb2x1bW5zIiwicGl4ZWxTcGFjaW5nIiwiYml0c0FsbG9jYXRlZCIsImJpdHNTdG9yZWQiLCJoaWdoQml0IiwicGl4ZWxSZXByZXNlbnRhdGlvbiIsIndpbmRvd0NlbnRlciIsIndpbmRvd1dpZHRoIiwicmVzY2FsZUludGVyY2VwdCIsInJlc2NhbGVTbG9wZSIsInNvdXJjZUltYWdlSW5zdGFuY2VVaWQiLCJsYXRlcmFsaXR5Iiwidmlld1Bvc2l0aW9uIiwiYWNxdWlzaXRpb25EYXRlVGltZSIsIm51bWJlck9mRnJhbWVzIiwiZnJhbWVJbmNyZW1lbnRQb2ludGVyIiwiZnJhbWVUaW1lIiwiZnJhbWVUaW1lVmVjdG9yIiwibG9zc3lJbWFnZUNvbXByZXNzaW9uIiwiZGVyaXZhdGlvbkRlc2NyaXB0aW9uIiwibG9zc3lJbWFnZUNvbXByZXNzaW9uUmF0aW8iLCJsb3NzeUltYWdlQ29tcHJlc3Npb25NZXRob2QiLCJzcGFjaW5nQmV0d2VlblNsaWNlcyIsImVjaG9OdW1iZXIiLCJjb250cmFzdEJvbHVzQWdlbnQiLCJ3YWRvdXJpIiwid2Fkb1VyaVJvb3QiLCJXQURPUHJveHkiLCJjb252ZXJ0VVJMIiwiYWN0aXZlU2VydmVyIiwic3VwcG9ydHNJbnN0YW5jZVJldHJpZXZhbEJ5U3R1ZHlVaWQiLCJyZXN1bHRzIiwicmV0cmlldmVJbnN0YW5jZXNCeVN0dWR5T25seSIsIkN1cnJlbnRTZXJ2ZXIiLCJzZXR1cERJTVNFIiwiY29ubmVjdGlvbiIsInJlc2V0IiwicGVlciIsImFkZFBlZXIiLCJzdGFydHVwIiwiZmluZCIsIm9ic2VydmUiLCJhZGRlZCIsImNoYW5nZWQiLCJtb21lbnQiLCJyZXN1bHREYXRhVG9TdHVkaWVzIiwic3R1ZHlSYXciLCJzdHVkeSIsInN0dWR5VGltZSIsInJlZmVycmluZ1BoeXNpY2lhbk5hbWUiLCJwYXRpZW50QmlydGhkYXRlIiwic3R1ZHlJZCIsImZpbHRlclN0dWR5RGF0ZSIsInN0dWR5RGF0ZUZyb20iLCJzdHVkeURhdGVUbyIsImNvbnZlcnREYXRlIiwiZGF0ZSIsImZvcm1hdCIsImRhdGVGcm9tIiwiZGF0ZVRvIiwic3R1ZHlVaWRzIiwiQXJyYXkiLCJpc0FycmF5IiwicmVwbGFjZSIsInBhcmFtZXRlcnMiLCJtb2RhbGl0aWVzSW5TdHVkeSIsInJldHJpZXZlU3R1ZGllcyIsImJ1aWxkVXJsIiwicWlkb1Jvb3QiLCJESUNPTVdlYiIsImdldFN0cmluZyIsInVybCIsImdldEpTT04iLCJyZXF1ZXN0T3B0aW9ucyIsImRhdGVUb1N0cmluZyIsInllYXIiLCJnZXRGdWxsWWVhciIsInRvU3RyaW5nIiwibW9udGgiLCJnZXRNb250aCIsImRheSIsImdldERhdGUiLCJyZXBlYXQiLCJjb25jYXQiLCJmaWx0ZXJUb1FJRE9VUkwiLCJjb21tYVNlcGFyYXRlZEZpZWxkcyIsIlBhdGllbnROYW1lIiwiUGF0aWVudElEIiwiQWNjZXNzaW9uTnVtYmVyIiwiU3R1ZHlEZXNjcmlwdGlvbiIsIk1vZGFsaXRpZXNJblN0dWR5IiwibGltaXQiLCJpbmNsdWRlZmllbGQiLCJxaWRvU3VwcG9ydHNJbmNsdWRlRmllbGQiLCJEYXRlIiwiU3R1ZHlEYXRlIiwiU3R1ZHlJbnN0YW5jZVVJRCIsImdldE5hbWUiLCJudW1iZXJPZlN0dWR5UmVsYXRlZFNlcmllcyIsIm51bWJlck9mU3R1ZHlSZWxhdGVkSW5zdGFuY2VzIiwiZ2V0TW9kYWxpdGllcyIsIlNlcmllc0luc3RhbmNlVUlEIiwiU2VyaWVzTnVtYmVyIiwiU09QQ2xhc3NVSUQiLCJJbnN0YW5jZU51bWJlciIsInJlbW90ZSIsIk9ydGhhbmNSZW1vdGUiLCJyb290Iiwic291cmNlQUUiLCJmaW5kSW5zdGFuY2VzIiwiaWlkIiwiaW1hZ2VSZW5kZXJpbmciLCJ3YWRvcnN1cmkiLCJ3YWRvUm9vdCIsImNvbnNvbGUiLCJyZXRyaWV2ZU1ldGFkYXRhIiwic3R1ZHlJbnN0YW5jZVVJRCIsIlN0dWR5VGltZSIsIlJlZmVycmluZ1BoeXNpY2lhbk5hbWUiLCJQYXRpZW50QmlydGhEYXRlIiwiUGF0aWVudFNleCIsIlN0dWR5SUQiLCJOdW1iZXJPZlN0dWR5UmVsYXRlZFNlcmllcyIsIk51bWJlck9mU3R1ZHlSZWxhdGVkSW5zdGFuY2VzIiwiZmluZFN0dWRpZXMiLCJwYWxldHRlQ29sb3JDYWNoZSIsImNvdW50IiwibWF4QWdlIiwiZW50cmllcyIsImlzVmFsaWRVSUQiLCJwYWxldHRlVUlEIiwiZ2V0IiwiZW50cnkiLCJoYXNPd25Qcm9wZXJ0eSIsIm5vdyIsInRpbWUiLCJhZGQiLCJ1aWQiLCJidWlsZEluc3RhbmNlV2Fkb1VybCIsInBhcmFtcyIsImJ1aWxkSW5zdGFuY2VXYWRvUnNVcmkiLCJidWlsZEluc3RhbmNlRnJhbWVXYWRvUnNVcmkiLCJmcmFtZSIsImJhc2VXYWRvUnNVcmkiLCJnZXRQYWxldHRlQ29sb3IiLCJ0YWciLCJsdXREZXNjcmlwdG9yIiwibHV0IiwibnVtTHV0RW50cmllcyIsImJpdHMiLCJCdWxrRGF0YVVSSSIsImdldEJ1bGtEYXRhIiwicmVhZFVJbnQxNkxFIiwicmVhZFVJbnQ4IiwiZ2V0UGFsZXR0ZUNvbG9ycyIsInIiLCJnIiwiYiIsInJlZCIsImdyZWVuIiwiYmx1ZSIsIm5hbWUiLCJtZXNzYWdlIiwiZ2V0RnJhbWVJbmNyZW1lbnRQb2ludGVyIiwiZnJhbWVJbmNyZW1lbnRQb2ludGVyTmFtZXMiLCJnZXRSYWRpb3BoYXJtYWNldXRpY2FsSW5mbyIsInJhZGlvcGhhcm1hY2V1dGljYWxJbmZvIiwidW5kZWZpbmVkIiwiZmlyc3RQZXRSYWRpb3BoYXJtYWNldXRpY2FsSW5mbyIsInJhZGlvcGhhcm1hY2V1dGljYWxTdGFydFRpbWUiLCJyYWRpb251Y2xpZGVUb3RhbERvc2UiLCJnZXROdW1iZXIiLCJyYWRpb251Y2xpZGVIYWxmTGlmZSIsInBhdGllbnRBZ2UiLCJwYXRpZW50U2l6ZSIsInBhdGllbnRXZWlnaHQiLCJzZXJpZXNEYXRlIiwic2VyaWVzVGltZSIsInBpeGVsQXNwZWN0UmF0aW8iLCJzbWFsbGVzdFBpeGVsVmFsdWUiLCJsYXJnZXN0UGl4ZWxWYWx1ZSIsInJlc2NhbGVUeXBlIiwidGh1bWJuYWlsUmVuZGVyaW5nIiwicmVkUGFsZXR0ZUNvbG9yTG9va3VwVGFibGVEZXNjcmlwdG9yIiwiZ3JlZW5QYWxldHRlQ29sb3JMb29rdXBUYWJsZURlc2NyaXB0b3IiLCJibHVlUGFsZXR0ZUNvbG9yTG9va3VwVGFibGVEZXNjcmlwdG9yIiwicGFsZXR0ZXMiLCJwYWxldHRlQ29sb3JMb29rdXBUYWJsZVVJRCIsInJlZFBhbGV0dGVDb2xvckxvb2t1cFRhYmxlRGF0YSIsImdyZWVuUGFsZXR0ZUNvbG9yTG9va3VwVGFibGVEYXRhIiwiYmx1ZVBhbGV0dGVDb2xvckxvb2t1cFRhYmxlRGF0YSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsSUFBSjtBQUFTQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDSCxPQUFLSSxDQUFMLEVBQU87QUFBQ0osV0FBS0ksQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUVUSixLQUFLSyxPQUFMLEdBQWUsRUFBZjs7QUFFQUYsUUFBUSxpQkFBUixFOzs7Ozs7Ozs7OztBQ0pBQSxRQUFRLG1CQUFSLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiO0FBQStCRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiO0FBQW1DRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQWxFOzs7Ozs7O0FBT0FHLGtCQUFrQixVQUFTQyxJQUFULEVBQWU7QUFDN0IsTUFBSUMsTUFBTSxFQUFWOztBQUVBLE9BQUssSUFBSUMsQ0FBVCxJQUFjRixJQUFkLEVBQW9CO0FBQ2hCLFFBQUlBLEtBQUtFLENBQUwsQ0FBSixFQUFhO0FBQ1RELFVBQUlFLElBQUosQ0FBU0MsbUJBQW1CRixDQUFuQixJQUF3QixHQUF4QixHQUE4QkUsbUJBQW1CSixLQUFLRSxDQUFMLENBQW5CLENBQXZDO0FBQ0g7QUFDSjs7QUFFRCxTQUFPRCxJQUFJSSxJQUFKLENBQVMsR0FBVCxDQUFQO0FBQ0gsQ0FWRCxDOzs7Ozs7Ozs7OztBQ1BBWCxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUJBQVIsQ0FBYjtBQUE2Q0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBN0NGLE9BQU9ZLE1BQVAsQ0FBYztBQUFDQyxtQkFBZ0IsTUFBSUE7QUFBckIsQ0FBZDs7QUFBTyxNQUFNQSxrQkFBa0IsVUFBU0MsR0FBVCxFQUFjO0FBQ3pDLE1BQUlDLFNBQVMsRUFBYjs7QUFFQSxNQUFJLENBQUNELEdBQUwsRUFBVTtBQUNOLFdBQU9DLE1BQVA7QUFDSDs7QUFFRCxNQUFJQyxPQUFPRixJQUFJRyxLQUFKLENBQVUsSUFBVixDQUFYOztBQUNBLE9BQUssSUFBSUMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJRixLQUFLRyxNQUF6QixFQUFpQ0QsR0FBakMsRUFBc0M7QUFDbENILFdBQU9OLElBQVAsQ0FBWVcsV0FBV0osS0FBS0UsQ0FBTCxDQUFYLENBQVo7QUFDSDs7QUFFRCxTQUFPSCxNQUFQO0FBQ0gsQ0FiTSxDOzs7Ozs7Ozs7OztBQ0FQZixPQUFPWSxNQUFQLENBQWM7QUFBQ1Msa0JBQWUsTUFBSUE7QUFBcEIsQ0FBZDs7QUFBTyxNQUFNQSxpQkFBaUIsVUFBU1AsR0FBVCxFQUFjO0FBQzFDLFNBQU9BLE1BQU1BLElBQUlRLEtBQVYsR0FBa0IsSUFBekI7QUFDRCxDQUZNLEM7Ozs7Ozs7Ozs7O0FDQVAsSUFBSUMsTUFBSjtBQUFXdkIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDcUIsU0FBT3BCLENBQVAsRUFBUztBQUFDb0IsYUFBT3BCLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUosSUFBSjtBQUFTQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDSCxPQUFLSSxDQUFMLEVBQU87QUFBQ0osV0FBS0ksQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUduRm9CLE9BQU9DLE9BQVAsQ0FBZTtBQUNYOzs7O0FBSUFDLG9CQUFrQixVQUFTQyxnQkFBVCxFQUEyQjtBQUN6QzNCLFNBQUs0QixHQUFMLENBQVNDLElBQVQsQ0FBYyxzQkFBZCxFQUFzQ0YsZ0JBQXRDLEVBRHlDLENBR3pDO0FBQ0E7O0FBQ0EsVUFBTUcsU0FBUzlCLEtBQUsrQixPQUFMLENBQWFDLGdCQUFiLEVBQWY7O0FBRUEsUUFBSSxDQUFDRixNQUFMLEVBQWE7QUFDVCxZQUFNLElBQUlOLE9BQU9TLEtBQVgsQ0FBaUIsd0JBQWpCLEVBQTJDLHFFQUEzQyxDQUFOO0FBQ0g7O0FBRUQsUUFBSTtBQUNBLFVBQUlILE9BQU9JLElBQVAsS0FBZ0IsVUFBcEIsRUFBZ0M7QUFDNUIsZUFBT2xDLEtBQUtLLE9BQUwsQ0FBYThCLFFBQWIsQ0FBc0JDLElBQXRCLENBQTJCQyxnQkFBM0IsQ0FBNENQLE1BQTVDLEVBQW9ESCxnQkFBcEQsQ0FBUDtBQUNILE9BRkQsTUFFTyxJQUFJRyxPQUFPSSxJQUFQLEtBQWdCLE9BQXBCLEVBQTZCO0FBQ2hDLGVBQU9sQyxLQUFLSyxPQUFMLENBQWE4QixRQUFiLENBQXNCRyxLQUF0QixDQUE0QkQsZ0JBQTVCLENBQTZDVixnQkFBN0MsQ0FBUDtBQUNIO0FBQ0osS0FORCxDQU1FLE9BQU9ZLEtBQVAsRUFBYztBQUNadkMsV0FBSzRCLEdBQUwsQ0FBU1ksS0FBVDtBQUVBLFlBQU1ELEtBQU47QUFDSDtBQUNKO0FBM0JVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNIQXRDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiO0FBQStDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0EvQyxJQUFJcUIsTUFBSjtBQUFXdkIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDcUIsU0FBT3BCLENBQVAsRUFBUztBQUFDb0IsYUFBT3BCLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUosSUFBSjtBQUFTQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDSCxPQUFLSSxDQUFMLEVBQU87QUFBQ0osV0FBS0ksQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUduRm9CLE9BQU9DLE9BQVAsQ0FBZTtBQUNYOzs7OztBQUtBZ0Isa0JBQWdCQyxNQUFoQixFQUF3QjtBQUNwQjtBQUNBO0FBQ0EsVUFBTVosU0FBUzlCLEtBQUsrQixPQUFMLENBQWFDLGdCQUFiLEVBQWY7O0FBRUEsUUFBSSxDQUFDRixNQUFMLEVBQWE7QUFDVCxZQUFNLElBQUlOLE9BQU9TLEtBQVgsQ0FBaUIsd0JBQWpCLEVBQTJDLHFFQUEzQyxDQUFOO0FBQ0g7O0FBRUQsUUFBSTtBQUNBLFVBQUlILE9BQU9JLElBQVAsS0FBZ0IsVUFBcEIsRUFBZ0M7QUFDNUIsZUFBT2xDLEtBQUtLLE9BQUwsQ0FBYThCLFFBQWIsQ0FBc0JRLElBQXRCLENBQTJCQyxPQUEzQixDQUFtQ2QsTUFBbkMsRUFBMkNZLE1BQTNDLENBQVA7QUFDSCxPQUZELE1BRU8sSUFBSVosT0FBT0ksSUFBUCxLQUFnQixPQUFwQixFQUE2QjtBQUNoQyxlQUFPbEMsS0FBS0ssT0FBTCxDQUFhOEIsUUFBYixDQUFzQkcsS0FBdEIsQ0FBNEJNLE9BQTVCLENBQW9DRixNQUFwQyxDQUFQO0FBQ0g7QUFDSixLQU5ELENBTUUsT0FBT0gsS0FBUCxFQUFjO0FBQ1p2QyxXQUFLNEIsR0FBTCxDQUFTWSxLQUFUO0FBRUEsWUFBTUQsS0FBTjtBQUNIO0FBQ0o7O0FBMUJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNIQXRDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiO0FBQXdDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEscUJBQVIsQ0FBYjtBQUE2Q0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1CQUFSLENBQWI7QUFBMkNGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw0QkFBUixDQUFiO0FBQW9ERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYjtBQUE4Q0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWI7QUFBNENGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiO0FBQXFERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYjtBQUEwQ0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWI7QUFBK0NGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiO0FBQTZDRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsOEJBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0F6YyxJQUFJSCxJQUFKO0FBQVNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNILE9BQUtJLENBQUwsRUFBTztBQUFDSixXQUFLSSxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBRVQsTUFBTXlDLFdBQVcsRUFBakI7QUFDQUEsU0FBU0YsSUFBVCxHQUFnQixFQUFoQjtBQUNBRSxTQUFTVCxJQUFULEdBQWdCLEVBQWhCO0FBQ0FTLFNBQVNQLEtBQVQsR0FBaUIsRUFBakI7QUFDQU8sU0FBU0MsTUFBVCxHQUFrQixFQUFsQjtBQUVBOUMsS0FBS0ssT0FBTCxDQUFhOEIsUUFBYixHQUF3QlUsUUFBeEI7O0FBRUF2QixpQkFBaUIsVUFBU1AsR0FBVCxFQUFjO0FBQzNCLFNBQU9BLE1BQU1BLElBQUlRLEtBQVYsR0FBa0IsSUFBekI7QUFDSCxDQUZELEM7Ozs7Ozs7Ozs7O0FDVkEsSUFBSXZCLElBQUo7QUFBU0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ0gsT0FBS0ksQ0FBTCxFQUFPO0FBQUNKLFdBQUtJLENBQUw7QUFBTzs7QUFBaEIsQ0FBekMsRUFBMkQsQ0FBM0Q7O0FBRVQ7Ozs7Ozs7QUFPQSxTQUFTMkMseUJBQVQsQ0FBbUNDLFVBQW5DLEVBQStDckIsZ0JBQS9DLEVBQWlFO0FBQzdELFFBQU1zQixZQUFZLEVBQWxCO0FBQ0EsUUFBTUMsYUFBYSxFQUFuQjtBQUVBRixhQUFXRyxPQUFYLENBQW1CLFVBQVNDLFdBQVQsRUFBc0I7QUFDckMsVUFBTUMsV0FBV0QsWUFBWUUsUUFBWixFQUFqQixDQURxQyxDQUVyQztBQUNBO0FBQ0E7O0FBQ0EsVUFBTUMsb0JBQW9CRixTQUFTLFVBQVQsQ0FBMUI7QUFDQSxRQUFJRyxTQUFTUCxVQUFVTSxpQkFBVixDQUFiLENBTnFDLENBUXJDO0FBQ0E7O0FBQ0EsUUFBSSxDQUFDQyxNQUFMLEVBQWE7QUFDVEEsZUFBUztBQUNMRCwyQkFBbUJBLGlCQURkO0FBRUxFLHNCQUFjSixTQUFTLFVBQVQsQ0FGVDtBQUdMSyxtQkFBVztBQUhOLE9BQVQsQ0FEUyxDQU9UOztBQUNBVCxnQkFBVU0saUJBQVYsSUFBK0JDLE1BQS9CO0FBQ0FOLGlCQUFXeEMsSUFBWCxDQUFnQjhDLE1BQWhCO0FBQ0gsS0FwQm9DLENBc0JyQzs7O0FBQ0EsVUFBTTFCLFNBQVM5QixLQUFLK0IsT0FBTCxDQUFhQyxnQkFBYixHQUFnQzJCLEtBQWhDLENBQXNDLENBQXRDLENBQWY7QUFFQSxVQUFNQyxhQUFhOUIsT0FBTytCLElBQVAsR0FBYyxHQUFkLEdBQW9CL0IsT0FBT2dDLElBQTlDO0FBRUEsVUFBTUMsaUJBQWlCVixTQUFTLFVBQVQsQ0FBdkI7QUFDQSxVQUFNVyxNQUFNSixhQUFhLFdBQWIsR0FBMkJqQyxnQkFBM0IsR0FBOEMsVUFBOUMsR0FBMkQ0QixpQkFBM0QsR0FBK0UsYUFBL0UsR0FBK0ZRLGNBQS9GLEdBQWdILFdBQTVILENBNUJxQyxDQThCckM7O0FBQ0FQLFdBQU9FLFNBQVAsQ0FBaUJoRCxJQUFqQixDQUFzQjtBQUNsQnVELG1CQUFhWixTQUFTLFVBQVQsQ0FESztBQUVsQlUsb0JBRmtCO0FBR2xCQyxTQUhrQjtBQUlsQkUsc0JBQWdCYixTQUFTLFVBQVQ7QUFKRSxLQUF0QjtBQU1ILEdBckNEO0FBc0NBLFNBQU9ILFVBQVA7QUFDSDtBQUVEOzs7Ozs7O0FBS0FsRCxLQUFLSyxPQUFMLENBQWE4QixRQUFiLENBQXNCRyxLQUF0QixDQUE0QjZCLFNBQTVCLEdBQXdDLFVBQVN4QyxnQkFBVCxFQUEyQjtBQUMvRDtBQUNBLFFBQU1YLFNBQVNzQixNQUFNOEIsaUJBQU4sQ0FBd0J6QyxnQkFBeEIsQ0FBZjtBQUVBLFNBQU87QUFDSEEsc0JBQWtCQSxnQkFEZjtBQUVIdUIsZ0JBQVlILDBCQUEwQi9CLE1BQTFCLEVBQWtDVyxnQkFBbEM7QUFGVCxHQUFQO0FBSUgsQ0FSRCxDOzs7Ozs7Ozs7OztBQzNEQSxJQUFJM0IsSUFBSjtBQUFTQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDSCxPQUFLSSxDQUFMLEVBQU87QUFBQ0osV0FBS0ksQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUE4RCxJQUFJVSxlQUFKO0FBQW9CYixPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0RBQVIsQ0FBYixFQUErRTtBQUFDVyxrQkFBZ0JWLENBQWhCLEVBQWtCO0FBQUNVLHNCQUFnQlYsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQS9FLEVBQXVILENBQXZIOztBQUczRjs7Ozs7OztBQU9BLFNBQVNpRSxRQUFULENBQWtCQyxPQUFsQixFQUEyQkMsWUFBM0IsRUFBeUM7QUFDckMsTUFBSSxDQUFDRCxPQUFELElBQVksQ0FBQ0EsUUFBUUUsS0FBekIsRUFBZ0M7QUFDNUIsV0FBT0QsWUFBUDtBQUNIOztBQUVELFNBQU9ELFFBQVFFLEtBQWY7QUFDSDtBQUVEOzs7Ozs7Ozs7O0FBUUEsU0FBU0MseUJBQVQsQ0FBbUNwQixRQUFuQyxFQUE2QztBQUN6QztBQUNBO0FBQ0E7QUFDQSxRQUFNcUIsc0JBQXNCckIsU0FBUyxVQUFULENBQTVCOztBQUNBLE1BQUlxQix1QkFBdUJBLG9CQUFvQnRELE1BQS9DLEVBQXVEO0FBQ25ELFdBQU9zRCxvQkFBb0IsQ0FBcEIsRUFBdUIsVUFBdkIsQ0FBUDtBQUNIO0FBQ0o7QUFFRDs7Ozs7Ozs7Ozs7QUFTQSxTQUFTM0IseUJBQVQsQ0FBbUNwQixnQkFBbkMsRUFBcURxQixVQUFyRCxFQUFpRTtBQUM3RGhELE9BQUs0QixHQUFMLENBQVNDLElBQVQsQ0FBYywyQkFBZDtBQUNBLFFBQU1vQixZQUFZLEVBQWxCO0FBQ0EsUUFBTUMsYUFBYSxFQUFuQjs7QUFFQSxNQUFJLENBQUNGLFdBQVc1QixNQUFoQixFQUF3QjtBQUNwQjtBQUNIOztBQUVELFFBQU11RCxhQUFhM0IsV0FBVyxDQUFYLEVBQWNNLFFBQWQsRUFBbkI7O0FBQ0EsTUFBSSxDQUFDcUIsVUFBTCxFQUFpQjtBQUNiO0FBQ0g7O0FBRUQsUUFBTUMsWUFBWTtBQUNkMUIsZ0JBQVlBLFVBREU7QUFFZDJCLGlCQUFhRixXQUFXLFVBQVgsQ0FGQztBQUdkRyxlQUFXSCxXQUFXLFVBQVgsQ0FIRztBQUlkSSxzQkFBa0JKLFdBQVcsVUFBWCxDQUpKO0FBS2RLLGdCQUFZTCxXQUFXLFVBQVgsQ0FMRTtBQU1kTSxxQkFBaUJOLFdBQVcsVUFBWCxDQU5IO0FBT2RPLGVBQVdQLFdBQVcsVUFBWCxDQVBHO0FBUWRRLGdCQUFZUixXQUFXLFVBQVgsQ0FSRTtBQVNkUyxzQkFBa0JULFdBQVcsVUFBWCxDQVRKO0FBVWRVLGdCQUFZVixXQUFXLFVBQVgsQ0FWRTtBQVdkaEQsc0JBQWtCZ0QsV0FBVyxVQUFYLENBWEo7QUFZZFcscUJBQWlCWCxXQUFXLFVBQVg7QUFaSCxHQUFsQjtBQWVBM0IsYUFBV0csT0FBWCxDQUFtQixVQUFTQyxXQUFULEVBQXNCO0FBQ3JDLFVBQU1DLFdBQVdELFlBQVlFLFFBQVosRUFBakI7QUFDQSxVQUFNQyxvQkFBb0JGLFNBQVMsVUFBVCxDQUExQjtBQUNBLFFBQUlHLFNBQVNQLFVBQVVNLGlCQUFWLENBQWI7O0FBQ0EsUUFBSSxDQUFDQyxNQUFMLEVBQWE7QUFDVEEsZUFBUztBQUNMK0IsMkJBQW1CbEMsU0FBUyxVQUFULENBRGQ7QUFFTG1DLGtCQUFVbkMsU0FBUyxVQUFULENBRkw7QUFHTEUsMkJBQW1CQSxpQkFIZDtBQUlMRSxzQkFBY3BDLFdBQVdnQyxTQUFTLFVBQVQsQ0FBWCxDQUpUO0FBS0xLLG1CQUFXO0FBTE4sT0FBVDtBQU9BVCxnQkFBVU0saUJBQVYsSUFBK0JDLE1BQS9CO0FBQ0FOLGlCQUFXeEMsSUFBWCxDQUFnQjhDLE1BQWhCO0FBQ0g7O0FBRUQsVUFBTU8saUJBQWlCVixTQUFTLFVBQVQsQ0FBdkI7QUFFQSxVQUFNb0Msa0JBQWtCO0FBQ3BCQyxpQkFBV3JDLFNBQVMsVUFBVCxDQURTO0FBRXBCWSxtQkFBYVosU0FBUyxVQUFULENBRk87QUFHcEJtQyxnQkFBVW5DLFNBQVMsVUFBVCxDQUhVO0FBSXBCVSxzQkFBZ0JBLGNBSkk7QUFLcEJHLHNCQUFnQjdDLFdBQVdnQyxTQUFTLFVBQVQsQ0FBWCxDQUxJO0FBTXBCc0MsNEJBQXNCdEMsU0FBUyxVQUFULENBTkY7QUFPcEJ1QywrQkFBeUJ2QyxTQUFTLFVBQVQsQ0FQTDtBQVFwQndDLDJCQUFxQnhDLFNBQVMsVUFBVCxDQVJEO0FBU3BCeUMsc0JBQWdCekUsV0FBV2dDLFNBQVMsVUFBVCxDQUFYLENBVEk7QUFVcEIwQyxxQkFBZTFFLFdBQVdnQyxTQUFTLFVBQVQsQ0FBWCxDQVZLO0FBV3BCMkMscUJBQWUzRSxXQUFXZ0MsU0FBUyxVQUFULENBQVgsQ0FYSztBQVlwQjRDLHVCQUFpQjVFLFdBQVdnQyxTQUFTLFVBQVQsQ0FBWCxDQVpHO0FBYXBCNkMsaUNBQTJCN0MsU0FBUyxVQUFULENBYlA7QUFjcEI4QywyQkFBcUI5RSxXQUFXZ0MsU0FBUyxVQUFULENBQVgsQ0FkRDtBQWVwQitDLFlBQU0vRSxXQUFXZ0MsU0FBUyxVQUFULENBQVgsQ0FmYztBQWdCcEJnRCxlQUFTaEYsV0FBV2dDLFNBQVMsVUFBVCxDQUFYLENBaEJXO0FBaUJwQmlELG9CQUFjakQsU0FBUyxVQUFULENBakJNO0FBa0JwQmtELHFCQUFlbEYsV0FBV2dDLFNBQVMsVUFBVCxDQUFYLENBbEJLO0FBbUJwQm1ELGtCQUFZbkYsV0FBV2dDLFNBQVMsVUFBVCxDQUFYLENBbkJRO0FBb0JwQm9ELGVBQVNwRixXQUFXZ0MsU0FBUyxVQUFULENBQVgsQ0FwQlc7QUFxQnBCcUQsMkJBQXFCckYsV0FBV2dDLFNBQVMsVUFBVCxDQUFYLENBckJEO0FBc0JwQnNELG9CQUFjdEQsU0FBUyxVQUFULENBdEJNO0FBdUJwQnVELG1CQUFhdkQsU0FBUyxVQUFULENBdkJPO0FBd0JwQndELHdCQUFrQnhGLFdBQVdnQyxTQUFTLFVBQVQsQ0FBWCxDQXhCRTtBQXlCcEJ5RCxvQkFBY3pGLFdBQVdnQyxTQUFTLFVBQVQsQ0FBWCxDQXpCTTtBQTBCcEIwRCw4QkFBd0J0QywwQkFBMEJwQixRQUExQixDQTFCSjtBQTJCcEIyRCxrQkFBWTNELFNBQVMsVUFBVCxDQTNCUTtBQTRCcEI0RCxvQkFBYzVELFNBQVMsVUFBVCxDQTVCTTtBQTZCcEI2RCwyQkFBcUI3RCxTQUFTLFVBQVQsQ0E3QkQ7QUE4QnBCOEQsc0JBQWdCOUYsV0FBV2dDLFNBQVMsVUFBVCxDQUFYLENBOUJJO0FBK0JwQitELDZCQUF1Qi9DLFNBQVNoQixTQUFTLFVBQVQsQ0FBVCxDQS9CSDtBQWdDcEJnRSxpQkFBV2hHLFdBQVdnQyxTQUFTLFVBQVQsQ0FBWCxDQWhDUztBQWlDcEJpRSx1QkFBaUJ4RyxnQkFBZ0J1QyxTQUFTLFVBQVQsQ0FBaEIsQ0FqQ0c7QUFrQ3BCa0UsNkJBQXVCbEUsU0FBUyxVQUFULENBbENIO0FBbUNwQm1FLDZCQUF1Qm5FLFNBQVMsVUFBVCxDQW5DSDtBQW9DcEJvRSxrQ0FBNEJwRSxTQUFTLFVBQVQsQ0FwQ1I7QUFxQ3BCcUUsbUNBQTZCckUsU0FBUyxVQUFULENBckNUO0FBc0NwQnNFLDRCQUFzQnRFLFNBQVMsVUFBVCxDQXRDRjtBQXVDcEJ1RSxrQkFBWXZFLFNBQVMsVUFBVCxDQXZDUTtBQXdDcEJ3RSwwQkFBb0J4RSxTQUFTLFVBQVQ7QUF4Q0EsS0FBeEIsQ0FsQnFDLENBNkRyQzs7QUFDQSxVQUFNdkIsU0FBUzlCLEtBQUsrQixPQUFMLENBQWFDLGdCQUFiLEVBQWY7QUFDQSxVQUFNOEYsVUFBVyxHQUFFaEcsT0FBT2lHLFdBQVksOEJBQTZCcEcsZ0JBQWlCLGNBQWE0QixpQkFBa0IsY0FBYVEsY0FBZSxrQ0FBL0k7QUFDQTBCLG9CQUFnQnFDLE9BQWhCLEdBQTBCRSxVQUFVQyxVQUFWLENBQXFCSCxPQUFyQixFQUE4QmhHLE1BQTlCLENBQTFCO0FBRUEwQixXQUFPRSxTQUFQLENBQWlCaEQsSUFBakIsQ0FBc0IrRSxlQUF0QjtBQUNILEdBbkVEO0FBcUVBYixZQUFVakQsZ0JBQVYsR0FBNkJBLGdCQUE3QjtBQUVBLFNBQU9pRCxTQUFQO0FBQ0g7QUFFRDs7Ozs7OztBQUtBNUUsS0FBS0ssT0FBTCxDQUFhOEIsUUFBYixDQUFzQkcsS0FBdEIsQ0FBNEJELGdCQUE1QixHQUErQyxVQUFTVixnQkFBVCxFQUEyQjtBQUN0RTtBQUNBLFFBQU11RyxlQUFlbEksS0FBSytCLE9BQUwsQ0FBYUMsZ0JBQWIsR0FBZ0MyQixLQUFoQyxDQUFzQyxDQUF0QyxDQUFyQjtBQUNBLFFBQU13RSxzQ0FBc0NELGFBQWFDLG1DQUF6RDtBQUNBLE1BQUlDLE9BQUosQ0FKc0UsQ0FNdEU7QUFDQTs7QUFDQSxNQUFJRCx3Q0FBd0MsS0FBNUMsRUFBbUQ7QUFDL0NDLGNBQVU5RixNQUFNK0YsNEJBQU4sQ0FBbUMxRyxnQkFBbkMsQ0FBVjtBQUNILEdBRkQsTUFFTztBQUNIeUcsY0FBVTlGLE1BQU04QixpQkFBTixDQUF3QnpDLGdCQUF4QixDQUFWO0FBQ0g7O0FBRUQsU0FBT29CLDBCQUEwQnBCLGdCQUExQixFQUE0Q3lHLE9BQTVDLENBQVA7QUFDSCxDQWZELEM7Ozs7Ozs7Ozs7O0FDekpBLElBQUk1RyxNQUFKO0FBQVd2QixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNxQixTQUFPcEIsQ0FBUCxFQUFTO0FBQUNvQixhQUFPcEIsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJSixJQUFKO0FBQVNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNILE9BQUtJLENBQUwsRUFBTztBQUFDSixXQUFLSSxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBQThELElBQUlrSSxhQUFKO0FBQWtCckksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNDQUFSLENBQWIsRUFBNkQ7QUFBQ21JLGdCQUFjbEksQ0FBZCxFQUFnQjtBQUFDa0ksb0JBQWNsSSxDQUFkO0FBQWdCOztBQUFsQyxDQUE3RCxFQUFpRyxDQUFqRzs7QUFJbkssTUFBTW1JLGFBQWEsTUFBTTtBQUNyQjtBQUNBakcsUUFBTWtHLFVBQU4sQ0FBaUJDLEtBQWpCLEdBRnFCLENBSXJCOztBQUNBLFFBQU0zRyxTQUFTOUIsS0FBSytCLE9BQUwsQ0FBYUMsZ0JBQWIsRUFBZixDQUxxQixDQU9yQjs7QUFDQSxNQUFJRixPQUFPSSxJQUFQLEtBQWdCLE9BQXBCLEVBQTZCO0FBQ3pCO0FBQ0gsR0FWb0IsQ0FZckI7OztBQUNBLFFBQU15QixRQUFRN0IsT0FBTzZCLEtBQXJCOztBQUNBLE1BQUksQ0FBQ0EsS0FBRCxJQUFVLENBQUNBLE1BQU12QyxNQUFyQixFQUE2QjtBQUN6QnBCLFNBQUs0QixHQUFMLENBQVNXLEtBQVQsQ0FBZSxtQkFBbUIsMEJBQWxDO0FBQ0EsVUFBTSxJQUFJZixPQUFPUyxLQUFYLENBQWlCLGNBQWpCLEVBQWlDLDBCQUFqQyxDQUFOO0FBQ0gsR0FqQm9CLENBbUJyQjs7O0FBQ0FqQyxPQUFLNEIsR0FBTCxDQUFTQyxJQUFULENBQWMsb0JBQWQ7O0FBQ0EsTUFBSTtBQUNBOEIsVUFBTVIsT0FBTixDQUFjdUYsUUFBUXBHLE1BQU1rRyxVQUFOLENBQWlCRyxPQUFqQixDQUF5QkQsSUFBekIsQ0FBdEI7QUFDSCxHQUZELENBRUUsT0FBTW5HLEtBQU4sRUFBYTtBQUNYdkMsU0FBSzRCLEdBQUwsQ0FBU1csS0FBVCxDQUFlLHFCQUFxQkEsS0FBcEM7QUFDQSxVQUFNLElBQUlmLE9BQU9TLEtBQVgsQ0FBaUIsZ0JBQWpCLEVBQW1DTSxLQUFuQyxDQUFOO0FBQ0g7QUFDSixDQTNCRCxDLENBNkJBOzs7QUFDQWYsT0FBT29ILE9BQVAsQ0FBZSxNQUFNO0FBQ2pCTixnQkFBY08sSUFBZCxHQUFxQkMsT0FBckIsQ0FBNkI7QUFDekJDLFdBQU9SLFVBRGtCO0FBRXpCUyxhQUFTVDtBQUZnQixHQUE3QjtBQUlILENBTEQsRTs7Ozs7Ozs7Ozs7QUNsQ0EsSUFBSVUsTUFBSjtBQUFXaEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQzhJLFNBQU83SSxDQUFQLEVBQVM7QUFBQzZJLGFBQU83SSxDQUFQO0FBQVM7O0FBQXBCLENBQS9DLEVBQXFFLENBQXJFO0FBQXdFLElBQUlKLElBQUo7QUFBU0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ0gsT0FBS0ksQ0FBTCxFQUFPO0FBQUNKLFdBQUtJLENBQUw7QUFBTzs7QUFBaEIsQ0FBekMsRUFBMkQsQ0FBM0Q7O0FBRzVGOzs7Ozs7QUFNQSxTQUFTOEksbUJBQVQsQ0FBNkJsRyxVQUE3QixFQUF5QztBQUNyQyxRQUFNM0MsVUFBVSxFQUFoQjtBQUVBMkMsYUFBV0csT0FBWCxDQUFtQixVQUFTZ0csUUFBVCxFQUFtQjtBQUNsQyxVQUFNQyxRQUFRRCxTQUFTN0YsUUFBVCxFQUFkO0FBQ0FqRCxZQUFRSyxJQUFSLENBQWE7QUFDVGlCLHdCQUFrQnlILE1BQU0sVUFBTixDQURUO0FBRVQ7QUFDQWxFLGlCQUFXa0UsTUFBTSxVQUFOLENBSEY7QUFJVEMsaUJBQVdELE1BQU0sVUFBTixDQUpGO0FBS1RuRSx1QkFBaUJtRSxNQUFNLFVBQU4sQ0FMUjtBQU1URSw4QkFBd0JGLE1BQU0sVUFBTixDQU5mO0FBT1Q7QUFDQXZFLG1CQUFhdUUsTUFBTSxVQUFOLENBUko7QUFTVHRFLGlCQUFXc0UsTUFBTSxVQUFOLENBVEY7QUFVVEcsd0JBQWtCSCxNQUFNLFVBQU4sQ0FWVDtBQVdUcEUsa0JBQVlvRSxNQUFNLFVBQU4sQ0FYSDtBQVlUL0Qsa0JBQVkrRCxNQUFNLFVBQU4sQ0FaSDtBQWFUSSxlQUFTSixNQUFNLFVBQU4sQ0FiQTtBQWNUaEUsd0JBQWtCZ0UsTUFBTSxVQUFOLENBZFQ7QUFlVGpFLGtCQUFZaUUsTUFBTSxVQUFOO0FBZkgsS0FBYjtBQWlCSCxHQW5CRDtBQW9CQSxTQUFPL0ksT0FBUDtBQUNIOztBQUVETCxLQUFLSyxPQUFMLENBQWE4QixRQUFiLENBQXNCRyxLQUF0QixDQUE0Qk0sT0FBNUIsR0FBc0MsVUFBU0YsTUFBVCxFQUFpQjtBQUNuRDFDLE9BQUs0QixHQUFMLENBQVNDLElBQVQsQ0FBYyx3QkFBZDtBQUVBLE1BQUk0SCxrQkFBa0IsRUFBdEI7O0FBQ0EsTUFBSS9HLE9BQU9nSCxhQUFQLElBQXdCaEgsT0FBT2lILFdBQW5DLEVBQWdEO0FBQzVDLFVBQU1DLGNBQWNDLFFBQVFaLE9BQU9ZLElBQVAsRUFBYSxZQUFiLEVBQTJCQyxNQUEzQixDQUFrQyxVQUFsQyxDQUE1Qjs7QUFDQSxVQUFNQyxXQUFXSCxZQUFZbEgsT0FBT2dILGFBQW5CLENBQWpCO0FBQ0EsVUFBTU0sU0FBU0osWUFBWWxILE9BQU9pSCxXQUFuQixDQUFmO0FBQ0FGLHNCQUFtQixHQUFFTSxRQUFTLElBQUdDLE1BQU8sRUFBeEM7QUFDSCxHQVRrRCxDQVduRDs7O0FBQ0EsTUFBSUMsWUFBWXZILE9BQU9mLGdCQUFQLElBQTJCLEVBQTNDOztBQUNBLE1BQUlzSSxTQUFKLEVBQWU7QUFDWEEsZ0JBQVlDLE1BQU1DLE9BQU4sQ0FBY0YsU0FBZCxJQUEyQkEsVUFBVXJKLElBQVYsRUFBM0IsR0FBOENxSixTQUExRDtBQUNBQSxnQkFBWUEsVUFBVUcsT0FBVixDQUFrQixXQUFsQixFQUErQixJQUEvQixDQUFaO0FBQ0g7O0FBRUQsUUFBTUMsYUFBYTtBQUNmLGdCQUFZSixTQURHO0FBRWYsZ0JBQVl2SCxPQUFPbUMsV0FGSjtBQUdmLGdCQUFZbkMsT0FBT29DLFNBSEo7QUFJZixnQkFBWXBDLE9BQU91QyxlQUpKO0FBS2YsZ0JBQVl3RSxlQUxHO0FBTWYsZ0JBQVkvRyxPQUFPMEMsZ0JBTko7QUFPZixnQkFBWSxFQVBHO0FBUWYsZ0JBQVksRUFSRztBQVNmLGdCQUFZMUMsT0FBTzRIO0FBVEosR0FBbkI7QUFZQSxRQUFNbEMsVUFBVTlGLE1BQU1pSSxlQUFOLENBQXNCRixVQUF0QixDQUFoQjtBQUNBLFNBQU9uQixvQkFBb0JkLE9BQXBCLENBQVA7QUFDSCxDQWhDRCxDOzs7Ozs7Ozs7OztBQ25DQSxJQUFJcEksSUFBSjtBQUFTQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDSCxPQUFLSSxDQUFMLEVBQU87QUFBQ0osV0FBS0ksQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDs7QUFFVDs7Ozs7O0FBTUEsU0FBU29LLFFBQVQsQ0FBa0IxSSxNQUFsQixFQUEwQkgsZ0JBQTFCLEVBQTRDO0FBQ3hDLFNBQU9HLE9BQU8ySSxRQUFQLEdBQWtCLFdBQWxCLEdBQWdDOUksZ0JBQWhDLEdBQW1ELFlBQTFEO0FBQ0g7QUFFRDs7Ozs7Ozs7Ozs7QUFTQSxTQUFTb0IseUJBQVQsQ0FBbUNqQixNQUFuQyxFQUEyQ0gsZ0JBQTNDLEVBQTZEcUIsVUFBN0QsRUFBeUU7QUFDckUsTUFBSUMsWUFBWSxFQUFoQjtBQUNBLE1BQUlDLGFBQWEsRUFBakI7QUFFQUYsYUFBV0csT0FBWCxDQUFtQixVQUFTRSxRQUFULEVBQW1CO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBLFFBQUlFLG9CQUFvQm1ILFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0FBeEI7QUFDQSxRQUFJRyxTQUFTUCxVQUFVTSxpQkFBVixDQUFiLENBTGtDLENBT2xDO0FBQ0E7O0FBQ0EsUUFBSSxDQUFDQyxNQUFMLEVBQWE7QUFDVEEsZUFBUztBQUNMRCwyQkFBbUJBLGlCQURkO0FBRUxFLHNCQUFjaUgsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQUZUO0FBR0xLLG1CQUFXO0FBSE4sT0FBVCxDQURTLENBT1Q7O0FBQ0FULGdCQUFVTSxpQkFBVixJQUErQkMsTUFBL0I7QUFDQU4saUJBQVd4QyxJQUFYLENBQWdCOEMsTUFBaEI7QUFDSCxLQW5CaUMsQ0FxQmxDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7OztBQUNBLFFBQUlPLGlCQUFpQjJHLFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0FBckI7QUFDQSxRQUFJVyxNQUFNbEMsT0FBT2lHLFdBQVAsR0FBcUIsNkJBQXJCLEdBQXFEcEcsZ0JBQXJELEdBQXdFLGFBQXhFLEdBQXdGNEIsaUJBQXhGLEdBQTRHLGFBQTVHLEdBQTRIUSxjQUE1SCxHQUE2SSxrQ0FBdkosQ0EvQmtDLENBaUNsQzs7QUFDQVAsV0FBT0UsU0FBUCxDQUFpQmhELElBQWpCLENBQXNCO0FBQ2xCdUQsbUJBQWF5RyxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBREs7QUFFbEJVLHNCQUFnQkEsY0FGRTtBQUdsQkMsV0FBS0EsR0FIYTtBQUlsQkUsc0JBQWdCd0csU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQjtBQUpFLEtBQXRCO0FBTUgsR0F4Q0Q7QUF5Q0EsU0FBT0gsVUFBUDtBQUNIO0FBRUQ7Ozs7Ozs7OztBQU9BbEQsS0FBS0ssT0FBTCxDQUFhOEIsUUFBYixDQUFzQlEsSUFBdEIsQ0FBMkJ3QixTQUEzQixHQUF1QyxVQUFTckMsTUFBVCxFQUFpQkgsZ0JBQWpCLEVBQW1DO0FBQ3RFLE1BQUlpSixNQUFNSixTQUFTMUksTUFBVCxFQUFpQkgsZ0JBQWpCLENBQVY7O0FBRUEsTUFBSTtBQUNBLFFBQUlYLFNBQVMwSixTQUFTRyxPQUFULENBQWlCRCxHQUFqQixFQUFzQjlJLE9BQU9nSixjQUE3QixDQUFiO0FBRUEsV0FBTztBQUNIL0MsbUJBQWFqRyxPQUFPaUcsV0FEakI7QUFFSHBHLHdCQUFrQkEsZ0JBRmY7QUFHSHVCLGtCQUFZSCwwQkFBMEJqQixNQUExQixFQUFrQ0gsZ0JBQWxDLEVBQW9EWCxPQUFPVCxJQUEzRDtBQUhULEtBQVA7QUFLSCxHQVJELENBUUUsT0FBT2dDLEtBQVAsRUFBYztBQUNadkMsU0FBSzRCLEdBQUwsQ0FBU1ksS0FBVDtBQUVBLFVBQU1ELEtBQU47QUFDSDtBQUVKLENBakJELEM7Ozs7Ozs7Ozs7O0FDNUVBLElBQUl2QyxJQUFKO0FBQVNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNILE9BQUtJLENBQUwsRUFBTztBQUFDSixXQUFLSSxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEOztBQUVUOzs7Ozs7O0FBT0EsU0FBUzJLLFlBQVQsQ0FBc0JsQixJQUF0QixFQUE0QjtBQUN4QixNQUFJLENBQUNBLElBQUwsRUFBVyxPQUFPLEVBQVA7QUFDWCxNQUFJbUIsT0FBT25CLEtBQUtvQixXQUFMLEdBQW1CQyxRQUFuQixFQUFYO0FBQ0EsTUFBSUMsUUFBUSxDQUFDdEIsS0FBS3VCLFFBQUwsS0FBa0IsQ0FBbkIsRUFBc0JGLFFBQXRCLEVBQVo7QUFDQSxNQUFJRyxNQUFNeEIsS0FBS3lCLE9BQUwsR0FBZUosUUFBZixFQUFWO0FBQ0FGLFNBQU8sSUFBSU8sTUFBSixDQUFXLElBQUlQLEtBQUs1SixNQUFwQixFQUE0Qm9LLE1BQTVCLENBQW1DUixJQUFuQyxDQUFQO0FBQ0FHLFVBQVEsSUFBSUksTUFBSixDQUFXLElBQUlKLE1BQU0vSixNQUFyQixFQUE2Qm9LLE1BQTdCLENBQW9DTCxLQUFwQyxDQUFSO0FBQ0FFLFFBQU0sSUFBSUUsTUFBSixDQUFXLElBQUlGLElBQUlqSyxNQUFuQixFQUEyQm9LLE1BQTNCLENBQWtDSCxHQUFsQyxDQUFOO0FBQ0EsU0FBTyxHQUFHRyxNQUFILENBQVVSLElBQVYsRUFBZ0JHLEtBQWhCLEVBQXVCRSxHQUF2QixDQUFQO0FBQ0g7QUFFRDs7Ozs7Ozs7OztBQVFBLFNBQVNJLGVBQVQsQ0FBeUIzSixNQUF6QixFQUFpQ1ksTUFBakMsRUFBeUM7QUFDckMsUUFBTWdKLHVCQUF1QixDQUN6QixVQUR5QixFQUNiO0FBQ1osWUFGeUIsQ0FFZDtBQUNYO0FBSHlCLElBSTNCOUssSUFKMkIsQ0FJdEIsR0FKc0IsQ0FBN0I7QUFNQSxRQUFNeUosYUFBYTtBQUNmc0IsaUJBQWFqSixPQUFPbUMsV0FETDtBQUVmK0csZUFBV2xKLE9BQU9vQyxTQUZIO0FBR2YrRyxxQkFBaUJuSixPQUFPdUMsZUFIVDtBQUlmNkcsc0JBQWtCcEosT0FBTzBDLGdCQUpWO0FBS2YyRyx1QkFBbUJySixPQUFPNEgsaUJBTFg7QUFNZjBCLFdBQU90SixPQUFPc0osS0FOQztBQU9mQyxrQkFBY25LLE9BQU9vSyx3QkFBUCxHQUFrQyxLQUFsQyxHQUEwQ1I7QUFQekMsR0FBbkIsQ0FQcUMsQ0FpQnJDOztBQUNBLE1BQUloSixPQUFPZ0gsYUFBUCxJQUF3QmhILE9BQU9pSCxXQUFuQyxFQUFnRDtBQUM1QyxVQUFNSSxXQUFXZ0IsYUFBYSxJQUFJb0IsSUFBSixDQUFTekosT0FBT2dILGFBQWhCLENBQWIsQ0FBakI7QUFDQSxVQUFNTSxTQUFTZSxhQUFhLElBQUlvQixJQUFKLENBQVN6SixPQUFPaUgsV0FBaEIsQ0FBYixDQUFmO0FBQ0FVLGVBQVcrQixTQUFYLEdBQXdCLEdBQUVyQyxRQUFTLElBQUdDLE1BQU8sRUFBN0M7QUFDSCxHQXRCb0MsQ0F3QnJDOzs7QUFDQSxNQUFJdEgsT0FBT2YsZ0JBQVgsRUFBNkI7QUFDekIsUUFBSXNJLFlBQVl2SCxPQUFPZixnQkFBdkI7QUFDQXNJLGdCQUFZQyxNQUFNQyxPQUFOLENBQWNGLFNBQWQsSUFBMkJBLFVBQVVySixJQUFWLEVBQTNCLEdBQThDcUosU0FBMUQ7QUFDQUEsZ0JBQVlBLFVBQVVHLE9BQVYsQ0FBa0IsV0FBbEIsRUFBK0IsSUFBL0IsQ0FBWjtBQUNBQyxlQUFXZ0MsZ0JBQVgsR0FBOEJwQyxTQUE5QjtBQUNIOztBQUVELFNBQU9uSSxPQUFPMkksUUFBUCxHQUFrQixXQUFsQixHQUFnQ25LLGdCQUFnQitKLFVBQWhCLENBQXZDO0FBQ0g7QUFFRDs7Ozs7Ozs7QUFNQSxTQUFTbkIsbUJBQVQsQ0FBNkJsRyxVQUE3QixFQUF5QztBQUNyQyxRQUFNM0MsVUFBVSxFQUFoQjtBQUVBLE1BQUksQ0FBQzJDLFVBQUQsSUFBZSxDQUFDQSxXQUFXNUIsTUFBL0IsRUFBdUM7QUFFdkM0QixhQUFXRyxPQUFYLENBQW1CaUcsU0FBUy9JLFFBQVFLLElBQVIsQ0FBYTtBQUNyQ2lCLHNCQUFrQitJLFNBQVNDLFNBQVQsQ0FBbUJ2QixNQUFNLFVBQU4sQ0FBbkIsQ0FEbUI7QUFFckM7QUFDQWxFLGVBQVd3RixTQUFTQyxTQUFULENBQW1CdkIsTUFBTSxVQUFOLENBQW5CLENBSDBCO0FBSXJDQyxlQUFXcUIsU0FBU0MsU0FBVCxDQUFtQnZCLE1BQU0sVUFBTixDQUFuQixDQUowQjtBQUtyQ25FLHFCQUFpQnlGLFNBQVNDLFNBQVQsQ0FBbUJ2QixNQUFNLFVBQU4sQ0FBbkIsQ0FMb0I7QUFNckNFLDRCQUF3Qm9CLFNBQVNDLFNBQVQsQ0FBbUJ2QixNQUFNLFVBQU4sQ0FBbkIsQ0FOYTtBQU9yQztBQUNBdkUsaUJBQWE2RixTQUFTNEIsT0FBVCxDQUFpQmxELE1BQU0sVUFBTixDQUFqQixDQVJ3QjtBQVNyQ3RFLGVBQVc0RixTQUFTQyxTQUFULENBQW1CdkIsTUFBTSxVQUFOLENBQW5CLENBVDBCO0FBVXJDRyxzQkFBa0JtQixTQUFTQyxTQUFULENBQW1CdkIsTUFBTSxVQUFOLENBQW5CLENBVm1CO0FBV3JDcEUsZ0JBQVkwRixTQUFTQyxTQUFULENBQW1CdkIsTUFBTSxVQUFOLENBQW5CLENBWHlCO0FBWXJDSSxhQUFTa0IsU0FBU0MsU0FBVCxDQUFtQnZCLE1BQU0sVUFBTixDQUFuQixDQVo0QjtBQWFyQ21ELGdDQUE0QjdCLFNBQVNDLFNBQVQsQ0FBbUJ2QixNQUFNLFVBQU4sQ0FBbkIsQ0FiUztBQWNyQ29ELG1DQUErQjlCLFNBQVNDLFNBQVQsQ0FBbUJ2QixNQUFNLFVBQU4sQ0FBbkIsQ0FkTTtBQWVyQ2hFLHNCQUFrQnNGLFNBQVNDLFNBQVQsQ0FBbUJ2QixNQUFNLFVBQU4sQ0FBbkIsQ0FmbUI7QUFnQnJDO0FBQ0E7QUFDQWpFLGdCQUFZdUYsU0FBU0MsU0FBVCxDQUFtQkQsU0FBUytCLGFBQVQsQ0FBdUJyRCxNQUFNLFVBQU4sQ0FBdkIsRUFBMENBLE1BQU0sVUFBTixDQUExQyxDQUFuQjtBQWxCeUIsR0FBYixDQUE1QjtBQXFCQSxTQUFPL0ksT0FBUDtBQUNIOztBQUVETCxLQUFLSyxPQUFMLENBQWE4QixRQUFiLENBQXNCUSxJQUF0QixDQUEyQkMsT0FBM0IsR0FBcUMsQ0FBQ2QsTUFBRCxFQUFTWSxNQUFULEtBQW9CO0FBQ3JELFFBQU1rSSxNQUFNYSxnQkFBZ0IzSixNQUFoQixFQUF3QlksTUFBeEIsQ0FBWjs7QUFFQSxNQUFJO0FBQ0EsVUFBTTFCLFNBQVMwSixTQUFTRyxPQUFULENBQWlCRCxHQUFqQixFQUFzQjlJLE9BQU9nSixjQUE3QixDQUFmO0FBRUEsV0FBTzVCLG9CQUFvQmxJLE9BQU9ULElBQTNCLENBQVA7QUFDSCxHQUpELENBSUUsT0FBT2dDLEtBQVAsRUFBYztBQUNadkMsU0FBSzRCLEdBQUwsQ0FBU1ksS0FBVDtBQUVBLFVBQU1ELEtBQU47QUFDSDtBQUNKLENBWkQsQzs7Ozs7Ozs7Ozs7QUNsR0EsSUFBSXZDLElBQUo7QUFBU0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ0gsT0FBS0ksQ0FBTCxFQUFPO0FBQUNKLFdBQUtJLENBQUw7QUFBTzs7QUFBaEIsQ0FBekMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSWtCLGNBQUo7QUFBbUJyQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDbUIsaUJBQWVsQixDQUFmLEVBQWlCO0FBQUNrQixxQkFBZWxCLENBQWY7QUFBaUI7O0FBQXBDLENBQWpELEVBQXVGLENBQXZGOztBQUcxRjs7Ozs7Ozs7O0FBU0EsU0FBUzJDLHlCQUFULENBQW1DakIsTUFBbkMsRUFBMkNILGdCQUEzQyxFQUE2RHFCLFVBQTdELEVBQXlFO0FBQ3JFLE1BQUlDLFlBQVksRUFBaEI7QUFDQSxNQUFJQyxhQUFhLEVBQWpCO0FBRUFGLGFBQVdHLE9BQVgsQ0FBbUIsVUFBU0UsUUFBVCxFQUFtQjtBQUNsQztBQUNBO0FBQ0E7QUFDQSxRQUFJRSxvQkFBb0JqQyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FBeEI7QUFDQSxRQUFJRyxTQUFTUCxVQUFVTSxpQkFBVixDQUFiLENBTGtDLENBT2xDO0FBQ0E7O0FBQ0EsUUFBRyxDQUFDQyxNQUFKLEVBQVk7QUFDUkEsZUFBUztBQUNMRCwyQkFBb0JBLGlCQURmO0FBRUxFLHNCQUFlcEMsV0FBV0MsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBQVgsQ0FGVjtBQUdMSyxtQkFBVztBQUhOLE9BQVQsQ0FEUSxDQU9SOztBQUNBVCxnQkFBVU0saUJBQVYsSUFBK0JDLE1BQS9CO0FBQ0FOLGlCQUFXeEMsSUFBWCxDQUFnQjhDLE1BQWhCO0FBQ0gsS0FuQmlDLENBcUJsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOzs7QUFDQSxRQUFJTyxpQkFBaUJ6QyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FBckI7QUFDQSxRQUFJVyxNQUFNbEMsT0FBT2lHLFdBQVAsR0FBcUIsNkJBQXJCLEdBQXFEcEcsZ0JBQXJELEdBQXdFLGFBQXhFLEdBQXdGNEIsaUJBQXhGLEdBQTRHLGFBQTVHLEdBQTRIUSxjQUE1SCxHQUE2SSxrQ0FBdkosQ0EvQmtDLENBaUNsQzs7QUFDQVAsV0FBT0UsU0FBUCxDQUFpQmhELElBQWpCLENBQXNCO0FBQ2xCdUQsbUJBQWEzQyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FESztBQUVsQlUsc0JBQWdCQSxjQUZFO0FBR2xCQyxXQUFLQSxHQUhhO0FBSWxCRSxzQkFBZ0I3QyxXQUFXQyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FBWDtBQUpFLEtBQXRCO0FBTUwsR0F4Q0M7QUF5Q0YsU0FBT0gsVUFBUDtBQUNEO0FBRUQ7Ozs7Ozs7O0FBTUFsRCxLQUFLSyxPQUFMLENBQWE4QixRQUFiLENBQXNCVyxNQUF0QixDQUE2QnFCLFNBQTdCLEdBQXlDLFVBQVNyQyxNQUFULEVBQWlCSCxnQkFBakIsRUFBbUM7QUFDeEUsTUFBSTBJLGFBQWE7QUFDYnNCLGlCQUFhLEVBREE7QUFFYkMsZUFBVyxFQUZFO0FBR2JDLHFCQUFpQixFQUhKO0FBSWJhLHVCQUFtQixFQUpOO0FBS2JDLGtCQUFlLEVBTEY7QUFNYkMsaUJBQWMsRUFORDtBQU9iQyxvQkFBaUI7QUFQSixHQUFqQjtBQVVBLE1BQUlDLFNBQVMsSUFBSUMsYUFBSixDQUFrQmpMLE9BQU9rTCxJQUF6QixFQUErQmxMLE9BQU9tTCxRQUF0QyxDQUFiO0FBRUEsU0FBTztBQUNIbEYsaUJBQWFqRyxPQUFPaUcsV0FEakI7QUFFSHBHLHNCQUFrQkEsZ0JBRmY7QUFHSHVCLGdCQUFZSCwwQkFBMEJqQixNQUExQixFQUFrQ0gsZ0JBQWxDLEVBQW9EbUwsT0FBT0ksYUFBUCxDQUFxQnBMLE9BQU8wRCxRQUE1QixFQUFzQzdELGdCQUF0QyxFQUF3RCxJQUF4RCxFQUE4RDBJLFVBQTlELENBQXBEO0FBSFQsR0FBUDtBQUtILENBbEJELEM7Ozs7Ozs7Ozs7O0FDbEVBLElBQUlySyxJQUFKO0FBQVNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNILE9BQUtJLENBQUwsRUFBTztBQUFDSixXQUFLSSxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBQThELElBQUlrQixjQUFKO0FBQW1CckIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ21CLGlCQUFlbEIsQ0FBZixFQUFpQjtBQUFDa0IscUJBQWVsQixDQUFmO0FBQWlCOztBQUFwQyxDQUFqRCxFQUF1RixDQUF2RjtBQUEwRixJQUFJVSxlQUFKO0FBQW9CYixPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDVyxrQkFBZ0JWLENBQWhCLEVBQWtCO0FBQUNVLHNCQUFnQlYsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQWxELEVBQTBGLENBQTFGOztBQUl4TTs7Ozs7Ozs7QUFRQSxTQUFTcUUseUJBQVQsQ0FBbUNwQixRQUFuQyxFQUE2QztBQUN6QztBQUNBO0FBQ0E7QUFDQSxNQUFJcUIsc0JBQXNCcEQsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBQTFCOztBQUNBLE1BQUlxQix1QkFBdUJBLG9CQUFvQm5ELEtBQTNDLElBQW9EbUQsb0JBQW9CbkQsS0FBcEIsQ0FBMEJILE1BQWxGLEVBQTBGO0FBQ3RGLFdBQU9zRCxvQkFBb0JuRCxLQUFwQixDQUEwQixDQUExQixFQUE2QixXQUE3QixFQUEwQ0EsS0FBMUMsQ0FBZ0QsQ0FBaEQsQ0FBUDtBQUNIO0FBQ0o7QUFFRDs7Ozs7Ozs7Ozs7O0FBVUEsU0FBU3dCLHlCQUFULENBQW1DakIsTUFBbkMsRUFBMkNILGdCQUEzQyxFQUE2RHFCLFVBQTdELEVBQXlFO0FBQ3JFLE1BQUlDLFlBQVksRUFBaEI7QUFDQSxNQUFJQyxhQUFhLEVBQWpCOztBQUVBLE1BQUksQ0FBQ0YsV0FBVzVCLE1BQWhCLEVBQXdCO0FBQ3BCO0FBQ0g7O0FBRUQsTUFBSXVELGFBQWEzQixXQUFXLENBQVgsQ0FBakI7O0FBQ0EsTUFBSSxDQUFDMkIsVUFBTCxFQUFpQjtBQUNiO0FBQ0g7O0FBRUQsTUFBSUMsWUFBWTtBQUNaMUIsZ0JBQVlBLFVBREE7QUFFWjJCLGlCQUFhdkQsZUFBZXFELFdBQVcsV0FBWCxDQUFmLENBRkQ7QUFHWkcsZUFBV3hELGVBQWVxRCxXQUFXLFdBQVgsQ0FBZixDQUhDO0FBSVpNLHFCQUFpQjNELGVBQWVxRCxXQUFXLFdBQVgsQ0FBZixDQUpMO0FBS1pPLGVBQVc1RCxlQUFlcUQsV0FBVyxXQUFYLENBQWYsQ0FMQztBQU1aUSxnQkFBWTdELGVBQWVxRCxXQUFXLFdBQVgsQ0FBZixDQU5BO0FBT1pTLHNCQUFrQjlELGVBQWVxRCxXQUFXLFdBQVgsQ0FBZixDQVBOO0FBUVpVLGdCQUFZL0QsZUFBZXFELFdBQVcsV0FBWCxDQUFmLENBUkE7QUFTWmhELHNCQUFrQkwsZUFBZXFELFdBQVcsV0FBWCxDQUFmO0FBVE4sR0FBaEI7QUFZQTNCLGFBQVdHLE9BQVgsQ0FBbUIsVUFBU0UsUUFBVCxFQUFtQjtBQUNsQyxRQUFJRSxvQkFBb0JqQyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FBeEI7QUFDQSxRQUFJRyxTQUFTUCxVQUFVTSxpQkFBVixDQUFiOztBQUNBLFFBQUksQ0FBQ0MsTUFBTCxFQUFhO0FBQ1RBLGVBQVM7QUFDTCtCLDJCQUFtQmpFLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQURkO0FBRUxtQyxrQkFBVWxFLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUZMO0FBR0xFLDJCQUFtQkEsaUJBSGQ7QUFJTEUsc0JBQWNwQyxXQUFXQyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FBWCxDQUpUO0FBS0xLLG1CQUFXO0FBTE4sT0FBVDtBQU9BVCxnQkFBVU0saUJBQVYsSUFBK0JDLE1BQS9CO0FBQ0FOLGlCQUFXeEMsSUFBWCxDQUFnQjhDLE1BQWhCO0FBQ0g7O0FBRUQsUUFBSU8saUJBQWlCekMsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBQXJCO0FBRUEsUUFBSW9DLGtCQUFrQjtBQUNsQkMsaUJBQVdwRSxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FETztBQUVsQlksbUJBQWEzQyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FGSztBQUdsQlUsc0JBQWdCQSxjQUhFO0FBSWxCRyxzQkFBZ0I3QyxXQUFXQyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FBWCxDQUpFO0FBS2xCc0MsNEJBQXNCckUsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBTEo7QUFNbEJ1QywrQkFBeUJ0RSxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FOUDtBQU9sQndDLDJCQUFxQnZFLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQVBIO0FBUWxCMEMscUJBQWUxRSxXQUFXQyxlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0FBWCxDQVJHO0FBU2xCNEMsdUJBQWlCNUUsV0FBV0MsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBQVgsQ0FUQztBQVVsQjZDLGlDQUEyQjVFLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQVZUO0FBV2xCK0MsWUFBTS9FLFdBQVdDLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUFYLENBWFk7QUFZbEJnRCxlQUFTaEYsV0FBV0MsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBQVgsQ0FaUztBQWFsQmlELG9CQUFjaEYsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBYkk7QUFjbEJrRCxxQkFBZWxGLFdBQVdDLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUFYLENBZEc7QUFlbEJtRCxrQkFBWW5GLFdBQVdDLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUFYLENBZk07QUFnQmxCb0QsZUFBU3BGLFdBQVdDLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUFYLENBaEJTO0FBaUJsQnFELDJCQUFxQnJGLFdBQVdDLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUFYLENBakJIO0FBa0JsQnNELG9CQUFjckYsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBbEJJO0FBbUJsQnVELG1CQUFhdEYsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBbkJLO0FBb0JsQndELHdCQUFrQnhGLFdBQVdDLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUFYLENBcEJBO0FBcUJsQnlELG9CQUFjekYsV0FBV0MsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBQVgsQ0FyQkk7QUFzQmxCMEQsOEJBQXdCdEMsMEJBQTBCcEIsUUFBMUIsQ0F0Qk47QUF1QmxCMkQsa0JBQVkxRixlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0F2Qk07QUF3QmxCNEQsb0JBQWMzRixlQUFlK0IsU0FBUyxXQUFULENBQWYsQ0F4Qkk7QUF5QmxCNkQsMkJBQXFCNUYsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBekJIO0FBMEJsQjhELHNCQUFnQjlGLFdBQVdDLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUFYLENBMUJFO0FBMkJsQitELDZCQUF1QjlGLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQTNCTDtBQTRCbEJnRSxpQkFBV2hHLFdBQVdDLGVBQWUrQixTQUFTLFdBQVQsQ0FBZixDQUFYLENBNUJPO0FBNkJsQmlFLHVCQUFpQnhHLGdCQUFnQlEsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBQWhCLENBN0JDO0FBOEJsQnVFLGtCQUFZdEcsZUFBZStCLFNBQVMsV0FBVCxDQUFmLENBOUJNO0FBK0JsQndFLDBCQUFvQnZHLGVBQWUrQixTQUFTLFdBQVQsQ0FBZjtBQS9CRixLQUF0QjtBQWtDQSxRQUFJOEosTUFBTTlKLFNBQVMsV0FBVCxFQUFzQjlCLEtBQWhDOztBQUNBLFFBQUlPLE9BQU9zTCxjQUFQLEtBQTBCLFNBQTlCLEVBQXlDO0FBQ3JDM0gsc0JBQWdCcUMsT0FBaEIsR0FBMEJoRyxPQUFPaUcsV0FBUCxHQUFxQiw2QkFBckIsR0FBcURwRyxnQkFBckQsR0FBd0UsYUFBeEUsR0FBd0Y0QixpQkFBeEYsR0FBNEcsYUFBNUcsR0FBNEhRLGNBQTVILEdBQTZJLGtDQUF2SztBQUNILEtBRkQsTUFFTyxJQUFJakMsT0FBT3NMLGNBQVAsSUFBeUIsU0FBN0IsRUFBd0M7QUFDM0MzSCxzQkFBZ0JxQyxPQUFoQixHQUEwQmhHLE9BQU9rTCxJQUFQLEdBQWMsYUFBZCxHQUE4QkcsR0FBOUIsR0FBb0MsT0FBOUQ7QUFDSCxLQUZNLE1BRUE7QUFDSDFILHNCQUFnQjRILFNBQWhCLEdBQTRCdkwsT0FBT3dMLFFBQVAsR0FBa0IsV0FBbEIsR0FBZ0MzTCxnQkFBaEMsR0FBbUQsVUFBbkQsR0FBZ0U0QixpQkFBaEUsR0FBb0YsYUFBcEYsR0FBb0dRLGNBQXBHLEdBQXFILFdBQWpKO0FBQ0g7O0FBRURQLFdBQU9FLFNBQVAsQ0FBaUJoRCxJQUFqQixDQUFzQitFLGVBQXRCO0FBQ0gsR0E3REQ7QUE4REo4SCxVQUFRM0wsR0FBUixDQUFZZ0QsVUFBVTFCLFVBQVYsQ0FBcUIsQ0FBckIsRUFBd0JRLFNBQXBDO0FBQ0ksU0FBT2tCLFNBQVA7QUFDSDtBQUVEOzs7Ozs7OztBQU1BNUUsS0FBS0ssT0FBTCxDQUFhOEIsUUFBYixDQUFzQlcsTUFBdEIsQ0FBNkJULGdCQUE3QixHQUFnRCxVQUFTUCxNQUFULEVBQWlCSCxnQkFBakIsRUFBbUM7QUFDL0UsTUFBSW1MLFNBQVMsSUFBSUMsYUFBSixDQUFrQmpMLE9BQU9rTCxJQUF6QixFQUErQmxMLE9BQU9tTCxRQUF0QyxDQUFiO0FBRUEsTUFBSTdELFFBQVFyRywwQkFBMEJqQixNQUExQixFQUFrQ0gsZ0JBQWxDLEVBQW9EbUwsT0FBT1UsZ0JBQVAsQ0FBd0IxTCxPQUFPMEQsUUFBL0IsRUFBeUM3RCxnQkFBekMsQ0FBcEQsQ0FBWjs7QUFDQSxNQUFJLENBQUN5SCxLQUFMLEVBQVk7QUFDVEEsWUFBUSxFQUFSO0FBQ0Y7O0FBRURBLFFBQU1yQixXQUFOLEdBQW9CakcsT0FBT2lHLFdBQTNCO0FBQ0FxQixRQUFNekgsZ0JBQU4sR0FBeUJBLGdCQUF6QjtBQUVBLFNBQU95SCxLQUFQO0FBQ0gsQ0FaRCxDOzs7Ozs7Ozs7OztBQ2pJQSxJQUFJcEosSUFBSjtBQUFTQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDSCxPQUFLSSxDQUFMLEVBQU87QUFBQ0osV0FBS0ksQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUE4RCxJQUFJa0IsY0FBSjtBQUFtQnJCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNtQixpQkFBZWxCLENBQWYsRUFBaUI7QUFBQ2tCLHFCQUFlbEIsQ0FBZjtBQUFpQjs7QUFBcEMsQ0FBakQsRUFBdUYsQ0FBdkY7O0FBRzFGLFNBQVM4SSxtQkFBVCxDQUE2QmxHLFVBQTdCLEVBQXlDO0FBQ3JDLFFBQU0zQyxVQUFVLEVBQWhCO0FBRUEyQyxhQUFXRyxPQUFYLENBQW1CLFVBQVNpRyxLQUFULEVBQWdCO0FBQy9CL0ksWUFBUUssSUFBUixDQUFhO0FBQ1RpQix3QkFBa0JMLGVBQWU4SCxNQUFNLFdBQU4sQ0FBZixDQURUO0FBRVQ7QUFDQWxFLGlCQUFXNUQsZUFBZThILE1BQU0sV0FBTixDQUFmLENBSEY7QUFJVEMsaUJBQVcvSCxlQUFlOEgsTUFBTSxXQUFOLENBQWYsQ0FKRjtBQUtUbkUsdUJBQWlCM0QsZUFBZThILE1BQU0sV0FBTixDQUFmLENBTFI7QUFNVEUsOEJBQXdCaEksZUFBZThILE1BQU0sV0FBTixDQUFmLENBTmY7QUFPVDtBQUNBdkUsbUJBQWF2RCxlQUFlOEgsTUFBTSxXQUFOLENBQWYsQ0FSSjtBQVNUdEUsaUJBQVd4RCxlQUFlOEgsTUFBTSxXQUFOLENBQWYsQ0FURjtBQVVURyx3QkFBa0JqSSxlQUFlOEgsTUFBTSxXQUFOLENBQWYsQ0FWVDtBQVdUcEUsa0JBQVkxRCxlQUFlOEgsTUFBTSxXQUFOLENBQWYsQ0FYSDtBQVlUSSxlQUFTbEksZUFBZThILE1BQU0sV0FBTixDQUFmLENBWkE7QUFhVG1ELGtDQUE0QmxMLFdBQVdDLGVBQWU4SCxNQUFNLFdBQU4sQ0FBZixDQUFYLENBYm5CO0FBY1RvRCxxQ0FBK0JuTCxXQUFXQyxlQUFlOEgsTUFBTSxXQUFOLENBQWYsQ0FBWCxDQWR0QjtBQWVUaEUsd0JBQWtCOUQsZUFBZThILE1BQU0sV0FBTixDQUFmLENBZlQ7QUFnQlRqRSxrQkFBWTdELGVBQWU4SCxNQUFNLFdBQU4sQ0FBZjtBQWhCSCxLQUFiO0FBa0JILEdBbkJEO0FBcUJBLFNBQU8vSSxPQUFQO0FBQ0g7O0FBRURMLEtBQUtLLE9BQUwsQ0FBYThCLFFBQWIsQ0FBc0JXLE1BQXRCLENBQTZCRixPQUE3QixHQUF1QyxVQUFTZCxNQUFULEVBQWlCWSxNQUFqQixFQUF5QjtBQUM1RCxRQUFNMkgsYUFBYTtBQUNmb0Qsc0JBQWtCL0ssT0FBT2YsZ0JBQVAsSUFBMkIsRUFEOUI7QUFFZmdLLGlCQUFhakosT0FBT21DLFdBQVAsR0FBcUJuQyxPQUFPbUMsV0FBNUIsR0FBMEMsRUFGeEM7QUFHZitHLGVBQVdsSixPQUFPb0MsU0FISDtBQUlmK0cscUJBQWlCbkosT0FBT3VDLGVBQVAsR0FBeUJ2QyxPQUFPdUMsZUFBaEMsR0FBa0QsRUFKcEQ7QUFLZjZHLHNCQUFrQixFQUxIO0FBTWZNLGVBQVcsRUFOSTtBQU9mc0IsZUFBVyxFQVBJO0FBUWZDLDRCQUF3QixFQVJUO0FBU2ZDLHNCQUFrQixFQVRIO0FBVWZDLGdCQUFZLEVBVkc7QUFXZkMsYUFBUyxFQVhNO0FBWWZDLGdDQUE0QixFQVpiO0FBYWZDLG1DQUErQixFQWJoQjtBQWNmakMsdUJBQW1CO0FBZEosR0FBbkI7QUFpQkEsUUFBTWUsU0FBUyxJQUFJQyxhQUFKLENBQWtCakwsT0FBT2tMLElBQXpCLEVBQStCbEwsT0FBT21MLFFBQXRDLENBQWY7QUFDQSxRQUFNMU0sT0FBT3VNLE9BQU9tQixXQUFQLENBQW1Cbk0sT0FBTzBELFFBQTFCLEVBQW9DNkUsVUFBcEMsQ0FBYjtBQUVBLFNBQU9uQixvQkFBb0IzSSxLQUFLNkgsT0FBekIsQ0FBUDtBQUNILENBdEJELEM7Ozs7Ozs7Ozs7O0FDOUJBLElBQUlwSSxJQUFKO0FBQVNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNILE9BQUtJLENBQUwsRUFBTztBQUFDSixXQUFLSSxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBQThELElBQUlVLGVBQUo7QUFBb0JiLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwyQkFBUixDQUFiLEVBQWtEO0FBQUNXLGtCQUFnQlYsQ0FBaEIsRUFBa0I7QUFBQ1Usc0JBQWdCVixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBbEQsRUFBMEYsQ0FBMUY7O0FBRzNGOzs7QUFHQSxNQUFNOE4sb0JBQW9CO0FBQ3RCQyxTQUFPLENBRGU7QUFFdEJDLFVBQVEsS0FBSyxFQUFMLEdBQVUsRUFBVixHQUFlLElBRkQ7QUFFTztBQUM3QkMsV0FBUyxFQUhhO0FBSXRCQyxjQUFZLFVBQVVDLFVBQVYsRUFBc0I7QUFDOUIsV0FBTyxPQUFPQSxVQUFQLEtBQXNCLFFBQXRCLElBQWtDQSxXQUFXbk4sTUFBWCxHQUFvQixDQUE3RDtBQUNILEdBTnFCO0FBT3RCb04sT0FBSyxVQUFVRCxVQUFWLEVBQXNCO0FBQ3ZCLFFBQUlFLFFBQVEsSUFBWjs7QUFDQSxRQUFJLEtBQUtKLE9BQUwsQ0FBYUssY0FBYixDQUE0QkgsVUFBNUIsQ0FBSixFQUE2QztBQUN6Q0UsY0FBUSxLQUFLSixPQUFMLENBQWFFLFVBQWIsQ0FBUixDQUR5QyxDQUV6Qzs7QUFDQSxVQUFLcEMsS0FBS3dDLEdBQUwsS0FBYUYsTUFBTUcsSUFBcEIsR0FBNEIsS0FBS1IsTUFBckMsRUFBNkM7QUFDekM7QUFDQSxlQUFPLEtBQUtDLE9BQUwsQ0FBYUUsVUFBYixDQUFQO0FBQ0EsYUFBS0osS0FBTDtBQUNBTSxnQkFBUSxJQUFSO0FBQ0g7QUFDSjs7QUFDRCxXQUFPQSxLQUFQO0FBQ0gsR0FwQnFCO0FBcUJ0QkksT0FBSyxVQUFVSixLQUFWLEVBQWlCO0FBQ2xCLFFBQUksS0FBS0gsVUFBTCxDQUFnQkcsTUFBTUssR0FBdEIsQ0FBSixFQUFnQztBQUM1QixVQUFJUCxhQUFhRSxNQUFNSyxHQUF2Qjs7QUFDQSxVQUFJLEtBQUtULE9BQUwsQ0FBYUssY0FBYixDQUE0QkgsVUFBNUIsTUFBNEMsSUFBaEQsRUFBc0Q7QUFDbEQsYUFBS0osS0FBTCxHQURrRCxDQUNwQztBQUNqQjs7QUFDRE0sWUFBTUcsSUFBTixHQUFhekMsS0FBS3dDLEdBQUwsRUFBYjtBQUNBLFdBQUtOLE9BQUwsQ0FBYUUsVUFBYixJQUEyQkUsS0FBM0IsQ0FONEIsQ0FPNUI7QUFDSDtBQUNKO0FBL0JxQixDQUExQjtBQWtDQTs7Ozs7Ozs7QUFPQSxTQUFTakUsUUFBVCxDQUFrQjFJLE1BQWxCLEVBQTBCSCxnQkFBMUIsRUFBNEM7QUFDeEMsU0FBT0csT0FBT3dMLFFBQVAsR0FBa0IsV0FBbEIsR0FBZ0MzTCxnQkFBaEMsR0FBbUQsV0FBMUQ7QUFDSDtBQUVEOzs7Ozs7Ozs7QUFPQSxTQUFTb04sb0JBQVQsQ0FBOEJqTixNQUE5QixFQUFzQ0gsZ0JBQXRDLEVBQXdENEIsaUJBQXhELEVBQTJFUSxjQUEzRSxFQUEyRjtBQUN2RixRQUFNaUwsU0FBUyxFQUFmO0FBRUFBLFNBQU90TyxJQUFQLENBQVksa0JBQVo7QUFDQXNPLFNBQU90TyxJQUFQLENBQWEsWUFBV2lCLGdCQUFpQixFQUF6QztBQUNBcU4sU0FBT3RPLElBQVAsQ0FBYSxhQUFZNkMsaUJBQWtCLEVBQTNDO0FBQ0F5TCxTQUFPdE8sSUFBUCxDQUFhLGFBQVlxRCxjQUFlLEVBQXhDO0FBQ0FpTCxTQUFPdE8sSUFBUCxDQUFZLGlDQUFaO0FBQ0FzTyxTQUFPdE8sSUFBUCxDQUFZLGtCQUFaO0FBRUEsU0FBUSxHQUFFb0IsT0FBT2lHLFdBQVksSUFBR2lILE9BQU9wTyxJQUFQLENBQVksR0FBWixDQUFpQixFQUFqRDtBQUNIOztBQUVELFNBQVNxTyxzQkFBVCxDQUFnQ25OLE1BQWhDLEVBQXdDSCxnQkFBeEMsRUFBMEQ0QixpQkFBMUQsRUFBNkVRLGNBQTdFLEVBQTZGO0FBQ3pGLFNBQVEsR0FBRWpDLE9BQU93TCxRQUFTLFlBQVczTCxnQkFBaUIsV0FBVTRCLGlCQUFrQixjQUFhUSxjQUFlLEVBQTlHO0FBQ0g7O0FBRUQsU0FBU21MLDJCQUFULENBQXFDcE4sTUFBckMsRUFBNkNILGdCQUE3QyxFQUErRDRCLGlCQUEvRCxFQUFrRlEsY0FBbEYsRUFBa0dvTCxLQUFsRyxFQUF5RztBQUNyRyxRQUFNQyxnQkFBZ0JILHVCQUF1Qm5OLE1BQXZCLEVBQStCSCxnQkFBL0IsRUFBaUQ0QixpQkFBakQsRUFBb0VRLGNBQXBFLENBQXRCO0FBQ0FvTCxVQUFRQSxTQUFTLElBQVQsSUFBaUIsQ0FBekI7QUFFQSxTQUFRLEdBQUVDLGFBQWMsV0FBVUQsS0FBTSxFQUF4QztBQUNIO0FBRUQ7Ozs7Ozs7Ozs7QUFRQSxTQUFTMUsseUJBQVQsQ0FBbUNwQixRQUFuQyxFQUE2QztBQUN6QztBQUNBO0FBQ0E7QUFDQSxNQUFJcUIsc0JBQXNCckIsU0FBUyxVQUFULENBQTFCOztBQUNBLE1BQUlxQix1QkFBdUJBLG9CQUFvQm5ELEtBQTNDLElBQW9EbUQsb0JBQW9CbkQsS0FBcEIsQ0FBMEJILE1BQWxGLEVBQTBGO0FBQ3RGLFdBQU9zRCxvQkFBb0JuRCxLQUFwQixDQUEwQixDQUExQixFQUE2QixVQUE3QixFQUF5Q0EsS0FBekMsQ0FBK0MsQ0FBL0MsQ0FBUDtBQUNIO0FBQ0o7O0FBRUQsU0FBUzhOLGVBQVQsQ0FBeUJ2TixNQUF6QixFQUFpQ3VCLFFBQWpDLEVBQTJDaU0sR0FBM0MsRUFBZ0RDLGFBQWhELEVBQStEO0FBQzNELFFBQU1DLE1BQU0sRUFBWjtBQUNBLFFBQU1DLGdCQUFnQkYsY0FBYyxDQUFkLENBQXRCO0FBQ0EsUUFBTUcsT0FBT0gsY0FBYyxDQUFkLENBQWI7QUFDQSxRQUFNdkwsTUFBTWdFLFVBQVVDLFVBQVYsQ0FBcUI1RSxTQUFTaU0sR0FBVCxFQUFjSyxXQUFuQyxFQUFnRDdOLE1BQWhELENBQVo7QUFDQSxRQUFNdkIsT0FBT21LLFNBQVNrRixXQUFULENBQXFCNUwsR0FBckIsQ0FBYjs7QUFFQSxPQUFLLElBQUk3QyxJQUFJLENBQWIsRUFBZ0JBLElBQUlzTyxhQUFwQixFQUFtQ3RPLEdBQW5DLEVBQXdDO0FBQ3BDLFFBQUd1TyxTQUFTLEVBQVosRUFBZ0I7QUFDWkYsVUFBSXJPLENBQUosSUFBU1osS0FBS3NQLFlBQUwsQ0FBa0IxTyxJQUFFLENBQXBCLENBQVQ7QUFDSCxLQUZELE1BRU87QUFDSHFPLFVBQUlyTyxDQUFKLElBQVNaLEtBQUt1UCxTQUFMLENBQWUzTyxDQUFmLENBQVQ7QUFDSDtBQUNKOztBQUVELFNBQU9xTyxHQUFQO0FBQ0g7QUFFRDs7Ozs7Ozs7O0FBT0EsU0FBU08sZ0JBQVQsQ0FBMEJqTyxNQUExQixFQUFrQ3VCLFFBQWxDLEVBQTRDa00sYUFBNUMsRUFBMkQ7QUFFdkQsTUFBSWQsUUFBUSxJQUFaO0FBQUEsTUFDSUYsYUFBYTdELFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0FEakI7O0FBR0EsTUFBSTZLLGtCQUFrQkksVUFBbEIsQ0FBNkJDLFVBQTdCLENBQUosRUFBOEM7QUFDMUNFLFlBQVFQLGtCQUFrQk0sR0FBbEIsQ0FBc0JELFVBQXRCLENBQVI7QUFDSCxHQUZELE1BRU87QUFDSEEsaUJBQWEsSUFBYjtBQUNIOztBQUVELE1BQUksQ0FBQ0UsS0FBTCxFQUFZO0FBQ1I7QUFDQSxRQUFJO0FBQ0EsVUFBSXVCLENBQUosRUFBT0MsQ0FBUCxFQUFVQyxDQUFWO0FBQ0FGLFVBQUlYLGdCQUFnQnZOLE1BQWhCLEVBQXdCdUIsUUFBeEIsRUFBa0MsVUFBbEMsRUFBOENrTSxhQUE5QyxDQUFKO0FBQ0FVLFVBQUlaLGdCQUFnQnZOLE1BQWhCLEVBQXdCdUIsUUFBeEIsRUFBa0MsVUFBbEMsRUFBOENrTSxhQUE5QyxDQUFKO0FBQWlFO0FBQ2pFVyxVQUFJYixnQkFBZ0J2TixNQUFoQixFQUF3QnVCLFFBQXhCLEVBQWtDLFVBQWxDLEVBQThDa00sYUFBOUMsQ0FBSjtBQUFpRTtBQUVqRWQsY0FBUTtBQUFFMEIsYUFBS0gsQ0FBUDtBQUFVSSxlQUFPSCxDQUFqQjtBQUFvQkksY0FBTUg7QUFBMUIsT0FBUjs7QUFDQSxVQUFJM0IsZUFBZSxJQUFuQixFQUF5QjtBQUNyQjtBQUNBRSxjQUFNSyxHQUFOLEdBQVlQLFVBQVo7QUFDQUwsMEJBQWtCVyxHQUFsQixDQUFzQkosS0FBdEI7QUFDSDtBQUNKLEtBWkQsQ0FZRSxPQUFPbE0sS0FBUCxFQUFjO0FBQ1p2QyxXQUFLNEIsR0FBTCxDQUFTVyxLQUFULENBQWdCLElBQUdBLE1BQU0rTixJQUFLLEtBQUkvTixNQUFNZ08sT0FBUSxFQUFoRDtBQUNIO0FBQ0o7O0FBRUQsU0FBTzlCLEtBQVA7QUFFSDs7QUFFRCxTQUFTK0Isd0JBQVQsQ0FBa0NsTSxPQUFsQyxFQUEyQztBQUN2QyxRQUFNbU0sNkJBQTZCO0FBQy9CLGdCQUFZLGlCQURtQjtBQUUvQixnQkFBWTtBQUZtQixHQUFuQzs7QUFLQSxNQUFHLENBQUNuTSxPQUFELElBQVksQ0FBQ0EsUUFBUS9DLEtBQXJCLElBQThCLENBQUMrQyxRQUFRL0MsS0FBUixDQUFjSCxNQUFoRCxFQUF3RDtBQUNwRDtBQUNIOztBQUVELFFBQU1vRCxRQUFRRixRQUFRL0MsS0FBUixDQUFjLENBQWQsQ0FBZDtBQUNBLFNBQU9rUCwyQkFBMkJqTSxLQUEzQixDQUFQO0FBQ0g7O0FBRUQsU0FBU2tNLDBCQUFULENBQW9Dck4sUUFBcEMsRUFBOEM7QUFDMUMsUUFBTW1DLFdBQVdrRixTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBQWpCOztBQUVBLE1BQUltQyxhQUFhLElBQWpCLEVBQXVCO0FBQ25CO0FBQ0g7O0FBRUQsUUFBTW1MLDBCQUEwQnROLFNBQVMsVUFBVCxDQUFoQzs7QUFDQSxNQUFLc04sNEJBQTRCQyxTQUE3QixJQUEyQyxDQUFDRCx3QkFBd0JwUCxLQUFwRSxJQUE2RSxDQUFDb1Asd0JBQXdCcFAsS0FBeEIsQ0FBOEJILE1BQWhILEVBQXdIO0FBQ3BIO0FBQ0g7O0FBRUQsUUFBTXlQLGtDQUFrQ0Ysd0JBQXdCcFAsS0FBeEIsQ0FBOEIsQ0FBOUIsQ0FBeEM7QUFDQSxTQUFPO0FBQ0h1UCxrQ0FBOEJwRyxTQUFTQyxTQUFULENBQW1Ca0csZ0NBQWdDLFVBQWhDLENBQW5CLENBRDNCO0FBRUhFLDJCQUF1QnJHLFNBQVNzRyxTQUFULENBQW1CSCxnQ0FBZ0MsVUFBaEMsQ0FBbkIsQ0FGcEI7QUFHSEksMEJBQXNCdkcsU0FBU3NHLFNBQVQsQ0FBbUJILGdDQUFnQyxVQUFoQyxDQUFuQjtBQUhuQixHQUFQO0FBS0g7QUFFRDs7Ozs7Ozs7Ozs7O0FBVUEsU0FBUzlOLHlCQUFULENBQW1DakIsTUFBbkMsRUFBMkNILGdCQUEzQyxFQUE2RHFCLFVBQTdELEVBQXlFO0FBQ3JFLE1BQUlDLFlBQVksRUFBaEI7QUFDQSxNQUFJQyxhQUFhLEVBQWpCOztBQUVBLE1BQUksQ0FBQ0YsV0FBVzVCLE1BQWhCLEVBQXdCO0FBQ3BCO0FBQ0g7O0FBRUQsTUFBSXVELGFBQWEzQixXQUFXLENBQVgsQ0FBakI7O0FBQ0EsTUFBSSxDQUFDMkIsVUFBTCxFQUFpQjtBQUNiO0FBQ0g7O0FBRUQsTUFBSUMsWUFBWTtBQUNaMUIsZ0JBQVlBLFVBREE7QUFFWjJCLGlCQUFhNkYsU0FBUzRCLE9BQVQsQ0FBaUIzSCxXQUFXLFVBQVgsQ0FBakIsQ0FGRDtBQUdaRyxlQUFXNEYsU0FBU0MsU0FBVCxDQUFtQmhHLFdBQVcsVUFBWCxDQUFuQixDQUhDO0FBSVp1TSxnQkFBWXhHLFNBQVNzRyxTQUFULENBQW1Cck0sV0FBVyxVQUFYLENBQW5CLENBSkE7QUFLWndNLGlCQUFhekcsU0FBU3NHLFNBQVQsQ0FBbUJyTSxXQUFXLFVBQVgsQ0FBbkIsQ0FMRDtBQU1aeU0sbUJBQWUxRyxTQUFTc0csU0FBVCxDQUFtQnJNLFdBQVcsVUFBWCxDQUFuQixDQU5IO0FBT1pNLHFCQUFpQnlGLFNBQVNDLFNBQVQsQ0FBbUJoRyxXQUFXLFVBQVgsQ0FBbkIsQ0FQTDtBQVFaTyxlQUFXd0YsU0FBU0MsU0FBVCxDQUFtQmhHLFdBQVcsVUFBWCxDQUFuQixDQVJDO0FBU1pRLGdCQUFZdUYsU0FBU0MsU0FBVCxDQUFtQmhHLFdBQVcsVUFBWCxDQUFuQixDQVRBO0FBVVpTLHNCQUFrQnNGLFNBQVNDLFNBQVQsQ0FBbUJoRyxXQUFXLFVBQVgsQ0FBbkIsQ0FWTjtBQVdaVSxnQkFBWXFGLFNBQVNDLFNBQVQsQ0FBbUJoRyxXQUFXLFVBQVgsQ0FBbkIsQ0FYQTtBQVlaaEQsc0JBQWtCK0ksU0FBU0MsU0FBVCxDQUFtQmhHLFdBQVcsVUFBWCxDQUFuQixDQVpOO0FBYVpXLHFCQUFpQm9GLFNBQVNDLFNBQVQsQ0FBbUJoRyxXQUFXLFVBQVgsQ0FBbkI7QUFiTCxHQUFoQjtBQWdCQTNCLGFBQVdHLE9BQVgsQ0FBbUIsVUFBU0UsUUFBVCxFQUFtQjtBQUNsQyxRQUFJRSxvQkFBb0JtSCxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBQXhCO0FBQ0EsUUFBSUcsU0FBU1AsVUFBVU0saUJBQVYsQ0FBYjs7QUFDQSxRQUFJLENBQUNDLE1BQUwsRUFBYTtBQUNUQSxlQUFTO0FBQ0wrQiwyQkFBbUJtRixTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBRGQ7QUFFTG1DLGtCQUFVa0YsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQUZMO0FBR0xFLDJCQUFtQkEsaUJBSGQ7QUFJTEUsc0JBQWNpSCxTQUFTc0csU0FBVCxDQUFtQjNOLFNBQVMsVUFBVCxDQUFuQixDQUpUO0FBS0xnTyxvQkFBWTNHLFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0FMUDtBQU1MaU8sb0JBQVk1RyxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBTlA7QUFPTEssbUJBQVc7QUFQTixPQUFUO0FBU0FULGdCQUFVTSxpQkFBVixJQUErQkMsTUFBL0I7QUFDQU4saUJBQVd4QyxJQUFYLENBQWdCOEMsTUFBaEI7QUFDSDs7QUFFRCxRQUFJTyxpQkFBaUIyRyxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBQXJCO0FBRUEsVUFBTXlFLFVBQVVpSCxxQkFBcUJqTixNQUFyQixFQUE2QkgsZ0JBQTdCLEVBQStDNEIsaUJBQS9DLEVBQWtFUSxjQUFsRSxDQUFoQjtBQUNBLFVBQU1xTCxnQkFBZ0JILHVCQUF1Qm5OLE1BQXZCLEVBQStCSCxnQkFBL0IsRUFBaUQ0QixpQkFBakQsRUFBb0VRLGNBQXBFLENBQXRCO0FBQ0EsVUFBTXNKLFlBQVk2Qiw0QkFBNEJwTixNQUE1QixFQUFvQ0gsZ0JBQXBDLEVBQXNENEIsaUJBQXRELEVBQXlFUSxjQUF6RSxDQUFsQjtBQUVBLFFBQUkwQixrQkFBa0I7QUFDbEJDLGlCQUFXZ0YsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQURPO0FBRWxCWSxtQkFBYXlHLFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0FGSztBQUdsQm1DLGdCQUFVa0YsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQUhRO0FBSWxCVSxzQkFBZ0JBLGNBSkU7QUFLbEJHLHNCQUFnQndHLFNBQVNzRyxTQUFULENBQW1CM04sU0FBUyxVQUFULENBQW5CLENBTEU7QUFNbEJzQyw0QkFBc0IrRSxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBTko7QUFPbEJ1QywrQkFBeUI4RSxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBUFA7QUFRbEJ3QywyQkFBcUI2RSxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBUkg7QUFTbEIwQyxxQkFBZTJFLFNBQVNzRyxTQUFULENBQW1CM04sU0FBUyxVQUFULENBQW5CLENBVEc7QUFVbEI0Qyx1QkFBaUJ5RSxTQUFTc0csU0FBVCxDQUFtQjNOLFNBQVMsVUFBVCxDQUFuQixDQVZDO0FBV2xCNkMsaUNBQTJCd0UsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQVhUO0FBWWxCOEMsMkJBQXFCdUUsU0FBU3NHLFNBQVQsQ0FBbUIzTixTQUFTLFVBQVQsQ0FBbkIsQ0FaSDtBQWFsQitDLFlBQU1zRSxTQUFTc0csU0FBVCxDQUFtQjNOLFNBQVMsVUFBVCxDQUFuQixDQWJZO0FBY2xCZ0QsZUFBU3FFLFNBQVNzRyxTQUFULENBQW1CM04sU0FBUyxVQUFULENBQW5CLENBZFM7QUFlbEJpRCxvQkFBY29FLFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0FmSTtBQWdCbEJrTyx3QkFBa0I3RyxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBaEJBO0FBaUJsQmtELHFCQUFlbUUsU0FBU3NHLFNBQVQsQ0FBbUIzTixTQUFTLFVBQVQsQ0FBbkIsQ0FqQkc7QUFrQmxCbUQsa0JBQVlrRSxTQUFTc0csU0FBVCxDQUFtQjNOLFNBQVMsVUFBVCxDQUFuQixDQWxCTTtBQW1CbEJvRCxlQUFTaUUsU0FBU3NHLFNBQVQsQ0FBbUIzTixTQUFTLFVBQVQsQ0FBbkIsQ0FuQlM7QUFvQmxCcUQsMkJBQXFCZ0UsU0FBU3NHLFNBQVQsQ0FBbUIzTixTQUFTLFVBQVQsQ0FBbkIsQ0FwQkg7QUFxQmxCbU8sMEJBQW9COUcsU0FBU3NHLFNBQVQsQ0FBbUIzTixTQUFTLFVBQVQsQ0FBbkIsQ0FyQkY7QUFzQmxCb08seUJBQW1CL0csU0FBU3NHLFNBQVQsQ0FBbUIzTixTQUFTLFVBQVQsQ0FBbkIsQ0F0QkQ7QUF1QmxCc0Qsb0JBQWMrRCxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBdkJJO0FBd0JsQnVELG1CQUFhOEQsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQXhCSztBQXlCbEJ3RCx3QkFBa0I2RCxTQUFTc0csU0FBVCxDQUFtQjNOLFNBQVMsVUFBVCxDQUFuQixDQXpCQTtBQTBCbEJ5RCxvQkFBYzRELFNBQVNzRyxTQUFULENBQW1CM04sU0FBUyxVQUFULENBQW5CLENBMUJJO0FBMkJsQnFPLG1CQUFhaEgsU0FBU3NHLFNBQVQsQ0FBbUIzTixTQUFTLFVBQVQsQ0FBbkIsQ0EzQks7QUE0QmxCMEQsOEJBQXdCdEMsMEJBQTBCcEIsUUFBMUIsQ0E1Qk47QUE2QmxCMkQsa0JBQVkwRCxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBN0JNO0FBOEJsQjRELG9CQUFjeUQsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQTlCSTtBQStCbEI2RCwyQkFBcUJ3RCxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBL0JIO0FBZ0NsQjhELHNCQUFnQnVELFNBQVNzRyxTQUFULENBQW1CM04sU0FBUyxVQUFULENBQW5CLENBaENFO0FBaUNsQitELDZCQUF1Qm9KLHlCQUF5Qm5OLFNBQVMsVUFBVCxDQUF6QixDQWpDTDtBQWtDbEJnRSxpQkFBV3FELFNBQVNzRyxTQUFULENBQW1CM04sU0FBUyxVQUFULENBQW5CLENBbENPO0FBbUNsQmlFLHVCQUFpQnhHLGdCQUFnQjRKLFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0FBaEIsQ0FuQ0M7QUFvQ2xCeUMsc0JBQWdCNEUsU0FBU3NHLFNBQVQsQ0FBbUIzTixTQUFTLFVBQVQsQ0FBbkIsQ0FwQ0U7QUFxQ2xCa0UsNkJBQXVCbUQsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQXJDTDtBQXNDbEJtRSw2QkFBdUJrRCxTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBdENMO0FBdUNsQm9FLGtDQUE0QmlELFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0F2Q1Y7QUF3Q2xCcUUsbUNBQTZCZ0QsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQXhDWDtBQXlDbEJ1RSxrQkFBWThDLFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0F6Q007QUEwQ2xCd0UsMEJBQW9CNkMsU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQTFDRjtBQTJDbEJzTiwrQkFBeUJELDJCQUEyQnJOLFFBQTNCLENBM0NQO0FBNENsQitMLHFCQUFlQSxhQTVDRztBQTZDbEJ0SCxlQUFTRSxVQUFVQyxVQUFWLENBQXFCSCxPQUFyQixFQUE4QmhHLE1BQTlCLENBN0NTO0FBOENsQnVMLGlCQUFXckYsVUFBVUMsVUFBVixDQUFxQm9GLFNBQXJCLEVBQWdDdkwsTUFBaEMsQ0E5Q087QUErQ2xCc0wsc0JBQWdCdEwsT0FBT3NMLGNBL0NMO0FBZ0RsQnVFLDBCQUFvQjdQLE9BQU82UDtBQWhEVCxLQUF0QixDQXZCa0MsQ0EwRWxDOztBQUNBLFFBQUlsTSxnQkFBZ0JTLHlCQUFoQixLQUE4QyxlQUFsRCxFQUFtRTtBQUMvRCxZQUFNMEwsdUNBQXVDOVEsZ0JBQWdCNEosU0FBU0MsU0FBVCxDQUFtQnRILFNBQVMsVUFBVCxDQUFuQixDQUFoQixDQUE3QztBQUNBLFlBQU13Tyx5Q0FBeUMvUSxnQkFBZ0I0SixTQUFTQyxTQUFULENBQW1CdEgsU0FBUyxVQUFULENBQW5CLENBQWhCLENBQS9DO0FBQ0EsWUFBTXlPLHdDQUF3Q2hSLGdCQUFnQjRKLFNBQVNDLFNBQVQsQ0FBbUJ0SCxTQUFTLFVBQVQsQ0FBbkIsQ0FBaEIsQ0FBOUM7QUFDQSxZQUFNME8sV0FBV2hDLGlCQUFpQmpPLE1BQWpCLEVBQXlCdUIsUUFBekIsRUFBbUN1TyxvQ0FBbkMsQ0FBakI7O0FBRUEsVUFBSUcsUUFBSixFQUFjO0FBQ1YsWUFBSUEsU0FBU2pELEdBQWIsRUFBa0I7QUFDZHJKLDBCQUFnQnVNLDBCQUFoQixHQUE2Q0QsU0FBU2pELEdBQXREO0FBQ0g7O0FBQ0RySix3QkFBZ0J3TSw4QkFBaEIsR0FBaURGLFNBQVM1QixHQUExRDtBQUNBMUssd0JBQWdCeU0sZ0NBQWhCLEdBQW1ESCxTQUFTM0IsS0FBNUQ7QUFDQTNLLHdCQUFnQjBNLCtCQUFoQixHQUFrREosU0FBUzFCLElBQTNEO0FBQ0E1Syx3QkFBZ0JtTSxvQ0FBaEIsR0FBdURBLG9DQUF2RDtBQUNBbk0sd0JBQWdCb00sc0NBQWhCLEdBQXlEQSxzQ0FBekQ7QUFDQXBNLHdCQUFnQnFNLHFDQUFoQixHQUF3REEscUNBQXhEO0FBQ0g7QUFDSjs7QUFFRHRPLFdBQU9FLFNBQVAsQ0FBaUJoRCxJQUFqQixDQUFzQitFLGVBQXRCO0FBRUgsR0FoR0Q7QUFrR0EsU0FBT2IsU0FBUDtBQUNIO0FBRUQ7Ozs7Ozs7O0FBTUE1RSxLQUFLSyxPQUFMLENBQWE4QixRQUFiLENBQXNCQyxJQUF0QixDQUEyQkMsZ0JBQTNCLEdBQThDLFVBQVNQLE1BQVQsRUFBaUJILGdCQUFqQixFQUFtQztBQUM3RSxNQUFJaUosTUFBTUosU0FBUzFJLE1BQVQsRUFBaUJILGdCQUFqQixDQUFWOztBQUVBLE1BQUk7QUFDQSxRQUFJWCxTQUFTMEosU0FBU0csT0FBVCxDQUFpQkQsR0FBakIsRUFBc0I5SSxPQUFPZ0osY0FBN0IsQ0FBYjtBQUVBLFFBQUkxQixRQUFRckcsMEJBQTBCakIsTUFBMUIsRUFBa0NILGdCQUFsQyxFQUFvRFgsT0FBT1QsSUFBM0QsQ0FBWjs7QUFDQSxRQUFJLENBQUM2SSxLQUFMLEVBQVk7QUFDUkEsY0FBUSxFQUFSO0FBQ0g7O0FBRURBLFVBQU1yQixXQUFOLEdBQW9CakcsT0FBT2lHLFdBQTNCO0FBQ0FxQixVQUFNekgsZ0JBQU4sR0FBeUJBLGdCQUF6QjtBQUVBLFdBQU95SCxLQUFQO0FBQ0gsR0FaRCxDQVlFLE9BQU83RyxLQUFQLEVBQWM7QUFDWnZDLFNBQUs0QixHQUFMLENBQVNZLEtBQVQ7QUFFQSxVQUFNRCxLQUFOO0FBQ0g7QUFDSixDQXBCRCxDIiwiZmlsZSI6Ii9wYWNrYWdlcy9vaGlmX3N0dWRpZXMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG5cbk9ISUYuc3R1ZGllcyA9IHt9O1xuXG5yZXF1aXJlKCcuLi9pbXBvcnRzL2JvdGgnKTtcbiIsInJlcXVpcmUoJy4uL2ltcG9ydHMvc2VydmVyJyk7XG4iLCJpbXBvcnQgJy4vbGliJztcbmltcG9ydCAnLi9tZXRob2RzJztcbmltcG9ydCAnLi9zZXJ2aWNlcyc7XG4iLCIvKipcbiAqIENvbnZlcnRzIHRoZSBwcm9wZXJ0aWVzIHRvIFVSTCBxdWVyeSBwYXJhbWV0ZXJzLiAgQmFzZWQgb246XG4gKiBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzExMTUyOS9jcmVhdGUtcXVlcnktcGFyYW1ldGVycy1pbi1qYXZhc2NyaXB0XG4gKlxuICogQHBhcmFtIGRhdGFcbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbmVuY29kZVF1ZXJ5RGF0YSA9IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICB2YXIgcmV0ID0gW107XG5cbiAgICBmb3IgKHZhciBkIGluIGRhdGEpIHtcbiAgICAgICAgaWYgKGRhdGFbZF0pIHtcbiAgICAgICAgICAgIHJldC5wdXNoKGVuY29kZVVSSUNvbXBvbmVudChkKSArICc9JyArIGVuY29kZVVSSUNvbXBvbmVudChkYXRhW2RdKSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gcmV0LmpvaW4oJyYnKTtcbn07XG4iLCJpbXBvcnQgJy4vcmVtb3RlR2V0VmFsdWUuanMnO1xuaW1wb3J0ICcuL2VuY29kZVF1ZXJ5RGF0YS5qcyc7XG4iLCJleHBvcnQgY29uc3QgcGFyc2VGbG9hdEFycmF5ID0gZnVuY3Rpb24ob2JqKSB7XG4gICAgdmFyIHJlc3VsdCA9IFtdO1xuXG4gICAgaWYgKCFvYmopIHtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG5cbiAgICB2YXIgb2JqcyA9IG9iai5zcGxpdChcIlxcXFxcIik7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBvYmpzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdC5wdXNoKHBhcnNlRmxvYXQob2Jqc1tpXSkpO1xuICAgIH1cblxuICAgIHJldHVybiByZXN1bHQ7XG59O1xuIiwiZXhwb3J0IGNvbnN0IHJlbW90ZUdldFZhbHVlID0gZnVuY3Rpb24ob2JqKSB7XG4gIHJldHVybiBvYmogPyBvYmouVmFsdWUgOiBudWxsO1xufTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgT0hJRiB9IGZyb20gJ21ldGVvci9vaGlmOmNvcmUnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgLyoqXG4gICAgICogUmV0cmlldmVzIFN0dWR5IG1ldGFkYXRhIGdpdmVuIGEgU3R1ZHkgSW5zdGFuY2UgVUlEXG4gICAgICogVGhpcyBNZXRlb3IgbWV0aG9kIGlzIGF2YWlsYWJsZSBmcm9tIGJvdGggdGhlIGNsaWVudCBhbmQgdGhlIHNlcnZlclxuICAgICAqL1xuICAgIEdldFN0dWR5TWV0YWRhdGE6IGZ1bmN0aW9uKHN0dWR5SW5zdGFuY2VVaWQpIHtcbiAgICAgICAgT0hJRi5sb2cuaW5mbygnR2V0U3R1ZHlNZXRhZGF0YSglcyknLCBzdHVkeUluc3RhbmNlVWlkKTtcblxuICAgICAgICAvLyBHZXQgdGhlIHNlcnZlciBkYXRhLiBUaGlzIGlzIHVzZXItZGVmaW5lZCBpbiB0aGUgY29uZmlnLmpzb24gZmlsZXMgb3IgdGhyb3VnaCBzZXJ2ZXJzXG4gICAgICAgIC8vIGNvbmZpZ3VyYXRpb24gbW9kYWxcbiAgICAgICAgY29uc3Qgc2VydmVyID0gT0hJRi5zZXJ2ZXJzLmdldEN1cnJlbnRTZXJ2ZXIoKTtcblxuICAgICAgICBpZiAoIXNlcnZlcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignaW1wcm9wZXItc2VydmVyLWNvbmZpZycsICdObyBwcm9wZXJseSBjb25maWd1cmVkIHNlcnZlciB3YXMgYXZhaWxhYmxlIG92ZXIgRElDT01XZWIgb3IgRElNU0UuJyk7XG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKHNlcnZlci50eXBlID09PSAnZGljb21XZWInKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE9ISUYuc3R1ZGllcy5zZXJ2aWNlcy5XQURPLlJldHJpZXZlTWV0YWRhdGEoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc2VydmVyLnR5cGUgPT09ICdkaW1zZScpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gT0hJRi5zdHVkaWVzLnNlcnZpY2VzLkRJTVNFLlJldHJpZXZlTWV0YWRhdGEoc3R1ZHlJbnN0YW5jZVVpZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBPSElGLmxvZy50cmFjZSgpO1xuXG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0ICcuL2dldFN0dWR5TWV0YWRhdGEuanMnO1xuaW1wb3J0ICcuL3N0dWR5bGlzdFNlYXJjaC5qcyc7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgIC8qKlxuICAgICAqIFVzZSB0aGUgc3BlY2lmaWVkIGZpbHRlciB0byBjb25kdWN0IGEgc2VhcmNoIGZyb20gdGhlIERJQ09NIHNlcnZlclxuICAgICAqXG4gICAgICogQHBhcmFtIGZpbHRlclxuICAgICAqL1xuICAgIFN0dWR5TGlzdFNlYXJjaChmaWx0ZXIpIHtcbiAgICAgICAgLy8gR2V0IHRoZSBzZXJ2ZXIgZGF0YS4gVGhpcyBpcyB1c2VyLWRlZmluZWQgaW4gdGhlIGNvbmZpZy5qc29uIGZpbGVzIG9yIHRocm91Z2ggc2VydmVyc1xuICAgICAgICAvLyBjb25maWd1cmF0aW9uIG1vZGFsXG4gICAgICAgIGNvbnN0IHNlcnZlciA9IE9ISUYuc2VydmVycy5nZXRDdXJyZW50U2VydmVyKCk7XG5cbiAgICAgICAgaWYgKCFzZXJ2ZXIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2ltcHJvcGVyLXNlcnZlci1jb25maWcnLCAnTm8gcHJvcGVybHkgY29uZmlndXJlZCBzZXJ2ZXIgd2FzIGF2YWlsYWJsZSBvdmVyIERJQ09NV2ViIG9yIERJTVNFLicpO1xuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmIChzZXJ2ZXIudHlwZSA9PT0gJ2RpY29tV2ViJykge1xuICAgICAgICAgICAgICAgIHJldHVybiBPSElGLnN0dWRpZXMuc2VydmljZXMuUUlETy5TdHVkaWVzKHNlcnZlciwgZmlsdGVyKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc2VydmVyLnR5cGUgPT09ICdkaW1zZScpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gT0hJRi5zdHVkaWVzLnNlcnZpY2VzLkRJTVNFLlN0dWRpZXMoZmlsdGVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIE9ISUYubG9nLnRyYWNlKCk7XG5cbiAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgfVxufSk7XG4iLCJpbXBvcnQgJy4vbmFtZXNwYWNlLmpzJztcblxuLy8gRElDT01XZWIgaW5zdGFuY2UsIHN0dWR5LCBhbmQgbWV0YWRhdGEgcmV0cmlldmFsXG5pbXBvcnQgJy4vcWlkby9pbnN0YW5jZXMuanMnO1xuaW1wb3J0ICcuL3FpZG8vc3R1ZGllcy5qcyc7XG5pbXBvcnQgJy4vd2Fkby9yZXRyaWV2ZU1ldGFkYXRhLmpzJztcblxuLy8gRElNU0UgaW5zdGFuY2UsIHN0dWR5LCBhbmQgbWV0YWRhdGEgcmV0cmlldmFsXG5pbXBvcnQgJy4vZGltc2UvaW5zdGFuY2VzLmpzJztcbmltcG9ydCAnLi9kaW1zZS9zdHVkaWVzLmpzJztcbmltcG9ydCAnLi9kaW1zZS9yZXRyaWV2ZU1ldGFkYXRhLmpzJztcbmltcG9ydCAnLi9kaW1zZS9zZXR1cC5qcyc7XG5cbi8vIFN0dWR5LCBpbnN0YW5jZSwgYW5kIG1ldGFkYXRhIHJldHJpZXZhbCBmcm9tIHJlbW90ZSBQQUNTIHZpYSBPcnRoYW5jIGFzIGEgcHJveHlcbmltcG9ydCAnLi9yZW1vdGUvaW5zdGFuY2VzLmpzJztcbmltcG9ydCAnLi9yZW1vdGUvc3R1ZGllcy5qcyc7XG5pbXBvcnQgJy4vcmVtb3RlL3JldHJpZXZlTWV0YWRhdGEuanMnO1xuIiwiaW1wb3J0IHsgT0hJRiB9IGZyb20gJ21ldGVvci9vaGlmOmNvcmUnO1xuXG5jb25zdCBTZXJ2aWNlcyA9IHt9O1xuU2VydmljZXMuUUlETyA9IHt9O1xuU2VydmljZXMuV0FETyA9IHt9O1xuU2VydmljZXMuRElNU0UgPSB7fTtcblNlcnZpY2VzLlJFTU9URSA9IHt9O1xuXG5PSElGLnN0dWRpZXMuc2VydmljZXMgPSBTZXJ2aWNlcztcblxucmVtb3RlR2V0VmFsdWUgPSBmdW5jdGlvbihvYmopIHtcbiAgICByZXR1cm4gb2JqID8gb2JqLlZhbHVlIDogbnVsbDtcbn07XG4iLCJpbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG5cbi8qKlxuICogUGFyc2VzIGRhdGEgcmV0dXJuZWQgZnJvbSBhIHN0dWR5IHNlYXJjaCBhbmQgdHJhbnNmb3JtcyBpdCBpbnRvXG4gKiBhbiBhcnJheSBvZiBzZXJpZXMgdGhhdCBhcmUgcHJlc2VudCBpbiB0aGUgc3R1ZHlcbiAqXG4gKiBAcGFyYW0gcmVzdWx0RGF0YVxuICogQHJldHVybnMge0FycmF5fSBTZXJpZXMgTGlzdFxuICovXG5mdW5jdGlvbiByZXN1bHREYXRhVG9TdHVkeU1ldGFkYXRhKHJlc3VsdERhdGEsIHN0dWR5SW5zdGFuY2VVaWQpIHtcbiAgICBjb25zdCBzZXJpZXNNYXAgPSB7fTtcbiAgICBjb25zdCBzZXJpZXNMaXN0ID0gW107XG5cbiAgICByZXN1bHREYXRhLmZvckVhY2goZnVuY3Rpb24oaW5zdGFuY2VSYXcpIHtcbiAgICAgICAgY29uc3QgaW5zdGFuY2UgPSBpbnN0YW5jZVJhdy50b09iamVjdCgpO1xuICAgICAgICAvLyBVc2Ugc2VyaWVzTWFwIHRvIGNhY2hlIHNlcmllcyBkYXRhXG4gICAgICAgIC8vIElmIHRoZSBzZXJpZXMgaW5zdGFuY2UgVUlEIGhhcyBhbHJlYWR5IGJlZW4gdXNlZCB0b1xuICAgICAgICAvLyBwcm9jZXNzIHNlcmllcyBkYXRhLCBjb250aW51ZSB1c2luZyB0aGF0IHNlcmllc1xuICAgICAgICBjb25zdCBzZXJpZXNJbnN0YW5jZVVpZCA9IGluc3RhbmNlWzB4MDAyMDAwMEVdO1xuICAgICAgICBsZXQgc2VyaWVzID0gc2VyaWVzTWFwW3Nlcmllc0luc3RhbmNlVWlkXTtcblxuICAgICAgICAvLyBJZiBubyBzZXJpZXMgZGF0YSBleGlzdHMgaW4gdGhlIHNlcmllc01hcCBjYWNoZSB2YXJpYWJsZSxcbiAgICAgICAgLy8gcHJvY2VzcyBhbnkgYXZhaWxhYmxlIHNlcmllcyBkYXRhXG4gICAgICAgIGlmICghc2VyaWVzKSB7XG4gICAgICAgICAgICBzZXJpZXMgPSB7XG4gICAgICAgICAgICAgICAgc2VyaWVzSW5zdGFuY2VVaWQ6IHNlcmllc0luc3RhbmNlVWlkLFxuICAgICAgICAgICAgICAgIHNlcmllc051bWJlcjogaW5zdGFuY2VbMHgwMDIwMDAxMV0sXG4gICAgICAgICAgICAgICAgaW5zdGFuY2VzOiBbXVxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLy8gU2F2ZSB0aGlzIGRhdGEgaW4gdGhlIHNlcmllc01hcCBjYWNoZSB2YXJpYWJsZVxuICAgICAgICAgICAgc2VyaWVzTWFwW3Nlcmllc0luc3RhbmNlVWlkXSA9IHNlcmllcztcbiAgICAgICAgICAgIHNlcmllc0xpc3QucHVzaChzZXJpZXMpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVE9ETzogQ2hlY2sgd2hpY2ggcGVlciBpdCBzaG91bGQgcG9pbnQgdG9cbiAgICAgICAgY29uc3Qgc2VydmVyID0gT0hJRi5zZXJ2ZXJzLmdldEN1cnJlbnRTZXJ2ZXIoKS5wZWVyc1swXTtcblxuICAgICAgICBjb25zdCBzZXJ2ZXJSb290ID0gc2VydmVyLmhvc3QgKyAnOicgKyBzZXJ2ZXIucG9ydDtcblxuICAgICAgICBjb25zdCBzb3BJbnN0YW5jZVVpZCA9IGluc3RhbmNlWzB4MDAwODAwMThdO1xuICAgICAgICBjb25zdCB1cmkgPSBzZXJ2ZXJSb290ICsgJy9zdHVkaWVzLycgKyBzdHVkeUluc3RhbmNlVWlkICsgJy9zZXJpZXMvJyArIHNlcmllc0luc3RhbmNlVWlkICsgJy9pbnN0YW5jZXMvJyArIHNvcEluc3RhbmNlVWlkICsgJy9mcmFtZXMvMSc7XG5cbiAgICAgICAgLy8gQWRkIHRoaXMgaW5zdGFuY2UgdG8gdGhlIGN1cnJlbnQgc2VyaWVzXG4gICAgICAgIHNlcmllcy5pbnN0YW5jZXMucHVzaCh7XG4gICAgICAgICAgICBzb3BDbGFzc1VpZDogaW5zdGFuY2VbMHgwMDA4MDAxNl0sXG4gICAgICAgICAgICBzb3BJbnN0YW5jZVVpZCxcbiAgICAgICAgICAgIHVyaSxcbiAgICAgICAgICAgIGluc3RhbmNlTnVtYmVyOiBpbnN0YW5jZVsweDAwMjAwMDEzXVxuICAgICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4gc2VyaWVzTGlzdDtcbn1cblxuLyoqXG4gKiBSZXRyaWV2ZSBhIHNldCBvZiBpbnN0YW5jZXMgdXNpbmcgYSBESU1TRSBjYWxsXG4gKiBAcGFyYW0gc3R1ZHlJbnN0YW5jZVVpZFxuICogQHJldHVybnMge3t3YWRvVXJpUm9vdDogU3RyaW5nLCBzdHVkeUluc3RhbmNlVWlkOiBTdHJpbmcsIHNlcmllc0xpc3Q6IEFycmF5fX1cbiAqL1xuT0hJRi5zdHVkaWVzLnNlcnZpY2VzLkRJTVNFLkluc3RhbmNlcyA9IGZ1bmN0aW9uKHN0dWR5SW5zdGFuY2VVaWQpIHtcbiAgICAvL3ZhciB1cmwgPSBidWlsZFVybChzZXJ2ZXIsIHN0dWR5SW5zdGFuY2VVaWQpO1xuICAgIGNvbnN0IHJlc3VsdCA9IERJTVNFLnJldHJpZXZlSW5zdGFuY2VzKHN0dWR5SW5zdGFuY2VVaWQpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgc3R1ZHlJbnN0YW5jZVVpZDogc3R1ZHlJbnN0YW5jZVVpZCxcbiAgICAgICAgc2VyaWVzTGlzdDogcmVzdWx0RGF0YVRvU3R1ZHlNZXRhZGF0YShyZXN1bHQsIHN0dWR5SW5zdGFuY2VVaWQpXG4gICAgfTtcbn07XG4iLCJpbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG5pbXBvcnQgeyBwYXJzZUZsb2F0QXJyYXkgfSBmcm9tICdtZXRlb3Ivb2hpZjpzdHVkaWVzL2ltcG9ydHMvc2VydmVyL2xpYi9wYXJzZUZsb2F0QXJyYXknO1xuXG4vKipcbiAqIFJldHVybnMgdGhlIHZhbHVlIG9mIHRoZSBlbGVtZW50IChlLmcuICcwMDI4MDAwOScpXG4gKlxuICogQHBhcmFtIGVsZW1lbnQgLSBUaGUgZ3JvdXAvZWxlbWVudCBvZiB0aGUgZWxlbWVudCAoZS5nLiAnMDAyODAwMDknKVxuICogQHBhcmFtIGRlZmF1bHRWYWx1ZSAtIFRoZSBkZWZhdWx0IHZhbHVlIHRvIHJldHVybiBpZiB0aGUgZWxlbWVudCBkb2VzIG5vdCBleGlzdFxuICogQHJldHVybnMgeyp9XG4gKi9cbmZ1bmN0aW9uIGdldFZhbHVlKGVsZW1lbnQsIGRlZmF1bHRWYWx1ZSkge1xuICAgIGlmICghZWxlbWVudCB8fCAhZWxlbWVudC52YWx1ZSkge1xuICAgICAgICByZXR1cm4gZGVmYXVsdFZhbHVlO1xuICAgIH1cblxuICAgIHJldHVybiBlbGVtZW50LnZhbHVlO1xufVxuXG4vKipcbiAqIFBhcnNlcyB0aGUgU291cmNlSW1hZ2VTZXF1ZW5jZSwgaWYgaXQgZXhpc3RzLCBpbiBvcmRlclxuICogdG8gcmV0dXJuIGEgUmVmZXJlbmNlU09QSW5zdGFuY2VVSUQuIFRoZSBSZWZlcmVuY2VTT1BJbnN0YW5jZVVJRFxuICogaXMgdXNlZCB0byByZWZlciB0byB0aGlzIGltYWdlIGluIGFueSBhY2NvbXBhbnlpbmcgRElDT00tU1IgZG9jdW1lbnRzLlxuICpcbiAqIEBwYXJhbSBpbnN0YW5jZVxuICogQHJldHVybnMge1N0cmluZ30gVGhlIFJlZmVyZW5jZVNPUEluc3RhbmNlVUlEXG4gKi9cbmZ1bmN0aW9uIGdldFNvdXJjZUltYWdlSW5zdGFuY2VVaWQoaW5zdGFuY2UpIHtcbiAgICAvLyBUT0RPPSBQYXJzZSB0aGUgd2hvbGUgU291cmNlIEltYWdlIFNlcXVlbmNlXG4gICAgLy8gVGhpcyBpcyBhIHJlYWxseSBwb29yIHdvcmthcm91bmQgZm9yIG5vdy5cbiAgICAvLyBMYXRlciB3ZSBzaG91bGQgcHJvYmFibHkgcGFyc2UgdGhlIHdob2xlIHNlcXVlbmNlLlxuICAgIGNvbnN0IFNvdXJjZUltYWdlU2VxdWVuY2UgPSBpbnN0YW5jZVsweDAwMDgyMTEyXTtcbiAgICBpZiAoU291cmNlSW1hZ2VTZXF1ZW5jZSAmJiBTb3VyY2VJbWFnZVNlcXVlbmNlLmxlbmd0aCkge1xuICAgICAgICByZXR1cm4gU291cmNlSW1hZ2VTZXF1ZW5jZVswXVsweDAwMDgxMTU1XTtcbiAgICB9XG59XG5cbi8qKlxuICogUGFyc2VzIHJlc3VsdCBkYXRhIGZyb20gYSBESU1TRSBzZWFyY2ggaW50byBTdHVkeSBNZXRhRGF0YVxuICogUmV0dXJucyBhbiBvYmplY3QgcG9wdWxhdGVkIHdpdGggc3R1ZHkgbWV0YWRhdGEsIGluY2x1ZGluZyB0aGVcbiAqIHNlcmllcyBsaXN0LlxuICpcbiAqIEBwYXJhbSBzdHVkeUluc3RhbmNlVWlkXG4gKiBAcGFyYW0gcmVzdWx0RGF0YVxuICogQHJldHVybnMge3tzZXJpZXNMaXN0OiBBcnJheSwgcGF0aWVudE5hbWU6ICosIHBhdGllbnRJZDogKiwgYWNjZXNzaW9uTnVtYmVyOiAqLCBzdHVkeURhdGU6ICosIG1vZGFsaXRpZXM6ICosIHN0dWR5RGVzY3JpcHRpb246ICosIGltYWdlQ291bnQ6ICosIHN0dWR5SW5zdGFuY2VVaWQ6ICp9fVxuICovXG5mdW5jdGlvbiByZXN1bHREYXRhVG9TdHVkeU1ldGFkYXRhKHN0dWR5SW5zdGFuY2VVaWQsIHJlc3VsdERhdGEpIHtcbiAgICBPSElGLmxvZy5pbmZvKCdyZXN1bHREYXRhVG9TdHVkeU1ldGFkYXRhJyk7XG4gICAgY29uc3Qgc2VyaWVzTWFwID0ge307XG4gICAgY29uc3Qgc2VyaWVzTGlzdCA9IFtdO1xuXG4gICAgaWYgKCFyZXN1bHREYXRhLmxlbmd0aCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgYW5JbnN0YW5jZSA9IHJlc3VsdERhdGFbMF0udG9PYmplY3QoKTtcbiAgICBpZiAoIWFuSW5zdGFuY2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHN0dWR5RGF0YSA9IHtcbiAgICAgICAgc2VyaWVzTGlzdDogc2VyaWVzTGlzdCxcbiAgICAgICAgcGF0aWVudE5hbWU6IGFuSW5zdGFuY2VbMHgwMDEwMDAxMF0sXG4gICAgICAgIHBhdGllbnRJZDogYW5JbnN0YW5jZVsweDAwMTAwMDIwXSxcbiAgICAgICAgcGF0aWVudEJpcnRoRGF0ZTogYW5JbnN0YW5jZVsweDAwMTAwMDMwXSxcbiAgICAgICAgcGF0aWVudFNleDogYW5JbnN0YW5jZVsweDAwMTAwMDQwXSxcbiAgICAgICAgYWNjZXNzaW9uTnVtYmVyOiBhbkluc3RhbmNlWzB4MDAwODAwNTBdLFxuICAgICAgICBzdHVkeURhdGU6IGFuSW5zdGFuY2VbMHgwMDA4MDAyMF0sXG4gICAgICAgIG1vZGFsaXRpZXM6IGFuSW5zdGFuY2VbMHgwMDA4MDA2MV0sXG4gICAgICAgIHN0dWR5RGVzY3JpcHRpb246IGFuSW5zdGFuY2VbMHgwMDA4MTAzMF0sXG4gICAgICAgIGltYWdlQ291bnQ6IGFuSW5zdGFuY2VbMHgwMDIwMTIwOF0sXG4gICAgICAgIHN0dWR5SW5zdGFuY2VVaWQ6IGFuSW5zdGFuY2VbMHgwMDIwMDAwRF0sXG4gICAgICAgIGluc3RpdHV0aW9uTmFtZTogYW5JbnN0YW5jZVsweDAwMDgwMDgwXVxuICAgIH07XG5cbiAgICByZXN1bHREYXRhLmZvckVhY2goZnVuY3Rpb24oaW5zdGFuY2VSYXcpIHtcbiAgICAgICAgY29uc3QgaW5zdGFuY2UgPSBpbnN0YW5jZVJhdy50b09iamVjdCgpO1xuICAgICAgICBjb25zdCBzZXJpZXNJbnN0YW5jZVVpZCA9IGluc3RhbmNlWzB4MDAyMDAwMEVdO1xuICAgICAgICBsZXQgc2VyaWVzID0gc2VyaWVzTWFwW3Nlcmllc0luc3RhbmNlVWlkXTtcbiAgICAgICAgaWYgKCFzZXJpZXMpIHtcbiAgICAgICAgICAgIHNlcmllcyA9IHtcbiAgICAgICAgICAgICAgICBzZXJpZXNEZXNjcmlwdGlvbjogaW5zdGFuY2VbMHgwMDA4MTAzRV0sXG4gICAgICAgICAgICAgICAgbW9kYWxpdHk6IGluc3RhbmNlWzB4MDAwODAwNjBdLFxuICAgICAgICAgICAgICAgIHNlcmllc0luc3RhbmNlVWlkOiBzZXJpZXNJbnN0YW5jZVVpZCxcbiAgICAgICAgICAgICAgICBzZXJpZXNOdW1iZXI6IHBhcnNlRmxvYXQoaW5zdGFuY2VbMHgwMDIwMDAxMV0pLFxuICAgICAgICAgICAgICAgIGluc3RhbmNlczogW11cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBzZXJpZXNNYXBbc2VyaWVzSW5zdGFuY2VVaWRdID0gc2VyaWVzO1xuICAgICAgICAgICAgc2VyaWVzTGlzdC5wdXNoKHNlcmllcyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBzb3BJbnN0YW5jZVVpZCA9IGluc3RhbmNlWzB4MDAwODAwMThdO1xuXG4gICAgICAgIGNvbnN0IGluc3RhbmNlU3VtbWFyeSA9IHtcbiAgICAgICAgICAgIGltYWdlVHlwZTogaW5zdGFuY2VbMHgwMDA4MDAwOF0sXG4gICAgICAgICAgICBzb3BDbGFzc1VpZDogaW5zdGFuY2VbMHgwMDA4MDAxNl0sXG4gICAgICAgICAgICBtb2RhbGl0eTogaW5zdGFuY2VbMHgwMDA4MDA2MF0sXG4gICAgICAgICAgICBzb3BJbnN0YW5jZVVpZDogc29wSW5zdGFuY2VVaWQsXG4gICAgICAgICAgICBpbnN0YW5jZU51bWJlcjogcGFyc2VGbG9hdChpbnN0YW5jZVsweDAwMjAwMDEzXSksXG4gICAgICAgICAgICBpbWFnZVBvc2l0aW9uUGF0aWVudDogaW5zdGFuY2VbMHgwMDIwMDAzMl0sXG4gICAgICAgICAgICBpbWFnZU9yaWVudGF0aW9uUGF0aWVudDogaW5zdGFuY2VbMHgwMDIwMDAzN10sXG4gICAgICAgICAgICBmcmFtZU9mUmVmZXJlbmNlVUlEOiBpbnN0YW5jZVsweDAwMjAwMDUyXSxcbiAgICAgICAgICAgIHNsaWNlVGhpY2tuZXNzOiBwYXJzZUZsb2F0KGluc3RhbmNlWzB4MDAxODAwNTBdKSxcbiAgICAgICAgICAgIHNsaWNlTG9jYXRpb246IHBhcnNlRmxvYXQoaW5zdGFuY2VbMHgwMDIwMTA0MV0pLFxuICAgICAgICAgICAgdGFibGVQb3NpdGlvbjogcGFyc2VGbG9hdChpbnN0YW5jZVsweDAwMTg5MzI3XSksXG4gICAgICAgICAgICBzYW1wbGVzUGVyUGl4ZWw6IHBhcnNlRmxvYXQoaW5zdGFuY2VbMHgwMDI4MDAwMl0pLFxuICAgICAgICAgICAgcGhvdG9tZXRyaWNJbnRlcnByZXRhdGlvbjogaW5zdGFuY2VbMHgwMDI4MDAwNF0sXG4gICAgICAgICAgICBwbGFuYXJDb25maWd1cmF0aW9uOiBwYXJzZUZsb2F0KGluc3RhbmNlWzB4MDAyODAwMDZdKSxcbiAgICAgICAgICAgIHJvd3M6IHBhcnNlRmxvYXQoaW5zdGFuY2VbMHgwMDI4MDAxMF0pLFxuICAgICAgICAgICAgY29sdW1uczogcGFyc2VGbG9hdChpbnN0YW5jZVsweDAwMjgwMDExXSksXG4gICAgICAgICAgICBwaXhlbFNwYWNpbmc6IGluc3RhbmNlWzB4MDAyODAwMzBdLFxuICAgICAgICAgICAgYml0c0FsbG9jYXRlZDogcGFyc2VGbG9hdChpbnN0YW5jZVsweDAwMjgwMTAwXSksXG4gICAgICAgICAgICBiaXRzU3RvcmVkOiBwYXJzZUZsb2F0KGluc3RhbmNlWzB4MDAyODAxMDFdKSxcbiAgICAgICAgICAgIGhpZ2hCaXQ6IHBhcnNlRmxvYXQoaW5zdGFuY2VbMHgwMDI4MDEwMl0pLFxuICAgICAgICAgICAgcGl4ZWxSZXByZXNlbnRhdGlvbjogcGFyc2VGbG9hdChpbnN0YW5jZVsweDAwMjgwMTAzXSksXG4gICAgICAgICAgICB3aW5kb3dDZW50ZXI6IGluc3RhbmNlWzB4MDAyODEwNTBdLFxuICAgICAgICAgICAgd2luZG93V2lkdGg6IGluc3RhbmNlWzB4MDAyODEwNTFdLFxuICAgICAgICAgICAgcmVzY2FsZUludGVyY2VwdDogcGFyc2VGbG9hdChpbnN0YW5jZVsweDAwMjgxMDUyXSksXG4gICAgICAgICAgICByZXNjYWxlU2xvcGU6IHBhcnNlRmxvYXQoaW5zdGFuY2VbMHgwMDI4MTA1M10pLFxuICAgICAgICAgICAgc291cmNlSW1hZ2VJbnN0YW5jZVVpZDogZ2V0U291cmNlSW1hZ2VJbnN0YW5jZVVpZChpbnN0YW5jZSksXG4gICAgICAgICAgICBsYXRlcmFsaXR5OiBpbnN0YW5jZVsweDAwMjAwMDYyXSxcbiAgICAgICAgICAgIHZpZXdQb3NpdGlvbjogaW5zdGFuY2VbMHgwMDE4NTEwMV0sXG4gICAgICAgICAgICBhY3F1aXNpdGlvbkRhdGVUaW1lOiBpbnN0YW5jZVsweDAwMDgwMDJBXSxcbiAgICAgICAgICAgIG51bWJlck9mRnJhbWVzOiBwYXJzZUZsb2F0KGluc3RhbmNlWzB4MDAyODAwMDhdKSxcbiAgICAgICAgICAgIGZyYW1lSW5jcmVtZW50UG9pbnRlcjogZ2V0VmFsdWUoaW5zdGFuY2VbMHgwMDI4MDAwOV0pLFxuICAgICAgICAgICAgZnJhbWVUaW1lOiBwYXJzZUZsb2F0KGluc3RhbmNlWzB4MDAxODEwNjNdKSxcbiAgICAgICAgICAgIGZyYW1lVGltZVZlY3RvcjogcGFyc2VGbG9hdEFycmF5KGluc3RhbmNlWzB4MDAxODEwNjVdKSxcbiAgICAgICAgICAgIGxvc3N5SW1hZ2VDb21wcmVzc2lvbjogaW5zdGFuY2VbMHgwMDI4MjExMF0sXG4gICAgICAgICAgICBkZXJpdmF0aW9uRGVzY3JpcHRpb246IGluc3RhbmNlWzB4MDAyODIxMTFdLFxuICAgICAgICAgICAgbG9zc3lJbWFnZUNvbXByZXNzaW9uUmF0aW86IGluc3RhbmNlWzB4MDAyODIxMTJdLFxuICAgICAgICAgICAgbG9zc3lJbWFnZUNvbXByZXNzaW9uTWV0aG9kOiBpbnN0YW5jZVsweDAwMjgyMTE0XSxcbiAgICAgICAgICAgIHNwYWNpbmdCZXR3ZWVuU2xpY2VzOiBpbnN0YW5jZVsweDAwMTgwMDg4XSxcbiAgICAgICAgICAgIGVjaG9OdW1iZXI6IGluc3RhbmNlWzB4MDAxODAwODZdLFxuICAgICAgICAgICAgY29udHJhc3RCb2x1c0FnZW50OiBpbnN0YW5jZVsweDAwMTgwMDEwXVxuICAgICAgICB9O1xuXG4gICAgICAgIC8vIFJldHJpZXZlIHRoZSBhY3R1YWwgZGF0YSBvdmVyIFdBRE8tVVJJXG4gICAgICAgIGNvbnN0IHNlcnZlciA9IE9ISUYuc2VydmVycy5nZXRDdXJyZW50U2VydmVyKCk7XG4gICAgICAgIGNvbnN0IHdhZG91cmkgPSBgJHtzZXJ2ZXIud2Fkb1VyaVJvb3R9P3JlcXVlc3RUeXBlPVdBRE8mc3R1ZHlVSUQ9JHtzdHVkeUluc3RhbmNlVWlkfSZzZXJpZXNVSUQ9JHtzZXJpZXNJbnN0YW5jZVVpZH0mb2JqZWN0VUlEPSR7c29wSW5zdGFuY2VVaWR9JmNvbnRlbnRUeXBlPWFwcGxpY2F0aW9uJTJGZGljb21gO1xuICAgICAgICBpbnN0YW5jZVN1bW1hcnkud2Fkb3VyaSA9IFdBRE9Qcm94eS5jb252ZXJ0VVJMKHdhZG91cmksIHNlcnZlcik7XG5cbiAgICAgICAgc2VyaWVzLmluc3RhbmNlcy5wdXNoKGluc3RhbmNlU3VtbWFyeSk7XG4gICAgfSk7XG5cbiAgICBzdHVkeURhdGEuc3R1ZHlJbnN0YW5jZVVpZCA9IHN0dWR5SW5zdGFuY2VVaWQ7XG5cbiAgICByZXR1cm4gc3R1ZHlEYXRhO1xufVxuXG4vKipcbiAqIFJldHJpZXZlZCBTdHVkeSBNZXRhRGF0YSBmcm9tIGEgRElDT00gc2VydmVyIHVzaW5nIERJTVNFXG4gKiBAcGFyYW0gc3R1ZHlJbnN0YW5jZVVpZFxuICogQHJldHVybnMge3tzZXJpZXNMaXN0OiBBcnJheSwgcGF0aWVudE5hbWU6ICosIHBhdGllbnRJZDogKiwgYWNjZXNzaW9uTnVtYmVyOiAqLCBzdHVkeURhdGU6ICosIG1vZGFsaXRpZXM6ICosIHN0dWR5RGVzY3JpcHRpb246ICosIGltYWdlQ291bnQ6ICosIHN0dWR5SW5zdGFuY2VVaWQ6ICp9fVxuICovXG5PSElGLnN0dWRpZXMuc2VydmljZXMuRElNU0UuUmV0cmlldmVNZXRhZGF0YSA9IGZ1bmN0aW9uKHN0dWR5SW5zdGFuY2VVaWQpIHtcbiAgICAvLyBUT0RPOiBDaGVjayB3aGljaCBwZWVyIGl0IHNob3VsZCBwb2ludCB0b1xuICAgIGNvbnN0IGFjdGl2ZVNlcnZlciA9IE9ISUYuc2VydmVycy5nZXRDdXJyZW50U2VydmVyKCkucGVlcnNbMF07XG4gICAgY29uc3Qgc3VwcG9ydHNJbnN0YW5jZVJldHJpZXZhbEJ5U3R1ZHlVaWQgPSBhY3RpdmVTZXJ2ZXIuc3VwcG9ydHNJbnN0YW5jZVJldHJpZXZhbEJ5U3R1ZHlVaWQ7XG4gICAgbGV0IHJlc3VsdHM7XG5cbiAgICAvLyBDaGVjayBleHBsaWNpdGx5IGZvciBhIHZhbHVlIG9mIGZhbHNlLCBzaW5jZSB0aGlzIHByb3BlcnR5XG4gICAgLy8gbWF5IGJlIGxlZnQgdW5kZWZpbmVkIGluIGNvbmZpZyBmaWxlc1xuICAgIGlmIChzdXBwb3J0c0luc3RhbmNlUmV0cmlldmFsQnlTdHVkeVVpZCA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmVzdWx0cyA9IERJTVNFLnJldHJpZXZlSW5zdGFuY2VzQnlTdHVkeU9ubHkoc3R1ZHlJbnN0YW5jZVVpZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcmVzdWx0cyA9IERJTVNFLnJldHJpZXZlSW5zdGFuY2VzKHN0dWR5SW5zdGFuY2VVaWQpO1xuICAgIH1cblxuICAgIHJldHVybiByZXN1bHREYXRhVG9TdHVkeU1ldGFkYXRhKHN0dWR5SW5zdGFuY2VVaWQsIHJlc3VsdHMpO1xufTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgT0hJRiB9IGZyb20gJ21ldGVvci9vaGlmOmNvcmUnO1xuaW1wb3J0IHsgQ3VycmVudFNlcnZlciB9IGZyb20gJ21ldGVvci9vaGlmOnNlcnZlcnMvYm90aC9jb2xsZWN0aW9ucyc7XG5cbmNvbnN0IHNldHVwRElNU0UgPSAoKSA9PiB7XG4gICAgLy8gVGVybWluYXRlIGV4aXN0aW5nIERJTVNFIHNlcnZlcnMgYW5kIHNvY2tldHMgYW5kIGNsZWFuIHVwIHRoZSBjb25uZWN0aW9uIG9iamVjdFxuICAgIERJTVNFLmNvbm5lY3Rpb24ucmVzZXQoKTtcblxuICAgIC8vIEdldCB0aGUgbmV3IHNlcnZlciBjb25maWd1cmF0aW9uXG4gICAgY29uc3Qgc2VydmVyID0gT0hJRi5zZXJ2ZXJzLmdldEN1cnJlbnRTZXJ2ZXIoKTtcblxuICAgIC8vIFN0b3AgaGVyZSBpZiB0aGUgbmV3IHNlcnZlciBpcyBub3Qgb2YgRElNU0UgdHlwZVxuICAgIGlmIChzZXJ2ZXIudHlwZSAhPT0gJ2RpbXNlJykge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaWYgcGVlcnMgd2VyZSBkZWZpbmVkIGluIHRoZSBzZXJ2ZXIgY29uZmlndXJhdGlvbiBhbmQgdGhyb3cgYW4gZXJyb3IgaWYgbm90XG4gICAgY29uc3QgcGVlcnMgPSBzZXJ2ZXIucGVlcnM7XG4gICAgaWYgKCFwZWVycyB8fCAhcGVlcnMubGVuZ3RoKSB7XG4gICAgICAgIE9ISUYubG9nLmVycm9yKCdkaW1zZS1jb25maWc6ICcgKyAnTm8gRElNU0UgUGVlcnMgcHJvdmlkZWQuJyk7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2RpbXNlLWNvbmZpZycsICdObyBESU1TRSBQZWVycyBwcm92aWRlZC4nKTtcbiAgICB9XG5cbiAgICAvLyBBZGQgYWxsIHRoZSBESU1TRSBwZWVycywgZXN0YWJsaXNoaW5nIHRoZSBjb25uZWN0aW9uc1xuICAgIE9ISUYubG9nLmluZm8oJ0FkZGluZyBESU1TRSBwZWVycycpO1xuICAgIHRyeSB7XG4gICAgICAgIHBlZXJzLmZvckVhY2gocGVlciA9PiBESU1TRS5jb25uZWN0aW9uLmFkZFBlZXIocGVlcikpO1xuICAgIH0gY2F0Y2goZXJyb3IpIHtcbiAgICAgICAgT0hJRi5sb2cuZXJyb3IoJ2RpbXNlLWFkZFBlZXJzOiAnICsgZXJyb3IpO1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdkaW1zZS1hZGRQZWVycycsIGVycm9yKTtcbiAgICB9XG59O1xuXG4vLyBTZXR1cCB0aGUgRElNU0UgY29ubmVjdGlvbnMgb24gc3RhcnR1cCBvciB3aGVuIHRoZSBjdXJyZW50IHNlcnZlciBpcyBjaGFuZ2VkXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gICAgQ3VycmVudFNlcnZlci5maW5kKCkub2JzZXJ2ZSh7XG4gICAgICAgIGFkZGVkOiBzZXR1cERJTVNFLFxuICAgICAgICBjaGFuZ2VkOiBzZXR1cERJTVNFXG4gICAgfSk7XG59KTtcbiIsImltcG9ydCB7IG1vbWVudCB9IGZyb20gJ21ldGVvci9tb21lbnRqczptb21lbnQnO1xuaW1wb3J0IHsgT0hJRiB9IGZyb20gJ21ldGVvci9vaGlmOmNvcmUnO1xuXG4vKipcbiAqIFBhcnNlcyByZXN1bHRpbmcgZGF0YSBmcm9tIGEgUUlETyBjYWxsIGludG8gYSBzZXQgb2YgU3R1ZHkgTWV0YURhdGFcbiAqXG4gKiBAcGFyYW0gcmVzdWx0RGF0YVxuICogQHJldHVybnMge0FycmF5fSBBbiBhcnJheSBvZiBTdHVkeSBNZXRhRGF0YSBvYmplY3RzXG4gKi9cbmZ1bmN0aW9uIHJlc3VsdERhdGFUb1N0dWRpZXMocmVzdWx0RGF0YSkge1xuICAgIGNvbnN0IHN0dWRpZXMgPSBbXTtcblxuICAgIHJlc3VsdERhdGEuZm9yRWFjaChmdW5jdGlvbihzdHVkeVJhdykge1xuICAgICAgICBjb25zdCBzdHVkeSA9IHN0dWR5UmF3LnRvT2JqZWN0KCk7XG4gICAgICAgIHN0dWRpZXMucHVzaCh7XG4gICAgICAgICAgICBzdHVkeUluc3RhbmNlVWlkOiBzdHVkeVsweDAwMjAwMDBEXSxcbiAgICAgICAgICAgIC8vIDAwMDgwMDA1ID0gU3BlY2lmaWNDaGFyYWN0ZXJTZXRcbiAgICAgICAgICAgIHN0dWR5RGF0ZTogc3R1ZHlbMHgwMDA4MDAyMF0sXG4gICAgICAgICAgICBzdHVkeVRpbWU6IHN0dWR5WzB4MDAwODAwMzBdLFxuICAgICAgICAgICAgYWNjZXNzaW9uTnVtYmVyOiBzdHVkeVsweDAwMDgwMDUwXSxcbiAgICAgICAgICAgIHJlZmVycmluZ1BoeXNpY2lhbk5hbWU6IHN0dWR5WzB4MDAwODAwOTBdLFxuICAgICAgICAgICAgLy8gMDAwODExOTAgPSBVUkxcbiAgICAgICAgICAgIHBhdGllbnROYW1lOiBzdHVkeVsweDAwMTAwMDEwXSxcbiAgICAgICAgICAgIHBhdGllbnRJZDogc3R1ZHlbMHgwMDEwMDAyMF0sXG4gICAgICAgICAgICBwYXRpZW50QmlydGhkYXRlOiBzdHVkeVsweDAwMTAwMDMwXSxcbiAgICAgICAgICAgIHBhdGllbnRTZXg6IHN0dWR5WzB4MDAxMDAwNDBdLFxuICAgICAgICAgICAgaW1hZ2VDb3VudDogc3R1ZHlbMHgwMDIwMTIwOF0sXG4gICAgICAgICAgICBzdHVkeUlkOiBzdHVkeVsweDAwMjAwMDEwXSxcbiAgICAgICAgICAgIHN0dWR5RGVzY3JpcHRpb246IHN0dWR5WzB4MDAwODEwMzBdLFxuICAgICAgICAgICAgbW9kYWxpdGllczogc3R1ZHlbMHgwMDA4MDA2MV1cbiAgICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHN0dWRpZXM7XG59XG5cbk9ISUYuc3R1ZGllcy5zZXJ2aWNlcy5ESU1TRS5TdHVkaWVzID0gZnVuY3Rpb24oZmlsdGVyKSB7XG4gICAgT0hJRi5sb2cuaW5mbygnU2VydmljZXMuRElNU0UuU3R1ZGllcycpO1xuXG4gICAgbGV0IGZpbHRlclN0dWR5RGF0ZSA9ICcnO1xuICAgIGlmIChmaWx0ZXIuc3R1ZHlEYXRlRnJvbSAmJiBmaWx0ZXIuc3R1ZHlEYXRlVG8pIHtcbiAgICAgICAgY29uc3QgY29udmVydERhdGUgPSBkYXRlID0+IG1vbWVudChkYXRlLCAnTU0vREQvWVlZWScpLmZvcm1hdCgnWVlZWU1NREQnKTtcbiAgICAgICAgY29uc3QgZGF0ZUZyb20gPSBjb252ZXJ0RGF0ZShmaWx0ZXIuc3R1ZHlEYXRlRnJvbSk7XG4gICAgICAgIGNvbnN0IGRhdGVUbyA9IGNvbnZlcnREYXRlKGZpbHRlci5zdHVkeURhdGVUbyk7XG4gICAgICAgIGZpbHRlclN0dWR5RGF0ZSA9IGAke2RhdGVGcm9tfS0ke2RhdGVUb31gO1xuICAgIH1cblxuICAgIC8vIEJ1aWxkIHRoZSBTdHVkeUluc3RhbmNlVUlEIHBhcmFtZXRlclxuICAgIGxldCBzdHVkeVVpZHMgPSBmaWx0ZXIuc3R1ZHlJbnN0YW5jZVVpZCB8fCAnJztcbiAgICBpZiAoc3R1ZHlVaWRzKSB7XG4gICAgICAgIHN0dWR5VWlkcyA9IEFycmF5LmlzQXJyYXkoc3R1ZHlVaWRzKSA/IHN0dWR5VWlkcy5qb2luKCkgOiBzdHVkeVVpZHM7XG4gICAgICAgIHN0dWR5VWlkcyA9IHN0dWR5VWlkcy5yZXBsYWNlKC9bXjAtOS5dKy9nLCAnXFxcXCcpO1xuICAgIH1cblxuICAgIGNvbnN0IHBhcmFtZXRlcnMgPSB7XG4gICAgICAgIDB4MDAyMDAwMEQ6IHN0dWR5VWlkcyxcbiAgICAgICAgMHgwMDEwMDAxMDogZmlsdGVyLnBhdGllbnROYW1lLFxuICAgICAgICAweDAwMTAwMDIwOiBmaWx0ZXIucGF0aWVudElkLFxuICAgICAgICAweDAwMDgwMDUwOiBmaWx0ZXIuYWNjZXNzaW9uTnVtYmVyLFxuICAgICAgICAweDAwMDgwMDIwOiBmaWx0ZXJTdHVkeURhdGUsXG4gICAgICAgIDB4MDAwODEwMzA6IGZpbHRlci5zdHVkeURlc2NyaXB0aW9uLFxuICAgICAgICAweDAwMTAwMDQwOiAnJyxcbiAgICAgICAgMHgwMDIwMTIwODogJycsXG4gICAgICAgIDB4MDAwODAwNjE6IGZpbHRlci5tb2RhbGl0aWVzSW5TdHVkeVxuICAgIH07XG5cbiAgICBjb25zdCByZXN1bHRzID0gRElNU0UucmV0cmlldmVTdHVkaWVzKHBhcmFtZXRlcnMpO1xuICAgIHJldHVybiByZXN1bHREYXRhVG9TdHVkaWVzKHJlc3VsdHMpO1xufTtcbiIsImltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcblxuLyoqXG4gKiBDcmVhdGVzIGEgUUlETyBVUkwgZ2l2ZW4gdGhlIHNlcnZlciBzZXR0aW5ncyBhbmQgYSBzdHVkeSBpbnN0YW5jZSBVSURcbiAqIEBwYXJhbSBzZXJ2ZXJcbiAqIEBwYXJhbSBzdHVkeUluc3RhbmNlVWlkXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBVUkwgdG8gYmUgdXNlZCBmb3IgUUlETyBjYWxsc1xuICovXG5mdW5jdGlvbiBidWlsZFVybChzZXJ2ZXIsIHN0dWR5SW5zdGFuY2VVaWQpIHtcbiAgICByZXR1cm4gc2VydmVyLnFpZG9Sb290ICsgJy9zdHVkaWVzLycgKyBzdHVkeUluc3RhbmNlVWlkICsgJy9pbnN0YW5jZXMnO1xufVxuXG4vKipcbiAqIFBhcnNlcyBkYXRhIHJldHVybmVkIGZyb20gYSBRSURPIHNlYXJjaCBhbmQgdHJhbnNmb3JtcyBpdCBpbnRvXG4gKiBhbiBhcnJheSBvZiBzZXJpZXMgdGhhdCBhcmUgcHJlc2VudCBpbiB0aGUgc3R1ZHlcbiAqXG4gKiBAcGFyYW0gc2VydmVyIFRoZSBESUNPTSBzZXJ2ZXJcbiAqIEBwYXJhbSBzdHVkeUluc3RhbmNlVWlkXG4gKiBAcGFyYW0gcmVzdWx0RGF0YVxuICogQHJldHVybnMge0FycmF5fSBTZXJpZXMgTGlzdFxuICovXG5mdW5jdGlvbiByZXN1bHREYXRhVG9TdHVkeU1ldGFkYXRhKHNlcnZlciwgc3R1ZHlJbnN0YW5jZVVpZCwgcmVzdWx0RGF0YSkge1xuICAgIHZhciBzZXJpZXNNYXAgPSB7fTtcbiAgICB2YXIgc2VyaWVzTGlzdCA9IFtdO1xuXG4gICAgcmVzdWx0RGF0YS5mb3JFYWNoKGZ1bmN0aW9uKGluc3RhbmNlKSB7XG4gICAgICAgIC8vIFVzZSBzZXJpZXNNYXAgdG8gY2FjaGUgc2VyaWVzIGRhdGFcbiAgICAgICAgLy8gSWYgdGhlIHNlcmllcyBpbnN0YW5jZSBVSUQgaGFzIGFscmVhZHkgYmVlbiB1c2VkIHRvXG4gICAgICAgIC8vIHByb2Nlc3Mgc2VyaWVzIGRhdGEsIGNvbnRpbnVlIHVzaW5nIHRoYXQgc2VyaWVzXG4gICAgICAgIHZhciBzZXJpZXNJbnN0YW5jZVVpZCA9IERJQ09NV2ViLmdldFN0cmluZyhpbnN0YW5jZVsnMDAyMDAwMEUnXSk7XG4gICAgICAgIHZhciBzZXJpZXMgPSBzZXJpZXNNYXBbc2VyaWVzSW5zdGFuY2VVaWRdO1xuXG4gICAgICAgIC8vIElmIG5vIHNlcmllcyBkYXRhIGV4aXN0cyBpbiB0aGUgc2VyaWVzTWFwIGNhY2hlIHZhcmlhYmxlLFxuICAgICAgICAvLyBwcm9jZXNzIGFueSBhdmFpbGFibGUgc2VyaWVzIGRhdGFcbiAgICAgICAgaWYgKCFzZXJpZXMpIHtcbiAgICAgICAgICAgIHNlcmllcyA9IHtcbiAgICAgICAgICAgICAgICBzZXJpZXNJbnN0YW5jZVVpZDogc2VyaWVzSW5zdGFuY2VVaWQsXG4gICAgICAgICAgICAgICAgc2VyaWVzTnVtYmVyOiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjAwMDExJ10pLFxuICAgICAgICAgICAgICAgIGluc3RhbmNlczogW11cbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8vIFNhdmUgdGhpcyBkYXRhIGluIHRoZSBzZXJpZXNNYXAgY2FjaGUgdmFyaWFibGVcbiAgICAgICAgICAgIHNlcmllc01hcFtzZXJpZXNJbnN0YW5jZVVpZF0gPSBzZXJpZXM7XG4gICAgICAgICAgICBzZXJpZXNMaXN0LnB1c2goc2VyaWVzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRoZSB1cmkgZm9yIHRoZSBkaWNvbXdlYlxuICAgICAgICAvLyBOT1RFOiBEQ000Q0hFRSBzZWVtcyB0byByZXR1cm4gdGhlIGRhdGEgemlwcGVkXG4gICAgICAgIC8vIE5PVEU6IE9ydGhhbmMgcmV0dXJucyB0aGUgZGF0YSB3aXRoIG11bHRpLXBhcnQgbWltZSB3aGljaCBjb3JuZXJzdG9uZVdBRE9JbWFnZUxvYWRlciBkb2Vzbid0XG4gICAgICAgIC8vICAgICAgIGtub3cgaG93IHRvIHBhcnNlIHlldFxuICAgICAgICAvL3ZhciB1cmkgPSBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMDgxMTkwJ10pO1xuICAgICAgICAvL3VyaSA9IHVyaS5yZXBsYWNlKCd3YWRvLXJzJywgJ2RpY29tLXdlYicpO1xuXG4gICAgICAgIC8vIG1hbnVhbGx5IGNyZWF0ZSBhIFdBRE8tVVJJIGZyb20gdGhlIFVJRHNcbiAgICAgICAgLy8gTk9URTogSGF2ZW4ndCBiZWVuIGFibGUgdG8gZ2V0IE9ydGhhbmMncyBXQURPLVVSSSB0byB3b3JrIHlldCAtIG1heWJlIGl0cyBub3QgY29uZmlndXJlZD9cbiAgICAgICAgdmFyIHNvcEluc3RhbmNlVWlkID0gRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDA4MDAxOCddKTtcbiAgICAgICAgdmFyIHVyaSA9IHNlcnZlci53YWRvVXJpUm9vdCArICc/cmVxdWVzdFR5cGU9V0FETyZzdHVkeVVJRD0nICsgc3R1ZHlJbnN0YW5jZVVpZCArICcmc2VyaWVzVUlEPScgKyBzZXJpZXNJbnN0YW5jZVVpZCArICcmb2JqZWN0VUlEPScgKyBzb3BJbnN0YW5jZVVpZCArICcmY29udGVudFR5cGU9YXBwbGljYXRpb24lMkZkaWNvbSc7XG5cbiAgICAgICAgLy8gQWRkIHRoaXMgaW5zdGFuY2UgdG8gdGhlIGN1cnJlbnQgc2VyaWVzXG4gICAgICAgIHNlcmllcy5pbnN0YW5jZXMucHVzaCh7XG4gICAgICAgICAgICBzb3BDbGFzc1VpZDogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDA4MDAxNiddKSxcbiAgICAgICAgICAgIHNvcEluc3RhbmNlVWlkOiBzb3BJbnN0YW5jZVVpZCxcbiAgICAgICAgICAgIHVyaTogdXJpLFxuICAgICAgICAgICAgaW5zdGFuY2VOdW1iZXI6IERJQ09NV2ViLmdldFN0cmluZyhpbnN0YW5jZVsnMDAyMDAwMTMnXSlcbiAgICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHNlcmllc0xpc3Q7XG59XG5cbi8qKlxuICogUmV0cmlldmUgYSBzZXQgb2YgaW5zdGFuY2VzIHVzaW5nIGEgUUlETyBjYWxsXG4gKiBAcGFyYW0gc2VydmVyXG4gKiBAcGFyYW0gc3R1ZHlJbnN0YW5jZVVpZFxuICogQHRocm93cyBFQ09OTlJFRlVTRURcbiAqIEByZXR1cm5zIHt7d2Fkb1VyaVJvb3Q6IFN0cmluZywgc3R1ZHlJbnN0YW5jZVVpZDogU3RyaW5nLCBzZXJpZXNMaXN0OiBBcnJheX19XG4gKi9cbk9ISUYuc3R1ZGllcy5zZXJ2aWNlcy5RSURPLkluc3RhbmNlcyA9IGZ1bmN0aW9uKHNlcnZlciwgc3R1ZHlJbnN0YW5jZVVpZCkge1xuICAgIHZhciB1cmwgPSBidWlsZFVybChzZXJ2ZXIsIHN0dWR5SW5zdGFuY2VVaWQpO1xuXG4gICAgdHJ5IHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IERJQ09NV2ViLmdldEpTT04odXJsLCBzZXJ2ZXIucmVxdWVzdE9wdGlvbnMpO1xuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB3YWRvVXJpUm9vdDogc2VydmVyLndhZG9VcmlSb290LFxuICAgICAgICAgICAgc3R1ZHlJbnN0YW5jZVVpZDogc3R1ZHlJbnN0YW5jZVVpZCxcbiAgICAgICAgICAgIHNlcmllc0xpc3Q6IHJlc3VsdERhdGFUb1N0dWR5TWV0YWRhdGEoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkLCByZXN1bHQuZGF0YSlcbiAgICAgICAgfTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBPSElGLmxvZy50cmFjZSgpO1xuXG4gICAgICAgIHRocm93IGVycm9yO1xuICAgIH1cblxufTtcbiIsImltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcblxuLyoqXG4gKiBDcmVhdGVzIGEgUUlETyBkYXRlIHN0cmluZyBmb3IgYSBkYXRlIHJhbmdlIHF1ZXJ5XG4gKiBBc3N1bWVzIHRoZSB5ZWFyIGlzIHBvc2l0aXZlLCBhdCBtb3N0IDQgZGlnaXRzIGxvbmcuXG4gKlxuICogQHBhcmFtIGRhdGUgVGhlIERhdGUgb2JqZWN0IHRvIGJlIGZvcm1hdHRlZFxuICogQHJldHVybnMge3N0cmluZ30gVGhlIGZvcm1hdHRlZCBkYXRlIHN0cmluZ1xuICovXG5mdW5jdGlvbiBkYXRlVG9TdHJpbmcoZGF0ZSkge1xuICAgIGlmICghZGF0ZSkgcmV0dXJuICcnO1xuICAgIGxldCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpLnRvU3RyaW5nKCk7XG4gICAgbGV0IG1vbnRoID0gKGRhdGUuZ2V0TW9udGgoKSArIDEpLnRvU3RyaW5nKCk7XG4gICAgbGV0IGRheSA9IGRhdGUuZ2V0RGF0ZSgpLnRvU3RyaW5nKCk7XG4gICAgeWVhciA9ICcwJy5yZXBlYXQoNCAtIHllYXIubGVuZ3RoKS5jb25jYXQoeWVhcik7XG4gICAgbW9udGggPSAnMCcucmVwZWF0KDIgLSBtb250aC5sZW5ndGgpLmNvbmNhdChtb250aCk7XG4gICAgZGF5ID0gJzAnLnJlcGVhdCgyIC0gZGF5Lmxlbmd0aCkuY29uY2F0KGRheSk7XG4gICAgcmV0dXJuICcnLmNvbmNhdCh5ZWFyLCBtb250aCwgZGF5KTtcbn1cblxuLyoqXG4gKiBQcm9kdWNlcyBhIFFJRE8gVVJMIGdpdmVuIHNlcnZlciBkZXRhaWxzIGFuZCBhIHNldCBvZiBzcGVjaWZpZWQgc2VhcmNoIGZpbHRlclxuICogaXRlbXNcbiAqXG4gKiBAcGFyYW0gc2VydmVyXG4gKiBAcGFyYW0gZmlsdGVyXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBUaGUgVVJMIHdpdGggZW5jb2RlZCBmaWx0ZXIgcXVlcnkgZGF0YVxuICovXG5mdW5jdGlvbiBmaWx0ZXJUb1FJRE9VUkwoc2VydmVyLCBmaWx0ZXIpIHtcbiAgICBjb25zdCBjb21tYVNlcGFyYXRlZEZpZWxkcyA9IFtcbiAgICAgICAgJzAwMDgxMDMwJywgLy8gU3R1ZHkgRGVzY3JpcHRpb25cbiAgICAgICAgJzAwMDgwMDYwJyAvL01vZGFsaXR5XG4gICAgICAgIC8vIEFkZCBtb3JlIGZpZWxkcyBoZXJlIGlmIHlvdSB3YW50IHRoZW0gaW4gdGhlIHJlc3VsdFxuICAgIF0uam9pbignLCcpO1xuXG4gICAgY29uc3QgcGFyYW1ldGVycyA9IHtcbiAgICAgICAgUGF0aWVudE5hbWU6IGZpbHRlci5wYXRpZW50TmFtZSxcbiAgICAgICAgUGF0aWVudElEOiBmaWx0ZXIucGF0aWVudElkLFxuICAgICAgICBBY2Nlc3Npb25OdW1iZXI6IGZpbHRlci5hY2Nlc3Npb25OdW1iZXIsXG4gICAgICAgIFN0dWR5RGVzY3JpcHRpb246IGZpbHRlci5zdHVkeURlc2NyaXB0aW9uLFxuICAgICAgICBNb2RhbGl0aWVzSW5TdHVkeTogZmlsdGVyLm1vZGFsaXRpZXNJblN0dWR5LFxuICAgICAgICBsaW1pdDogZmlsdGVyLmxpbWl0LFxuICAgICAgICBpbmNsdWRlZmllbGQ6IHNlcnZlci5xaWRvU3VwcG9ydHNJbmNsdWRlRmllbGQgPyAnYWxsJyA6IGNvbW1hU2VwYXJhdGVkRmllbGRzXG4gICAgfTtcblxuICAgIC8vIGJ1aWxkIHRoZSBTdHVkeURhdGUgcmFuZ2UgcGFyYW1ldGVyXG4gICAgaWYgKGZpbHRlci5zdHVkeURhdGVGcm9tIHx8IGZpbHRlci5zdHVkeURhdGVUbykge1xuICAgICAgICBjb25zdCBkYXRlRnJvbSA9IGRhdGVUb1N0cmluZyhuZXcgRGF0ZShmaWx0ZXIuc3R1ZHlEYXRlRnJvbSkpO1xuICAgICAgICBjb25zdCBkYXRlVG8gPSBkYXRlVG9TdHJpbmcobmV3IERhdGUoZmlsdGVyLnN0dWR5RGF0ZVRvKSk7XG4gICAgICAgIHBhcmFtZXRlcnMuU3R1ZHlEYXRlID0gYCR7ZGF0ZUZyb219LSR7ZGF0ZVRvfWA7XG4gICAgfVxuXG4gICAgLy8gQnVpbGQgdGhlIFN0dWR5SW5zdGFuY2VVSUQgcGFyYW1ldGVyXG4gICAgaWYgKGZpbHRlci5zdHVkeUluc3RhbmNlVWlkKSB7XG4gICAgICAgIGxldCBzdHVkeVVpZHMgPSBmaWx0ZXIuc3R1ZHlJbnN0YW5jZVVpZDtcbiAgICAgICAgc3R1ZHlVaWRzID0gQXJyYXkuaXNBcnJheShzdHVkeVVpZHMpID8gc3R1ZHlVaWRzLmpvaW4oKSA6IHN0dWR5VWlkcztcbiAgICAgICAgc3R1ZHlVaWRzID0gc3R1ZHlVaWRzLnJlcGxhY2UoL1teMC05Ll0rL2csICdcXFxcJyk7XG4gICAgICAgIHBhcmFtZXRlcnMuU3R1ZHlJbnN0YW5jZVVJRCA9IHN0dWR5VWlkcztcbiAgICB9XG5cbiAgICByZXR1cm4gc2VydmVyLnFpZG9Sb290ICsgJy9zdHVkaWVzPycgKyBlbmNvZGVRdWVyeURhdGEocGFyYW1ldGVycyk7XG59XG5cbi8qKlxuICogUGFyc2VzIHJlc3VsdGluZyBkYXRhIGZyb20gYSBRSURPIGNhbGwgaW50byBhIHNldCBvZiBTdHVkeSBNZXRhRGF0YVxuICpcbiAqIEBwYXJhbSByZXN1bHREYXRhXG4gKiBAcmV0dXJucyB7QXJyYXl9IEFuIGFycmF5IG9mIFN0dWR5IE1ldGFEYXRhIG9iamVjdHNcbiAqL1xuZnVuY3Rpb24gcmVzdWx0RGF0YVRvU3R1ZGllcyhyZXN1bHREYXRhKSB7XG4gICAgY29uc3Qgc3R1ZGllcyA9IFtdO1xuXG4gICAgaWYgKCFyZXN1bHREYXRhIHx8ICFyZXN1bHREYXRhLmxlbmd0aCkgcmV0dXJuO1xuXG4gICAgcmVzdWx0RGF0YS5mb3JFYWNoKHN0dWR5ID0+IHN0dWRpZXMucHVzaCh7XG4gICAgICAgIHN0dWR5SW5zdGFuY2VVaWQ6IERJQ09NV2ViLmdldFN0cmluZyhzdHVkeVsnMDAyMDAwMEQnXSksXG4gICAgICAgIC8vIDAwMDgwMDA1ID0gU3BlY2lmaWNDaGFyYWN0ZXJTZXRcbiAgICAgICAgc3R1ZHlEYXRlOiBESUNPTVdlYi5nZXRTdHJpbmcoc3R1ZHlbJzAwMDgwMDIwJ10pLFxuICAgICAgICBzdHVkeVRpbWU6IERJQ09NV2ViLmdldFN0cmluZyhzdHVkeVsnMDAwODAwMzAnXSksXG4gICAgICAgIGFjY2Vzc2lvbk51bWJlcjogRElDT01XZWIuZ2V0U3RyaW5nKHN0dWR5WycwMDA4MDA1MCddKSxcbiAgICAgICAgcmVmZXJyaW5nUGh5c2ljaWFuTmFtZTogRElDT01XZWIuZ2V0U3RyaW5nKHN0dWR5WycwMDA4MDA5MCddKSxcbiAgICAgICAgLy8gMDAwODExOTAgPSBVUkxcbiAgICAgICAgcGF0aWVudE5hbWU6IERJQ09NV2ViLmdldE5hbWUoc3R1ZHlbJzAwMTAwMDEwJ10pLFxuICAgICAgICBwYXRpZW50SWQ6IERJQ09NV2ViLmdldFN0cmluZyhzdHVkeVsnMDAxMDAwMjAnXSksXG4gICAgICAgIHBhdGllbnRCaXJ0aGRhdGU6IERJQ09NV2ViLmdldFN0cmluZyhzdHVkeVsnMDAxMDAwMzAnXSksXG4gICAgICAgIHBhdGllbnRTZXg6IERJQ09NV2ViLmdldFN0cmluZyhzdHVkeVsnMDAxMDAwNDAnXSksXG4gICAgICAgIHN0dWR5SWQ6IERJQ09NV2ViLmdldFN0cmluZyhzdHVkeVsnMDAyMDAwMTAnXSksXG4gICAgICAgIG51bWJlck9mU3R1ZHlSZWxhdGVkU2VyaWVzOiBESUNPTVdlYi5nZXRTdHJpbmcoc3R1ZHlbJzAwMjAxMjA2J10pLFxuICAgICAgICBudW1iZXJPZlN0dWR5UmVsYXRlZEluc3RhbmNlczogRElDT01XZWIuZ2V0U3RyaW5nKHN0dWR5WycwMDIwMTIwOCddKSxcbiAgICAgICAgc3R1ZHlEZXNjcmlwdGlvbjogRElDT01XZWIuZ2V0U3RyaW5nKHN0dWR5WycwMDA4MTAzMCddKSxcbiAgICAgICAgLy8gbW9kYWxpdHk6IERJQ09NV2ViLmdldFN0cmluZyhzdHVkeVsnMDAwODAwNjAnXSksXG4gICAgICAgIC8vIG1vZGFsaXRpZXNJblN0dWR5OiBESUNPTVdlYi5nZXRTdHJpbmcoc3R1ZHlbJzAwMDgwMDYxJ10pLFxuICAgICAgICBtb2RhbGl0aWVzOiBESUNPTVdlYi5nZXRTdHJpbmcoRElDT01XZWIuZ2V0TW9kYWxpdGllcyhzdHVkeVsnMDAwODAwNjAnXSwgc3R1ZHlbJzAwMDgwMDYxJ10pKVxuICAgIH0pKTtcblxuICAgIHJldHVybiBzdHVkaWVzO1xufVxuXG5PSElGLnN0dWRpZXMuc2VydmljZXMuUUlETy5TdHVkaWVzID0gKHNlcnZlciwgZmlsdGVyKSA9PiB7XG4gICAgY29uc3QgdXJsID0gZmlsdGVyVG9RSURPVVJMKHNlcnZlciwgZmlsdGVyKTtcblxuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IERJQ09NV2ViLmdldEpTT04odXJsLCBzZXJ2ZXIucmVxdWVzdE9wdGlvbnMpO1xuXG4gICAgICAgIHJldHVybiByZXN1bHREYXRhVG9TdHVkaWVzKHJlc3VsdC5kYXRhKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBPSElGLmxvZy50cmFjZSgpO1xuXG4gICAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbn07XG4iLCJpbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG5pbXBvcnQgeyByZW1vdGVHZXRWYWx1ZSB9IGZyb20gJy4uLy4uL2xpYi9yZW1vdGVHZXRWYWx1ZSc7XG5cbi8qKlxuICogUGFyc2VzIGRhdGEgcmV0dXJuZWQgZnJvbSBhIFFJRE8gc2VhcmNoIGFuZCB0cmFuc2Zvcm1zIGl0IGludG9cbiAqIGFuIGFycmF5IG9mIHNlcmllcyB0aGF0IGFyZSBwcmVzZW50IGluIHRoZSBzdHVkeVxuICpcbiAqIEBwYXJhbSBzZXJ2ZXIgVGhlIERJQ09NIHNlcnZlclxuICogQHBhcmFtIHN0dWR5SW5zdGFuY2VVaWRcbiAqIEBwYXJhbSByZXN1bHREYXRhXG4gKiBAcmV0dXJucyB7QXJyYXl9IFNlcmllcyBMaXN0XG4gKi9cbmZ1bmN0aW9uIHJlc3VsdERhdGFUb1N0dWR5TWV0YWRhdGEoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkLCByZXN1bHREYXRhKSB7XG4gICAgdmFyIHNlcmllc01hcCA9IHt9O1xuICAgIHZhciBzZXJpZXNMaXN0ID0gW107XG5cbiAgICByZXN1bHREYXRhLmZvckVhY2goZnVuY3Rpb24oaW5zdGFuY2UpIHtcbiAgICAgICAgLy8gVXNlIHNlcmllc01hcCB0byBjYWNoZSBzZXJpZXMgZGF0YVxuICAgICAgICAvLyBJZiB0aGUgc2VyaWVzIGluc3RhbmNlIFVJRCBoYXMgYWxyZWFkeSBiZWVuIHVzZWQgdG9cbiAgICAgICAgLy8gcHJvY2VzcyBzZXJpZXMgZGF0YSwgY29udGludWUgdXNpbmcgdGhhdCBzZXJpZXNcbiAgICAgICAgdmFyIHNlcmllc0luc3RhbmNlVWlkID0gcmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjAsMDAwZSddKTtcbiAgICAgICAgdmFyIHNlcmllcyA9IHNlcmllc01hcFtzZXJpZXNJbnN0YW5jZVVpZF07XG5cbiAgICAgICAgLy8gSWYgbm8gc2VyaWVzIGRhdGEgZXhpc3RzIGluIHRoZSBzZXJpZXNNYXAgY2FjaGUgdmFyaWFibGUsXG4gICAgICAgIC8vIHByb2Nlc3MgYW55IGF2YWlsYWJsZSBzZXJpZXMgZGF0YVxuICAgICAgICBpZighc2VyaWVzKSB7XG4gICAgICAgICAgICBzZXJpZXMgPSB7XG4gICAgICAgICAgICAgICAgc2VyaWVzSW5zdGFuY2VVaWQgOiBzZXJpZXNJbnN0YW5jZVVpZCxcbiAgICAgICAgICAgICAgICBzZXJpZXNOdW1iZXIgOiBwYXJzZUZsb2F0KHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDIwLDAwMTEnXSkpLFxuICAgICAgICAgICAgICAgIGluc3RhbmNlczogW11cbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8vIFNhdmUgdGhpcyBkYXRhIGluIHRoZSBzZXJpZXNNYXAgY2FjaGUgdmFyaWFibGVcbiAgICAgICAgICAgIHNlcmllc01hcFtzZXJpZXNJbnN0YW5jZVVpZF0gPSBzZXJpZXM7XG4gICAgICAgICAgICBzZXJpZXNMaXN0LnB1c2goc2VyaWVzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRoZSB1cmkgZm9yIHRoZSBkaWNvbXdlYlxuICAgICAgICAvLyBOT1RFOiBEQ000Q0hFRSBzZWVtcyB0byByZXR1cm4gdGhlIGRhdGEgemlwcGVkXG4gICAgICAgIC8vIE5PVEU6IE9ydGhhbmMgcmV0dXJucyB0aGUgZGF0YSB3aXRoIG11bHRpLXBhcnQgbWltZSB3aGljaCBjb3JuZXJzdG9uZVdBRE9JbWFnZUxvYWRlciBkb2Vzbid0XG4gICAgICAgIC8vICAgICAgIGtub3cgaG93IHRvIHBhcnNlIHlldFxuICAgICAgICAvL3ZhciB1cmkgPSBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMDgxMTkwJ10pO1xuICAgICAgICAvL3VyaSA9IHVyaS5yZXBsYWNlKCd3YWRvLXJzJywgJ2RpY29tLXdlYicpO1xuXG4gICAgICAgIC8vIG1hbnVhbGx5IGNyZWF0ZSBhIFdBRE8tVVJJIGZyb20gdGhlIFVJRHNcbiAgICAgICAgLy8gTk9URTogSGF2ZW4ndCBiZWVuIGFibGUgdG8gZ2V0IE9ydGhhbmMncyBXQURPLVVSSSB0byB3b3JrIHlldCAtIG1heWJlIGl0cyBub3QgY29uZmlndXJlZD9cbiAgICAgICAgdmFyIHNvcEluc3RhbmNlVWlkID0gcmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMDgsMDAxOCddKTtcbiAgICAgICAgdmFyIHVyaSA9IHNlcnZlci53YWRvVXJpUm9vdCArICc/cmVxdWVzdFR5cGU9V0FETyZzdHVkeVVJRD0nICsgc3R1ZHlJbnN0YW5jZVVpZCArICcmc2VyaWVzVUlEPScgKyBzZXJpZXNJbnN0YW5jZVVpZCArICcmb2JqZWN0VUlEPScgKyBzb3BJbnN0YW5jZVVpZCArIFwiJmNvbnRlbnRUeXBlPWFwcGxpY2F0aW9uJTJGZGljb21cIjtcblxuICAgICAgICAvLyBBZGQgdGhpcyBpbnN0YW5jZSB0byB0aGUgY3VycmVudCBzZXJpZXNcbiAgICAgICAgc2VyaWVzLmluc3RhbmNlcy5wdXNoKHtcbiAgICAgICAgICAgIHNvcENsYXNzVWlkOiByZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAwOCwwMDE2J10pLFxuICAgICAgICAgICAgc29wSW5zdGFuY2VVaWQ6IHNvcEluc3RhbmNlVWlkLFxuICAgICAgICAgICAgdXJpOiB1cmksXG4gICAgICAgICAgICBpbnN0YW5jZU51bWJlcjogcGFyc2VGbG9hdChyZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyMCwwMDEzJ10pKVxuICAgICAgICB9KTtcbiAgfSk7XG4gIHJldHVybiBzZXJpZXNMaXN0O1xufVxuXG4vKipcbiAqIFJldHJpZXZlIGEgc2V0IG9mIGluc3RhbmNlcyB1c2luZyBhIFFJRE8gY2FsbFxuICogQHBhcmFtIHNlcnZlclxuICogQHBhcmFtIHN0dWR5SW5zdGFuY2VVaWRcbiAqIEByZXR1cm5zIHt7d2Fkb1VyaVJvb3Q6IFN0cmluZywgc3R1ZHlJbnN0YW5jZVVpZDogU3RyaW5nLCBzZXJpZXNMaXN0OiBBcnJheX19XG4gKi9cbk9ISUYuc3R1ZGllcy5zZXJ2aWNlcy5SRU1PVEUuSW5zdGFuY2VzID0gZnVuY3Rpb24oc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkKSB7XG4gICAgdmFyIHBhcmFtZXRlcnMgPSB7XG4gICAgICAgIFBhdGllbnROYW1lOiBcIlwiLFxuICAgICAgICBQYXRpZW50SUQ6IFwiXCIsXG4gICAgICAgIEFjY2Vzc2lvbk51bWJlcjogXCJcIixcbiAgICAgICAgU2VyaWVzSW5zdGFuY2VVSUQ6IFwiXCIsXG4gICAgICAgIFNlcmllc051bWJlciA6IFwiXCIsXG4gICAgICAgIFNPUENsYXNzVUlEIDogXCJcIixcbiAgICAgICAgSW5zdGFuY2VOdW1iZXIgOiBcIlwiXG4gICAgfTtcblxuICAgIHZhciByZW1vdGUgPSBuZXcgT3J0aGFuY1JlbW90ZShzZXJ2ZXIucm9vdCwgc2VydmVyLnNvdXJjZUFFKTtcblxuICAgIHJldHVybiB7XG4gICAgICAgIHdhZG9VcmlSb290OiBzZXJ2ZXIud2Fkb1VyaVJvb3QsXG4gICAgICAgIHN0dWR5SW5zdGFuY2VVaWQ6IHN0dWR5SW5zdGFuY2VVaWQsXG4gICAgICAgIHNlcmllc0xpc3Q6IHJlc3VsdERhdGFUb1N0dWR5TWV0YWRhdGEoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkLCByZW1vdGUuZmluZEluc3RhbmNlcyhzZXJ2ZXIubW9kYWxpdHksIHN0dWR5SW5zdGFuY2VVaWQsIG51bGwsIHBhcmFtZXRlcnMpKVxuICAgIH07XG59O1xuIiwiaW1wb3J0IHsgT0hJRiB9IGZyb20gJ21ldGVvci9vaGlmOmNvcmUnO1xuaW1wb3J0IHsgcmVtb3RlR2V0VmFsdWUgfSBmcm9tICcuLi8uLi9saWIvcmVtb3RlR2V0VmFsdWUnO1xuaW1wb3J0IHsgcGFyc2VGbG9hdEFycmF5IH0gZnJvbSAnLi4vLi4vbGliL3BhcnNlRmxvYXRBcnJheSc7XG5cbi8qKlxuICogUGFyc2VzIHRoZSBTb3VyY2VJbWFnZVNlcXVlbmNlLCBpZiBpdCBleGlzdHMsIGluIG9yZGVyXG4gKiB0byByZXR1cm4gYSBSZWZlcmVuY2VTT1BJbnN0YW5jZVVJRC4gVGhlIFJlZmVyZW5jZVNPUEluc3RhbmNlVUlEXG4gKiBpcyB1c2VkIHRvIHJlZmVyIHRvIHRoaXMgaW1hZ2UgaW4gYW55IGFjY29tcGFueWluZyBESUNPTS1TUiBkb2N1bWVudHMuXG4gKlxuICogQHBhcmFtIGluc3RhbmNlXG4gKiBAcmV0dXJucyB7U3RyaW5nfSBUaGUgUmVmZXJlbmNlU09QSW5zdGFuY2VVSURcbiAqL1xuZnVuY3Rpb24gZ2V0U291cmNlSW1hZ2VJbnN0YW5jZVVpZChpbnN0YW5jZSkge1xuICAgIC8vIFRPRE89IFBhcnNlIHRoZSB3aG9sZSBTb3VyY2UgSW1hZ2UgU2VxdWVuY2VcbiAgICAvLyBUaGlzIGlzIGEgcmVhbGx5IHBvb3Igd29ya2Fyb3VuZCBmb3Igbm93LlxuICAgIC8vIExhdGVyIHdlIHNob3VsZCBwcm9iYWJseSBwYXJzZSB0aGUgd2hvbGUgc2VxdWVuY2UuXG4gICAgdmFyIFNvdXJjZUltYWdlU2VxdWVuY2UgPSByZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAwOCwyMTEyJ10pO1xuICAgIGlmIChTb3VyY2VJbWFnZVNlcXVlbmNlICYmIFNvdXJjZUltYWdlU2VxdWVuY2UuVmFsdWUgJiYgU291cmNlSW1hZ2VTZXF1ZW5jZS5WYWx1ZS5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIFNvdXJjZUltYWdlU2VxdWVuY2UuVmFsdWVbMF1bJzAwMDgsMTE1NSddLlZhbHVlWzBdO1xuICAgIH1cbn1cblxuLyoqXG4gKiBQYXJzZXMgcmVzdWx0IGRhdGEgZnJvbSBhIFdBRE8gc2VhcmNoIGludG8gU3R1ZHkgTWV0YURhdGFcbiAqIFJldHVybnMgYW4gb2JqZWN0IHBvcHVsYXRlZCB3aXRoIHN0dWR5IG1ldGFkYXRhLCBpbmNsdWRpbmcgdGhlXG4gKiBzZXJpZXMgbGlzdC5cbiAqXG4gKiBAcGFyYW0gc2VydmVyXG4gKiBAcGFyYW0gc3R1ZHlJbnN0YW5jZVVpZFxuICogQHBhcmFtIHJlc3VsdERhdGFcbiAqIEByZXR1cm5zIHt7c2VyaWVzTGlzdDogQXJyYXksIHBhdGllbnROYW1lOiAqLCBwYXRpZW50SWQ6ICosIGFjY2Vzc2lvbk51bWJlcjogKiwgc3R1ZHlEYXRlOiAqLCBtb2RhbGl0aWVzOiAqLCBzdHVkeURlc2NyaXB0aW9uOiAqLCBpbWFnZUNvdW50OiAqLCBzdHVkeUluc3RhbmNlVWlkOiAqfX1cbiAqL1xuZnVuY3Rpb24gcmVzdWx0RGF0YVRvU3R1ZHlNZXRhZGF0YShzZXJ2ZXIsIHN0dWR5SW5zdGFuY2VVaWQsIHJlc3VsdERhdGEpIHtcbiAgICB2YXIgc2VyaWVzTWFwID0ge307XG4gICAgdmFyIHNlcmllc0xpc3QgPSBbXTtcblxuICAgIGlmICghcmVzdWx0RGF0YS5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciBhbkluc3RhbmNlID0gcmVzdWx0RGF0YVswXTtcbiAgICBpZiAoIWFuSW5zdGFuY2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciBzdHVkeURhdGEgPSB7XG4gICAgICAgIHNlcmllc0xpc3Q6IHNlcmllc0xpc3QsXG4gICAgICAgIHBhdGllbnROYW1lOiByZW1vdGVHZXRWYWx1ZShhbkluc3RhbmNlWycwMDEwLDAwMTAnXSksXG4gICAgICAgIHBhdGllbnRJZDogcmVtb3RlR2V0VmFsdWUoYW5JbnN0YW5jZVsnMDAxMCwwMDIwJ10pLFxuICAgICAgICBhY2Nlc3Npb25OdW1iZXI6IHJlbW90ZUdldFZhbHVlKGFuSW5zdGFuY2VbJzAwMDgsMDA1MCddKSxcbiAgICAgICAgc3R1ZHlEYXRlOiByZW1vdGVHZXRWYWx1ZShhbkluc3RhbmNlWycwMDA4LDAwMjAnXSksXG4gICAgICAgIG1vZGFsaXRpZXM6IHJlbW90ZUdldFZhbHVlKGFuSW5zdGFuY2VbJzAwMDgsMDA2MSddKSxcbiAgICAgICAgc3R1ZHlEZXNjcmlwdGlvbjogcmVtb3RlR2V0VmFsdWUoYW5JbnN0YW5jZVsnMDAwOCwxMDMwJ10pLFxuICAgICAgICBpbWFnZUNvdW50OiByZW1vdGVHZXRWYWx1ZShhbkluc3RhbmNlWycwMDIwLDEyMDgnXSksXG4gICAgICAgIHN0dWR5SW5zdGFuY2VVaWQ6IHJlbW90ZUdldFZhbHVlKGFuSW5zdGFuY2VbJzAwMjAsMDAwZCddKVxuICAgIH07XG5cbiAgICByZXN1bHREYXRhLmZvckVhY2goZnVuY3Rpb24oaW5zdGFuY2UpIHtcbiAgICAgICAgdmFyIHNlcmllc0luc3RhbmNlVWlkID0gcmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjAsMDAwZSddKTtcbiAgICAgICAgdmFyIHNlcmllcyA9IHNlcmllc01hcFtzZXJpZXNJbnN0YW5jZVVpZF07XG4gICAgICAgIGlmICghc2VyaWVzKSB7XG4gICAgICAgICAgICBzZXJpZXMgPSB7XG4gICAgICAgICAgICAgICAgc2VyaWVzRGVzY3JpcHRpb246IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDA4LDEwM2UnXSksXG4gICAgICAgICAgICAgICAgbW9kYWxpdHk6IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDA4LDAwNjAnXSksXG4gICAgICAgICAgICAgICAgc2VyaWVzSW5zdGFuY2VVaWQ6IHNlcmllc0luc3RhbmNlVWlkLFxuICAgICAgICAgICAgICAgIHNlcmllc051bWJlcjogcGFyc2VGbG9hdChyZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyMCwwMDExJ10pKSxcbiAgICAgICAgICAgICAgICBpbnN0YW5jZXM6IFtdXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgc2VyaWVzTWFwW3Nlcmllc0luc3RhbmNlVWlkXSA9IHNlcmllcztcbiAgICAgICAgICAgIHNlcmllc0xpc3QucHVzaChzZXJpZXMpO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHNvcEluc3RhbmNlVWlkID0gcmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMDgsMDAxOCddKTtcblxuICAgICAgICB2YXIgaW5zdGFuY2VTdW1tYXJ5ID0ge1xuICAgICAgICAgICAgaW1hZ2VUeXBlOiByZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAwOCwwMDA4J10pLFxuICAgICAgICAgICAgc29wQ2xhc3NVaWQ6IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDA4LDAwMTYnXSksXG4gICAgICAgICAgICBzb3BJbnN0YW5jZVVpZDogc29wSW5zdGFuY2VVaWQsXG4gICAgICAgICAgICBpbnN0YW5jZU51bWJlcjogcGFyc2VGbG9hdChyZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyMCwwMDEzJ10pKSxcbiAgICAgICAgICAgIGltYWdlUG9zaXRpb25QYXRpZW50OiByZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyMCwwMDMyJ10pLFxuICAgICAgICAgICAgaW1hZ2VPcmllbnRhdGlvblBhdGllbnQ6IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDIwLDAwMzcnXSksXG4gICAgICAgICAgICBmcmFtZU9mUmVmZXJlbmNlVUlEOiByZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyMCwwMDUyJ10pLFxuICAgICAgICAgICAgc2xpY2VMb2NhdGlvbjogcGFyc2VGbG9hdChyZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyMCwxMDQxJ10pKSxcbiAgICAgICAgICAgIHNhbXBsZXNQZXJQaXhlbDogcGFyc2VGbG9hdChyZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyOCwwMDAyJ10pKSxcbiAgICAgICAgICAgIHBob3RvbWV0cmljSW50ZXJwcmV0YXRpb246IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDI4LDAwMDQnXSksXG4gICAgICAgICAgICByb3dzOiBwYXJzZUZsb2F0KHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDI4LDAwMTAnXSkpLFxuICAgICAgICAgICAgY29sdW1uczogcGFyc2VGbG9hdChyZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyOCwwMDExJ10pKSxcbiAgICAgICAgICAgIHBpeGVsU3BhY2luZzogcmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjgsMDAzMCddKSxcbiAgICAgICAgICAgIGJpdHNBbGxvY2F0ZWQ6IHBhcnNlRmxvYXQocmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjgsMDEwMCddKSksXG4gICAgICAgICAgICBiaXRzU3RvcmVkOiBwYXJzZUZsb2F0KHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDI4LDAxMDEnXSkpLFxuICAgICAgICAgICAgaGlnaEJpdDogcGFyc2VGbG9hdChyZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAyOCwwMTAyJ10pKSxcbiAgICAgICAgICAgIHBpeGVsUmVwcmVzZW50YXRpb246IHBhcnNlRmxvYXQocmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjgsMDEwMyddKSksXG4gICAgICAgICAgICB3aW5kb3dDZW50ZXI6IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDI4LDEwNTAnXSksXG4gICAgICAgICAgICB3aW5kb3dXaWR0aDogcmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjgsMTA1MSddKSxcbiAgICAgICAgICAgIHJlc2NhbGVJbnRlcmNlcHQ6IHBhcnNlRmxvYXQocmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjgsMTA1MiddKSksXG4gICAgICAgICAgICByZXNjYWxlU2xvcGU6IHBhcnNlRmxvYXQocmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjgsMTA1MyddKSksXG4gICAgICAgICAgICBzb3VyY2VJbWFnZUluc3RhbmNlVWlkOiBnZXRTb3VyY2VJbWFnZUluc3RhbmNlVWlkKGluc3RhbmNlKSxcbiAgICAgICAgICAgIGxhdGVyYWxpdHk6IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDIwLDAwNjInXSksXG4gICAgICAgICAgICB2aWV3UG9zaXRpb246IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDE4LDUxMDEnXSksXG4gICAgICAgICAgICBhY3F1aXNpdGlvbkRhdGVUaW1lOiByZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAwOCwwMDJBJ10pLFxuICAgICAgICAgICAgbnVtYmVyT2ZGcmFtZXM6IHBhcnNlRmxvYXQocmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMjgsMDAwOCddKSksXG4gICAgICAgICAgICBmcmFtZUluY3JlbWVudFBvaW50ZXI6IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDI4LDAwMDknXSksXG4gICAgICAgICAgICBmcmFtZVRpbWU6IHBhcnNlRmxvYXQocmVtb3RlR2V0VmFsdWUoaW5zdGFuY2VbJzAwMTgsMTA2MyddKSksXG4gICAgICAgICAgICBmcmFtZVRpbWVWZWN0b3I6IHBhcnNlRmxvYXRBcnJheShyZW1vdGVHZXRWYWx1ZShpbnN0YW5jZVsnMDAxOCwxMDY1J10pKSxcbiAgICAgICAgICAgIGVjaG9OdW1iZXI6IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDE4LDAwODYnXSksXG4gICAgICAgICAgICBjb250cmFzdEJvbHVzQWdlbnQ6IHJlbW90ZUdldFZhbHVlKGluc3RhbmNlWycwMDE4LDAwMTAnXSlcbiAgICAgICAgfTtcblxuICAgICAgICB2YXIgaWlkID0gaW5zdGFuY2VbJ3h4eHgsMDAwMSddLlZhbHVlO1xuICAgICAgICBpZiAoc2VydmVyLmltYWdlUmVuZGVyaW5nID09PSAnd2Fkb3VyaScpIHtcbiAgICAgICAgICAgIGluc3RhbmNlU3VtbWFyeS53YWRvdXJpID0gc2VydmVyLndhZG9VcmlSb290ICsgJz9yZXF1ZXN0VHlwZT1XQURPJnN0dWR5VUlEPScgKyBzdHVkeUluc3RhbmNlVWlkICsgJyZzZXJpZXNVSUQ9JyArIHNlcmllc0luc3RhbmNlVWlkICsgJyZvYmplY3RVSUQ9JyArIHNvcEluc3RhbmNlVWlkICsgXCImY29udGVudFR5cGU9YXBwbGljYXRpb24lMkZkaWNvbVwiO1xuICAgICAgICB9IGVsc2UgaWYgKHNlcnZlci5pbWFnZVJlbmRlcmluZyA9PSAnb3J0aGFuYycpIHtcbiAgICAgICAgICAgIGluc3RhbmNlU3VtbWFyeS53YWRvdXJpID0gc2VydmVyLnJvb3QgKyAnL2luc3RhbmNlcy8nICsgaWlkICsgJy9maWxlJztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGluc3RhbmNlU3VtbWFyeS53YWRvcnN1cmkgPSBzZXJ2ZXIud2Fkb1Jvb3QgKyAnL3N0dWRpZXMvJyArIHN0dWR5SW5zdGFuY2VVaWQgKyAnL3Nlcmllcy8nICsgc2VyaWVzSW5zdGFuY2VVaWQgKyAnL2luc3RhbmNlcy8nICsgc29wSW5zdGFuY2VVaWQgKyAnL2ZyYW1lcy8xJztcbiAgICAgICAgfVxuXG4gICAgICAgIHNlcmllcy5pbnN0YW5jZXMucHVzaChpbnN0YW5jZVN1bW1hcnkpO1xuICAgIH0pO1xuY29uc29sZS5sb2coc3R1ZHlEYXRhLnNlcmllc0xpc3RbMF0uaW5zdGFuY2VzKTtcbiAgICByZXR1cm4gc3R1ZHlEYXRhO1xufVxuXG4vKipcbiAqIFJldHJpZXZlZCBTdHVkeSBNZXRhRGF0YSBmcm9tIGEgRElDT00gc2VydmVyIHVzaW5nIGEgV0FETyBjYWxsXG4gKiBAcGFyYW0gc2VydmVyXG4gKiBAcGFyYW0gc3R1ZHlJbnN0YW5jZVVpZFxuICogQHJldHVybnMge3tzZXJpZXNMaXN0OiBBcnJheSwgcGF0aWVudE5hbWU6ICosIHBhdGllbnRJZDogKiwgYWNjZXNzaW9uTnVtYmVyOiAqLCBzdHVkeURhdGU6ICosIG1vZGFsaXRpZXM6ICosIHN0dWR5RGVzY3JpcHRpb246ICosIGltYWdlQ291bnQ6ICosIHN0dWR5SW5zdGFuY2VVaWQ6ICp9fVxuICovXG5PSElGLnN0dWRpZXMuc2VydmljZXMuUkVNT1RFLlJldHJpZXZlTWV0YWRhdGEgPSBmdW5jdGlvbihzZXJ2ZXIsIHN0dWR5SW5zdGFuY2VVaWQpIHtcbiAgICB2YXIgcmVtb3RlID0gbmV3IE9ydGhhbmNSZW1vdGUoc2VydmVyLnJvb3QsIHNlcnZlci5zb3VyY2VBRSk7XG5cbiAgICB2YXIgc3R1ZHkgPSByZXN1bHREYXRhVG9TdHVkeU1ldGFkYXRhKHNlcnZlciwgc3R1ZHlJbnN0YW5jZVVpZCwgcmVtb3RlLnJldHJpZXZlTWV0YWRhdGEoc2VydmVyLm1vZGFsaXR5LCBzdHVkeUluc3RhbmNlVWlkKSk7XG4gICAgaWYgKCFzdHVkeSkge1xuICAgICAgIHN0dWR5ID0ge307XG4gICAgfVxuXG4gICAgc3R1ZHkud2Fkb1VyaVJvb3QgPSBzZXJ2ZXIud2Fkb1VyaVJvb3Q7XG4gICAgc3R1ZHkuc3R1ZHlJbnN0YW5jZVVpZCA9IHN0dWR5SW5zdGFuY2VVaWQ7XG5cbiAgICByZXR1cm4gc3R1ZHk7XG59O1xuIiwiaW1wb3J0IHsgT0hJRiB9IGZyb20gJ21ldGVvci9vaGlmOmNvcmUnO1xuaW1wb3J0IHsgcmVtb3RlR2V0VmFsdWUgfSBmcm9tICcuLi8uLi9saWIvcmVtb3RlR2V0VmFsdWUnO1xuXG5mdW5jdGlvbiByZXN1bHREYXRhVG9TdHVkaWVzKHJlc3VsdERhdGEpIHtcbiAgICBjb25zdCBzdHVkaWVzID0gW107XG5cbiAgICByZXN1bHREYXRhLmZvckVhY2goZnVuY3Rpb24oc3R1ZHkpIHtcbiAgICAgICAgc3R1ZGllcy5wdXNoKHtcbiAgICAgICAgICAgIHN0dWR5SW5zdGFuY2VVaWQ6IHJlbW90ZUdldFZhbHVlKHN0dWR5WycwMDIwLDAwMGQnXSksXG4gICAgICAgICAgICAvLyAwMDA4MDAwNSA9IFNwZWNpZmljQ2hhcmFjdGVyU2V0XG4gICAgICAgICAgICBzdHVkeURhdGU6IHJlbW90ZUdldFZhbHVlKHN0dWR5WycwMDA4LDAwMjAnXSksXG4gICAgICAgICAgICBzdHVkeVRpbWU6IHJlbW90ZUdldFZhbHVlKHN0dWR5WycwMDA4LDAwMzAnXSksXG4gICAgICAgICAgICBhY2Nlc3Npb25OdW1iZXI6IHJlbW90ZUdldFZhbHVlKHN0dWR5WycwMDA4LDAwNTAnXSksXG4gICAgICAgICAgICByZWZlcnJpbmdQaHlzaWNpYW5OYW1lOiByZW1vdGVHZXRWYWx1ZShzdHVkeVsnMDAwOCwwMDkwJ10pLFxuICAgICAgICAgICAgLy8gMDAwODExOTAgPSBVUkxcbiAgICAgICAgICAgIHBhdGllbnROYW1lOiByZW1vdGVHZXRWYWx1ZShzdHVkeVsnMDAxMCwwMDEwJ10pLFxuICAgICAgICAgICAgcGF0aWVudElkOiByZW1vdGVHZXRWYWx1ZShzdHVkeVsnMDAxMCwwMDIwJ10pLFxuICAgICAgICAgICAgcGF0aWVudEJpcnRoZGF0ZTogcmVtb3RlR2V0VmFsdWUoc3R1ZHlbJzAwMTAsMDAzMCddKSxcbiAgICAgICAgICAgIHBhdGllbnRTZXg6IHJlbW90ZUdldFZhbHVlKHN0dWR5WycwMDEwLDAwNDAnXSksXG4gICAgICAgICAgICBzdHVkeUlkOiByZW1vdGVHZXRWYWx1ZShzdHVkeVsnMDAyMCwwMDEwJ10pLFxuICAgICAgICAgICAgbnVtYmVyT2ZTdHVkeVJlbGF0ZWRTZXJpZXM6IHBhcnNlRmxvYXQocmVtb3RlR2V0VmFsdWUoc3R1ZHlbJzAwMjAsMTIwNiddKSksXG4gICAgICAgICAgICBudW1iZXJPZlN0dWR5UmVsYXRlZEluc3RhbmNlczogcGFyc2VGbG9hdChyZW1vdGVHZXRWYWx1ZShzdHVkeVsnMDAyMCwxMjA4J10pKSxcbiAgICAgICAgICAgIHN0dWR5RGVzY3JpcHRpb246IHJlbW90ZUdldFZhbHVlKHN0dWR5WycwMDA4LDEwMzAnXSksXG4gICAgICAgICAgICBtb2RhbGl0aWVzOiByZW1vdGVHZXRWYWx1ZShzdHVkeVsnMDAwOCwwMDYxJ10pXG4gICAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHN0dWRpZXM7XG59XG5cbk9ISUYuc3R1ZGllcy5zZXJ2aWNlcy5SRU1PVEUuU3R1ZGllcyA9IGZ1bmN0aW9uKHNlcnZlciwgZmlsdGVyKSB7XG4gICAgY29uc3QgcGFyYW1ldGVycyA9IHtcbiAgICAgICAgc3R1ZHlJbnN0YW5jZVVJRDogZmlsdGVyLnN0dWR5SW5zdGFuY2VVaWQgfHwgJycsXG4gICAgICAgIFBhdGllbnROYW1lOiBmaWx0ZXIucGF0aWVudE5hbWUgPyBmaWx0ZXIucGF0aWVudE5hbWUgOiAnJyxcbiAgICAgICAgUGF0aWVudElEOiBmaWx0ZXIucGF0aWVudElkLFxuICAgICAgICBBY2Nlc3Npb25OdW1iZXI6IGZpbHRlci5hY2Nlc3Npb25OdW1iZXIgPyBmaWx0ZXIuYWNjZXNzaW9uTnVtYmVyIDogJycsXG4gICAgICAgIFN0dWR5RGVzY3JpcHRpb246ICcnLFxuICAgICAgICBTdHVkeURhdGU6ICcnLFxuICAgICAgICBTdHVkeVRpbWU6ICcnLFxuICAgICAgICBSZWZlcnJpbmdQaHlzaWNpYW5OYW1lOiAnJyxcbiAgICAgICAgUGF0aWVudEJpcnRoRGF0ZTogJycsXG4gICAgICAgIFBhdGllbnRTZXg6ICcnLFxuICAgICAgICBTdHVkeUlEOiAnJyxcbiAgICAgICAgTnVtYmVyT2ZTdHVkeVJlbGF0ZWRTZXJpZXM6ICcnLFxuICAgICAgICBOdW1iZXJPZlN0dWR5UmVsYXRlZEluc3RhbmNlczogJycsXG4gICAgICAgIE1vZGFsaXRpZXNJblN0dWR5OiAnJ1xuICAgIH07XG5cbiAgICBjb25zdCByZW1vdGUgPSBuZXcgT3J0aGFuY1JlbW90ZShzZXJ2ZXIucm9vdCwgc2VydmVyLnNvdXJjZUFFKTtcbiAgICBjb25zdCBkYXRhID0gcmVtb3RlLmZpbmRTdHVkaWVzKHNlcnZlci5tb2RhbGl0eSwgcGFyYW1ldGVycyk7XG5cbiAgICByZXR1cm4gcmVzdWx0RGF0YVRvU3R1ZGllcyhkYXRhLnJlc3VsdHMpO1xufTtcbiIsImltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcbmltcG9ydCB7IHBhcnNlRmxvYXRBcnJheSB9IGZyb20gJy4uLy4uL2xpYi9wYXJzZUZsb2F0QXJyYXknO1xuXG4vKipcbiAqIFNpbXBsZSBjYWNoZSBzY2hlbWEgZm9yIHJldHJpZXZlZCBjb2xvciBwYWxldHRlcy5cbiAqL1xuY29uc3QgcGFsZXR0ZUNvbG9yQ2FjaGUgPSB7XG4gICAgY291bnQ6IDAsXG4gICAgbWF4QWdlOiAyNCAqIDYwICogNjAgKiAxMDAwLCAvLyAyNGggY2FjaGU/XG4gICAgZW50cmllczoge30sXG4gICAgaXNWYWxpZFVJRDogZnVuY3Rpb24gKHBhbGV0dGVVSUQpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiBwYWxldHRlVUlEID09PSAnc3RyaW5nJyAmJiBwYWxldHRlVUlELmxlbmd0aCA+IDA7XG4gICAgfSxcbiAgICBnZXQ6IGZ1bmN0aW9uIChwYWxldHRlVUlEKSB7XG4gICAgICAgIGxldCBlbnRyeSA9IG51bGw7XG4gICAgICAgIGlmICh0aGlzLmVudHJpZXMuaGFzT3duUHJvcGVydHkocGFsZXR0ZVVJRCkpIHtcbiAgICAgICAgICAgIGVudHJ5ID0gdGhpcy5lbnRyaWVzW3BhbGV0dGVVSURdO1xuICAgICAgICAgICAgLy8gY2hlY2sgaG93IHRoZSBlbnRyeSBpcy4uLlxuICAgICAgICAgICAgaWYgKChEYXRlLm5vdygpIC0gZW50cnkudGltZSkgPiB0aGlzLm1heEFnZSkge1xuICAgICAgICAgICAgICAgIC8vIGVudHJ5IGlzIHRvbyBvbGQuLi4gcmVtb3ZlIGVudHJ5LlxuICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLmVudHJpZXNbcGFsZXR0ZVVJRF07XG4gICAgICAgICAgICAgICAgdGhpcy5jb3VudC0tO1xuICAgICAgICAgICAgICAgIGVudHJ5ID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZW50cnk7XG4gICAgfSxcbiAgICBhZGQ6IGZ1bmN0aW9uIChlbnRyeSkge1xuICAgICAgICBpZiAodGhpcy5pc1ZhbGlkVUlEKGVudHJ5LnVpZCkpIHtcbiAgICAgICAgICAgIGxldCBwYWxldHRlVUlEID0gZW50cnkudWlkO1xuICAgICAgICAgICAgaWYgKHRoaXMuZW50cmllcy5oYXNPd25Qcm9wZXJ0eShwYWxldHRlVUlEKSAhPT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHRoaXMuY291bnQrKzsgLy8gaW5jcmVtZW50IGNhY2hlIGVudHJ5IGNvdW50Li4uXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbnRyeS50aW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgIHRoaXMuZW50cmllc1twYWxldHRlVUlEXSA9IGVudHJ5O1xuICAgICAgICAgICAgLy8gQFRPRE86IEFkZCBsb2dpYyB0byBnZXQgcmlkIG9mIG9sZCBlbnRyaWVzIGFuZCByZWR1Y2UgbWVtb3J5IHVzYWdlLi4uXG4gICAgICAgIH1cbiAgICB9XG59O1xuXG4vKipcbiAqIENyZWF0ZXMgYSBVUkwgZm9yIGEgV0FETyBzZWFyY2hcbiAqXG4gKiBAcGFyYW0gc2VydmVyXG4gKiBAcGFyYW0gc3R1ZHlJbnN0YW5jZVVpZFxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZnVuY3Rpb24gYnVpbGRVcmwoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkKSB7XG4gICAgcmV0dXJuIHNlcnZlci53YWRvUm9vdCArICcvc3R1ZGllcy8nICsgc3R1ZHlJbnN0YW5jZVVpZCArICcvbWV0YWRhdGEnO1xufVxuXG4vKiogUmV0dXJucyBhIFdBRE8gdXJsIGZvciBhbiBpbnN0YW5jZVxuICpcbiAqIEBwYXJhbSBzdHVkeUluc3RhbmNlVWlkXG4gKiBAcGFyYW0gc2VyaWVzSW5zdGFuY2VVaWRcbiAqIEBwYXJhbSBzb3BJbnN0YW5jZVVpZFxuICogQHJldHVybnMgIHtzdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGJ1aWxkSW5zdGFuY2VXYWRvVXJsKHNlcnZlciwgc3R1ZHlJbnN0YW5jZVVpZCwgc2VyaWVzSW5zdGFuY2VVaWQsIHNvcEluc3RhbmNlVWlkKSB7XG4gICAgY29uc3QgcGFyYW1zID0gW107XG5cbiAgICBwYXJhbXMucHVzaCgncmVxdWVzdFR5cGU9V0FETycpO1xuICAgIHBhcmFtcy5wdXNoKGBzdHVkeVVJRD0ke3N0dWR5SW5zdGFuY2VVaWR9YCk7XG4gICAgcGFyYW1zLnB1c2goYHNlcmllc1VJRD0ke3Nlcmllc0luc3RhbmNlVWlkfWApO1xuICAgIHBhcmFtcy5wdXNoKGBvYmplY3RVSUQ9JHtzb3BJbnN0YW5jZVVpZH1gKTtcbiAgICBwYXJhbXMucHVzaCgnY29udGVudFR5cGU9YXBwbGljYXRpb24lMkZkaWNvbScpO1xuICAgIHBhcmFtcy5wdXNoKCd0cmFuc2ZlclN5bnRheD0qJyk7XG5cbiAgICByZXR1cm4gYCR7c2VydmVyLndhZG9VcmlSb290fT8ke3BhcmFtcy5qb2luKCcmJyl9YDtcbn1cblxuZnVuY3Rpb24gYnVpbGRJbnN0YW5jZVdhZG9Sc1VyaShzZXJ2ZXIsIHN0dWR5SW5zdGFuY2VVaWQsIHNlcmllc0luc3RhbmNlVWlkLCBzb3BJbnN0YW5jZVVpZCkge1xuICAgIHJldHVybiBgJHtzZXJ2ZXIud2Fkb1Jvb3R9L3N0dWRpZXMvJHtzdHVkeUluc3RhbmNlVWlkfS9zZXJpZXMvJHtzZXJpZXNJbnN0YW5jZVVpZH0vaW5zdGFuY2VzLyR7c29wSW5zdGFuY2VVaWR9YFxufVxuXG5mdW5jdGlvbiBidWlsZEluc3RhbmNlRnJhbWVXYWRvUnNVcmkoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkLCBzZXJpZXNJbnN0YW5jZVVpZCwgc29wSW5zdGFuY2VVaWQsIGZyYW1lKSB7XG4gICAgY29uc3QgYmFzZVdhZG9Sc1VyaSA9IGJ1aWxkSW5zdGFuY2VXYWRvUnNVcmkoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkLCBzZXJpZXNJbnN0YW5jZVVpZCwgc29wSW5zdGFuY2VVaWQpO1xuICAgIGZyYW1lID0gZnJhbWUgIT0gbnVsbCB8fCAxO1xuXG4gICAgcmV0dXJuIGAke2Jhc2VXYWRvUnNVcml9L2ZyYW1lcy8ke2ZyYW1lfWBcbn1cblxuLyoqXG4gKiBQYXJzZXMgdGhlIFNvdXJjZUltYWdlU2VxdWVuY2UsIGlmIGl0IGV4aXN0cywgaW4gb3JkZXJcbiAqIHRvIHJldHVybiBhIFJlZmVyZW5jZVNPUEluc3RhbmNlVUlELiBUaGUgUmVmZXJlbmNlU09QSW5zdGFuY2VVSURcbiAqIGlzIHVzZWQgdG8gcmVmZXIgdG8gdGhpcyBpbWFnZSBpbiBhbnkgYWNjb21wYW55aW5nIERJQ09NLVNSIGRvY3VtZW50cy5cbiAqXG4gKiBAcGFyYW0gaW5zdGFuY2VcbiAqIEByZXR1cm5zIHtTdHJpbmd9IFRoZSBSZWZlcmVuY2VTT1BJbnN0YW5jZVVJRFxuICovXG5mdW5jdGlvbiBnZXRTb3VyY2VJbWFnZUluc3RhbmNlVWlkKGluc3RhbmNlKSB7XG4gICAgLy8gVE9ETz0gUGFyc2UgdGhlIHdob2xlIFNvdXJjZSBJbWFnZSBTZXF1ZW5jZVxuICAgIC8vIFRoaXMgaXMgYSByZWFsbHkgcG9vciB3b3JrYXJvdW5kIGZvciBub3cuXG4gICAgLy8gTGF0ZXIgd2Ugc2hvdWxkIHByb2JhYmx5IHBhcnNlIHRoZSB3aG9sZSBzZXF1ZW5jZS5cbiAgICB2YXIgU291cmNlSW1hZ2VTZXF1ZW5jZSA9IGluc3RhbmNlWycwMDA4MjExMiddO1xuICAgIGlmIChTb3VyY2VJbWFnZVNlcXVlbmNlICYmIFNvdXJjZUltYWdlU2VxdWVuY2UuVmFsdWUgJiYgU291cmNlSW1hZ2VTZXF1ZW5jZS5WYWx1ZS5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIFNvdXJjZUltYWdlU2VxdWVuY2UuVmFsdWVbMF1bJzAwMDgxMTU1J10uVmFsdWVbMF07XG4gICAgfVxufVxuXG5mdW5jdGlvbiBnZXRQYWxldHRlQ29sb3Ioc2VydmVyLCBpbnN0YW5jZSwgdGFnLCBsdXREZXNjcmlwdG9yKSB7XG4gICAgY29uc3QgbHV0ID0gW107XG4gICAgY29uc3QgbnVtTHV0RW50cmllcyA9IGx1dERlc2NyaXB0b3JbMF07XG4gICAgY29uc3QgYml0cyA9IGx1dERlc2NyaXB0b3JbMl07XG4gICAgY29uc3QgdXJpID0gV0FET1Byb3h5LmNvbnZlcnRVUkwoaW5zdGFuY2VbdGFnXS5CdWxrRGF0YVVSSSwgc2VydmVyKVxuICAgIGNvbnN0IGRhdGEgPSBESUNPTVdlYi5nZXRCdWxrRGF0YSh1cmkpO1xuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBudW1MdXRFbnRyaWVzOyBpKyspIHtcbiAgICAgICAgaWYoYml0cyA9PT0gMTYpIHtcbiAgICAgICAgICAgIGx1dFtpXSA9IGRhdGEucmVhZFVJbnQxNkxFKGkqMik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsdXRbaV0gPSBkYXRhLnJlYWRVSW50OChpKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBsdXQ7XG59XG5cbi8qKlxuICogRmV0Y2ggcGFsZXR0ZSBjb2xvcnMgZm9yIGluc3RhbmNlcyB3aXRoIFwiUEFMRVRURSBDT0xPUlwiIHBob3RvbWV0cmljSW50ZXJwcmV0YXRpb24uXG4gKlxuICogQHBhcmFtIHNlcnZlciB7T2JqZWN0fSBDdXJyZW50IHNlcnZlcjtcbiAqIEBwYXJhbSBpbnN0YW5jZSB7T2JqZWN0fSBUaGUgcmV0cmlldmVkIGluc3RhbmNlIG1ldGFkYXRhO1xuICogQHJldHVybnMge1N0cmluZ30gVGhlIFJlZmVyZW5jZVNPUEluc3RhbmNlVUlEXG4gKi9cbmZ1bmN0aW9uIGdldFBhbGV0dGVDb2xvcnMoc2VydmVyLCBpbnN0YW5jZSwgbHV0RGVzY3JpcHRvcikge1xuXG4gICAgbGV0IGVudHJ5ID0gbnVsbCxcbiAgICAgICAgcGFsZXR0ZVVJRCA9IERJQ09NV2ViLmdldFN0cmluZyhpbnN0YW5jZVsnMDAyODExOTknXSk7XG5cbiAgICBpZiAocGFsZXR0ZUNvbG9yQ2FjaGUuaXNWYWxpZFVJRChwYWxldHRlVUlEKSkge1xuICAgICAgICBlbnRyeSA9IHBhbGV0dGVDb2xvckNhY2hlLmdldChwYWxldHRlVUlEKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBwYWxldHRlVUlEID0gbnVsbDtcbiAgICB9XG5cbiAgICBpZiAoIWVudHJ5KSB7XG4gICAgICAgIC8vIG5vIGVudHJ5IG9uIGNhY2hlLi4uIEZldGNoIHJlbW90ZSBkYXRhLlxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbGV0IHIsIGcsIGI7XG4gICAgICAgICAgICByID0gZ2V0UGFsZXR0ZUNvbG9yKHNlcnZlciwgaW5zdGFuY2UsICcwMDI4MTIwMScsIGx1dERlc2NyaXB0b3IpO1xuICAgICAgICAgICAgZyA9IGdldFBhbGV0dGVDb2xvcihzZXJ2ZXIsIGluc3RhbmNlLCAnMDAyODEyMDInLCBsdXREZXNjcmlwdG9yKTs7XG4gICAgICAgICAgICBiID0gZ2V0UGFsZXR0ZUNvbG9yKHNlcnZlciwgaW5zdGFuY2UsICcwMDI4MTIwMycsIGx1dERlc2NyaXB0b3IpOztcblxuICAgICAgICAgICAgZW50cnkgPSB7IHJlZDogciwgZ3JlZW46IGcsIGJsdWU6IGIgfTtcbiAgICAgICAgICAgIGlmIChwYWxldHRlVUlEICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgLy8gd2hlbiBwYWxldHRlVUlEIGlzIHByZXNlbnQsIHRoZSBlbnRyeSBjYW4gYmUgY2FjaGVkLi4uXG4gICAgICAgICAgICAgICAgZW50cnkudWlkID0gcGFsZXR0ZVVJRDtcbiAgICAgICAgICAgICAgICBwYWxldHRlQ29sb3JDYWNoZS5hZGQoZW50cnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgT0hJRi5sb2cuZXJyb3IoYCgke2Vycm9yLm5hbWV9KSAke2Vycm9yLm1lc3NhZ2V9YCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZW50cnk7XG5cbn1cblxuZnVuY3Rpb24gZ2V0RnJhbWVJbmNyZW1lbnRQb2ludGVyKGVsZW1lbnQpIHtcbiAgICBjb25zdCBmcmFtZUluY3JlbWVudFBvaW50ZXJOYW1lcyA9IHtcbiAgICAgICAgJzAwMTgxMDY1JzogJ2ZyYW1lVGltZVZlY3RvcicsXG4gICAgICAgICcwMDE4MTA2Myc6ICdmcmFtZVRpbWUnXG4gICAgfTtcblxuICAgIGlmKCFlbGVtZW50IHx8ICFlbGVtZW50LlZhbHVlIHx8ICFlbGVtZW50LlZhbHVlLmxlbmd0aCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdmFsdWUgPSBlbGVtZW50LlZhbHVlWzBdO1xuICAgIHJldHVybiBmcmFtZUluY3JlbWVudFBvaW50ZXJOYW1lc1t2YWx1ZV07XG59XG5cbmZ1bmN0aW9uIGdldFJhZGlvcGhhcm1hY2V1dGljYWxJbmZvKGluc3RhbmNlKSB7XG4gICAgY29uc3QgbW9kYWxpdHkgPSBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMDgwMDYwJ10pO1xuXG4gICAgaWYgKG1vZGFsaXR5ICE9PSAnUFQnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCByYWRpb3BoYXJtYWNldXRpY2FsSW5mbyA9IGluc3RhbmNlWycwMDU0MDAxNiddO1xuICAgIGlmICgocmFkaW9waGFybWFjZXV0aWNhbEluZm8gPT09IHVuZGVmaW5lZCkgfHwgIXJhZGlvcGhhcm1hY2V1dGljYWxJbmZvLlZhbHVlIHx8ICFyYWRpb3BoYXJtYWNldXRpY2FsSW5mby5WYWx1ZS5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGZpcnN0UGV0UmFkaW9waGFybWFjZXV0aWNhbEluZm8gPSByYWRpb3BoYXJtYWNldXRpY2FsSW5mby5WYWx1ZVswXTtcbiAgICByZXR1cm4ge1xuICAgICAgICByYWRpb3BoYXJtYWNldXRpY2FsU3RhcnRUaW1lOiBESUNPTVdlYi5nZXRTdHJpbmcoZmlyc3RQZXRSYWRpb3BoYXJtYWNldXRpY2FsSW5mb1snMDAxODEwNzInXSksXG4gICAgICAgIHJhZGlvbnVjbGlkZVRvdGFsRG9zZTogRElDT01XZWIuZ2V0TnVtYmVyKGZpcnN0UGV0UmFkaW9waGFybWFjZXV0aWNhbEluZm9bJzAwMTgxMDc0J10pLFxuICAgICAgICByYWRpb251Y2xpZGVIYWxmTGlmZTogRElDT01XZWIuZ2V0TnVtYmVyKGZpcnN0UGV0UmFkaW9waGFybWFjZXV0aWNhbEluZm9bJzAwMTgxMDc1J10pXG4gICAgfTtcbn1cblxuLyoqXG4gKiBQYXJzZXMgcmVzdWx0IGRhdGEgZnJvbSBhIFdBRE8gc2VhcmNoIGludG8gU3R1ZHkgTWV0YURhdGFcbiAqIFJldHVybnMgYW4gb2JqZWN0IHBvcHVsYXRlZCB3aXRoIHN0dWR5IG1ldGFkYXRhLCBpbmNsdWRpbmcgdGhlXG4gKiBzZXJpZXMgbGlzdC5cbiAqXG4gKiBAcGFyYW0gc2VydmVyXG4gKiBAcGFyYW0gc3R1ZHlJbnN0YW5jZVVpZFxuICogQHBhcmFtIHJlc3VsdERhdGFcbiAqIEByZXR1cm5zIHt7c2VyaWVzTGlzdDogQXJyYXksIHBhdGllbnROYW1lOiAqLCBwYXRpZW50SWQ6ICosIGFjY2Vzc2lvbk51bWJlcjogKiwgc3R1ZHlEYXRlOiAqLCBtb2RhbGl0aWVzOiAqLCBzdHVkeURlc2NyaXB0aW9uOiAqLCBpbWFnZUNvdW50OiAqLCBzdHVkeUluc3RhbmNlVWlkOiAqfX1cbiAqL1xuZnVuY3Rpb24gcmVzdWx0RGF0YVRvU3R1ZHlNZXRhZGF0YShzZXJ2ZXIsIHN0dWR5SW5zdGFuY2VVaWQsIHJlc3VsdERhdGEpIHtcbiAgICB2YXIgc2VyaWVzTWFwID0ge307XG4gICAgdmFyIHNlcmllc0xpc3QgPSBbXTtcblxuICAgIGlmICghcmVzdWx0RGF0YS5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciBhbkluc3RhbmNlID0gcmVzdWx0RGF0YVswXTtcbiAgICBpZiAoIWFuSW5zdGFuY2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciBzdHVkeURhdGEgPSB7XG4gICAgICAgIHNlcmllc0xpc3Q6IHNlcmllc0xpc3QsXG4gICAgICAgIHBhdGllbnROYW1lOiBESUNPTVdlYi5nZXROYW1lKGFuSW5zdGFuY2VbJzAwMTAwMDEwJ10pLFxuICAgICAgICBwYXRpZW50SWQ6IERJQ09NV2ViLmdldFN0cmluZyhhbkluc3RhbmNlWycwMDEwMDAyMCddKSxcbiAgICAgICAgcGF0aWVudEFnZTogRElDT01XZWIuZ2V0TnVtYmVyKGFuSW5zdGFuY2VbJzAwMTAxMDEwJ10pLFxuICAgICAgICBwYXRpZW50U2l6ZTogRElDT01XZWIuZ2V0TnVtYmVyKGFuSW5zdGFuY2VbJzAwMTAxMDIwJ10pLFxuICAgICAgICBwYXRpZW50V2VpZ2h0OiBESUNPTVdlYi5nZXROdW1iZXIoYW5JbnN0YW5jZVsnMDAxMDEwMzAnXSksXG4gICAgICAgIGFjY2Vzc2lvbk51bWJlcjogRElDT01XZWIuZ2V0U3RyaW5nKGFuSW5zdGFuY2VbJzAwMDgwMDUwJ10pLFxuICAgICAgICBzdHVkeURhdGU6IERJQ09NV2ViLmdldFN0cmluZyhhbkluc3RhbmNlWycwMDA4MDAyMCddKSxcbiAgICAgICAgbW9kYWxpdGllczogRElDT01XZWIuZ2V0U3RyaW5nKGFuSW5zdGFuY2VbJzAwMDgwMDYxJ10pLFxuICAgICAgICBzdHVkeURlc2NyaXB0aW9uOiBESUNPTVdlYi5nZXRTdHJpbmcoYW5JbnN0YW5jZVsnMDAwODEwMzAnXSksXG4gICAgICAgIGltYWdlQ291bnQ6IERJQ09NV2ViLmdldFN0cmluZyhhbkluc3RhbmNlWycwMDIwMTIwOCddKSxcbiAgICAgICAgc3R1ZHlJbnN0YW5jZVVpZDogRElDT01XZWIuZ2V0U3RyaW5nKGFuSW5zdGFuY2VbJzAwMjAwMDBEJ10pLFxuICAgICAgICBpbnN0aXR1dGlvbk5hbWU6IERJQ09NV2ViLmdldFN0cmluZyhhbkluc3RhbmNlWycwMDA4MDA4MCddKVxuICAgIH07XG5cbiAgICByZXN1bHREYXRhLmZvckVhY2goZnVuY3Rpb24oaW5zdGFuY2UpIHtcbiAgICAgICAgdmFyIHNlcmllc0luc3RhbmNlVWlkID0gRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDIwMDAwRSddKTtcbiAgICAgICAgdmFyIHNlcmllcyA9IHNlcmllc01hcFtzZXJpZXNJbnN0YW5jZVVpZF07XG4gICAgICAgIGlmICghc2VyaWVzKSB7XG4gICAgICAgICAgICBzZXJpZXMgPSB7XG4gICAgICAgICAgICAgICAgc2VyaWVzRGVzY3JpcHRpb246IERJQ09NV2ViLmdldFN0cmluZyhpbnN0YW5jZVsnMDAwODEwM0UnXSksXG4gICAgICAgICAgICAgICAgbW9kYWxpdHk6IERJQ09NV2ViLmdldFN0cmluZyhpbnN0YW5jZVsnMDAwODAwNjAnXSksXG4gICAgICAgICAgICAgICAgc2VyaWVzSW5zdGFuY2VVaWQ6IHNlcmllc0luc3RhbmNlVWlkLFxuICAgICAgICAgICAgICAgIHNlcmllc051bWJlcjogRElDT01XZWIuZ2V0TnVtYmVyKGluc3RhbmNlWycwMDIwMDAxMSddKSxcbiAgICAgICAgICAgICAgICBzZXJpZXNEYXRlOiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMDgwMDIxJ10pLFxuICAgICAgICAgICAgICAgIHNlcmllc1RpbWU6IERJQ09NV2ViLmdldFN0cmluZyhpbnN0YW5jZVsnMDAwODAwMzEnXSksXG4gICAgICAgICAgICAgICAgaW5zdGFuY2VzOiBbXVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNlcmllc01hcFtzZXJpZXNJbnN0YW5jZVVpZF0gPSBzZXJpZXM7XG4gICAgICAgICAgICBzZXJpZXNMaXN0LnB1c2goc2VyaWVzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBzb3BJbnN0YW5jZVVpZCA9IERJQ09NV2ViLmdldFN0cmluZyhpbnN0YW5jZVsnMDAwODAwMTgnXSk7XG5cbiAgICAgICAgY29uc3Qgd2Fkb3VyaSA9IGJ1aWxkSW5zdGFuY2VXYWRvVXJsKHNlcnZlciwgc3R1ZHlJbnN0YW5jZVVpZCwgc2VyaWVzSW5zdGFuY2VVaWQsIHNvcEluc3RhbmNlVWlkKTtcbiAgICAgICAgY29uc3QgYmFzZVdhZG9Sc1VyaSA9IGJ1aWxkSW5zdGFuY2VXYWRvUnNVcmkoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkLCBzZXJpZXNJbnN0YW5jZVVpZCwgc29wSW5zdGFuY2VVaWQpO1xuICAgICAgICBjb25zdCB3YWRvcnN1cmkgPSBidWlsZEluc3RhbmNlRnJhbWVXYWRvUnNVcmkoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkLCBzZXJpZXNJbnN0YW5jZVVpZCwgc29wSW5zdGFuY2VVaWQpO1xuXG4gICAgICAgIHZhciBpbnN0YW5jZVN1bW1hcnkgPSB7XG4gICAgICAgICAgICBpbWFnZVR5cGU6IERJQ09NV2ViLmdldFN0cmluZyhpbnN0YW5jZVsnMDAwODAwMDgnXSksXG4gICAgICAgICAgICBzb3BDbGFzc1VpZDogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDA4MDAxNiddKSxcbiAgICAgICAgICAgIG1vZGFsaXR5OiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMDgwMDYwJ10pLFxuICAgICAgICAgICAgc29wSW5zdGFuY2VVaWQ6IHNvcEluc3RhbmNlVWlkLFxuICAgICAgICAgICAgaW5zdGFuY2VOdW1iZXI6IERJQ09NV2ViLmdldE51bWJlcihpbnN0YW5jZVsnMDAyMDAwMTMnXSksXG4gICAgICAgICAgICBpbWFnZVBvc2l0aW9uUGF0aWVudDogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDIwMDAzMiddKSxcbiAgICAgICAgICAgIGltYWdlT3JpZW50YXRpb25QYXRpZW50OiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjAwMDM3J10pLFxuICAgICAgICAgICAgZnJhbWVPZlJlZmVyZW5jZVVJRDogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDIwMDA1MiddKSxcbiAgICAgICAgICAgIHNsaWNlTG9jYXRpb246IERJQ09NV2ViLmdldE51bWJlcihpbnN0YW5jZVsnMDAyMDEwNDEnXSksXG4gICAgICAgICAgICBzYW1wbGVzUGVyUGl4ZWw6IERJQ09NV2ViLmdldE51bWJlcihpbnN0YW5jZVsnMDAyODAwMDInXSksXG4gICAgICAgICAgICBwaG90b21ldHJpY0ludGVycHJldGF0aW9uOiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjgwMDA0J10pLFxuICAgICAgICAgICAgcGxhbmFyQ29uZmlndXJhdGlvbjogRElDT01XZWIuZ2V0TnVtYmVyKGluc3RhbmNlWycwMDI4MDAwNiddKSxcbiAgICAgICAgICAgIHJvd3M6IERJQ09NV2ViLmdldE51bWJlcihpbnN0YW5jZVsnMDAyODAwMTAnXSksXG4gICAgICAgICAgICBjb2x1bW5zOiBESUNPTVdlYi5nZXROdW1iZXIoaW5zdGFuY2VbJzAwMjgwMDExJ10pLFxuICAgICAgICAgICAgcGl4ZWxTcGFjaW5nOiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjgwMDMwJ10pLFxuICAgICAgICAgICAgcGl4ZWxBc3BlY3RSYXRpbzogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDI4MDAzNCddKSxcbiAgICAgICAgICAgIGJpdHNBbGxvY2F0ZWQ6IERJQ09NV2ViLmdldE51bWJlcihpbnN0YW5jZVsnMDAyODAxMDAnXSksXG4gICAgICAgICAgICBiaXRzU3RvcmVkOiBESUNPTVdlYi5nZXROdW1iZXIoaW5zdGFuY2VbJzAwMjgwMTAxJ10pLFxuICAgICAgICAgICAgaGlnaEJpdDogRElDT01XZWIuZ2V0TnVtYmVyKGluc3RhbmNlWycwMDI4MDEwMiddKSxcbiAgICAgICAgICAgIHBpeGVsUmVwcmVzZW50YXRpb246IERJQ09NV2ViLmdldE51bWJlcihpbnN0YW5jZVsnMDAyODAxMDMnXSksXG4gICAgICAgICAgICBzbWFsbGVzdFBpeGVsVmFsdWU6IERJQ09NV2ViLmdldE51bWJlcihpbnN0YW5jZVsnMDAyODAxMDYnXSksXG4gICAgICAgICAgICBsYXJnZXN0UGl4ZWxWYWx1ZTogRElDT01XZWIuZ2V0TnVtYmVyKGluc3RhbmNlWycwMDI4MDEwNyddKSxcbiAgICAgICAgICAgIHdpbmRvd0NlbnRlcjogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDI4MTA1MCddKSxcbiAgICAgICAgICAgIHdpbmRvd1dpZHRoOiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjgxMDUxJ10pLFxuICAgICAgICAgICAgcmVzY2FsZUludGVyY2VwdDogRElDT01XZWIuZ2V0TnVtYmVyKGluc3RhbmNlWycwMDI4MTA1MiddKSxcbiAgICAgICAgICAgIHJlc2NhbGVTbG9wZTogRElDT01XZWIuZ2V0TnVtYmVyKGluc3RhbmNlWycwMDI4MTA1MyddKSxcbiAgICAgICAgICAgIHJlc2NhbGVUeXBlOiBESUNPTVdlYi5nZXROdW1iZXIoaW5zdGFuY2VbJzAwMjgxMDU0J10pLFxuICAgICAgICAgICAgc291cmNlSW1hZ2VJbnN0YW5jZVVpZDogZ2V0U291cmNlSW1hZ2VJbnN0YW5jZVVpZChpbnN0YW5jZSksXG4gICAgICAgICAgICBsYXRlcmFsaXR5OiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjAwMDYyJ10pLFxuICAgICAgICAgICAgdmlld1Bvc2l0aW9uOiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMTg1MTAxJ10pLFxuICAgICAgICAgICAgYWNxdWlzaXRpb25EYXRlVGltZTogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDA4MDAyQSddKSxcbiAgICAgICAgICAgIG51bWJlck9mRnJhbWVzOiBESUNPTVdlYi5nZXROdW1iZXIoaW5zdGFuY2VbJzAwMjgwMDA4J10pLFxuICAgICAgICAgICAgZnJhbWVJbmNyZW1lbnRQb2ludGVyOiBnZXRGcmFtZUluY3JlbWVudFBvaW50ZXIoaW5zdGFuY2VbJzAwMjgwMDA5J10pLFxuICAgICAgICAgICAgZnJhbWVUaW1lOiBESUNPTVdlYi5nZXROdW1iZXIoaW5zdGFuY2VbJzAwMTgxMDYzJ10pLFxuICAgICAgICAgICAgZnJhbWVUaW1lVmVjdG9yOiBwYXJzZUZsb2F0QXJyYXkoRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDE4MTA2NSddKSksXG4gICAgICAgICAgICBzbGljZVRoaWNrbmVzczogRElDT01XZWIuZ2V0TnVtYmVyKGluc3RhbmNlWycwMDE4MDA1MCddKSxcbiAgICAgICAgICAgIGxvc3N5SW1hZ2VDb21wcmVzc2lvbjogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDI4MjExMCddKSxcbiAgICAgICAgICAgIGRlcml2YXRpb25EZXNjcmlwdGlvbjogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDI4MjExMSddKSxcbiAgICAgICAgICAgIGxvc3N5SW1hZ2VDb21wcmVzc2lvblJhdGlvOiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjgyMTEyJ10pLFxuICAgICAgICAgICAgbG9zc3lJbWFnZUNvbXByZXNzaW9uTWV0aG9kOiBESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjgyMTE0J10pLFxuICAgICAgICAgICAgZWNob051bWJlcjogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDE4MDA4NiddKSxcbiAgICAgICAgICAgIGNvbnRyYXN0Qm9sdXNBZ2VudDogRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDE4MDAxMCddKSxcbiAgICAgICAgICAgIHJhZGlvcGhhcm1hY2V1dGljYWxJbmZvOiBnZXRSYWRpb3BoYXJtYWNldXRpY2FsSW5mbyhpbnN0YW5jZSksXG4gICAgICAgICAgICBiYXNlV2Fkb1JzVXJpOiBiYXNlV2Fkb1JzVXJpLFxuICAgICAgICAgICAgd2Fkb3VyaTogV0FET1Byb3h5LmNvbnZlcnRVUkwod2Fkb3VyaSwgc2VydmVyKSxcbiAgICAgICAgICAgIHdhZG9yc3VyaTogV0FET1Byb3h5LmNvbnZlcnRVUkwod2Fkb3JzdXJpLCBzZXJ2ZXIpLFxuICAgICAgICAgICAgaW1hZ2VSZW5kZXJpbmc6IHNlcnZlci5pbWFnZVJlbmRlcmluZyxcbiAgICAgICAgICAgIHRodW1ibmFpbFJlbmRlcmluZzogc2VydmVyLnRodW1ibmFpbFJlbmRlcmluZ1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIEdldCBhZGRpdGlvbmFsIGluZm9ybWF0aW9uIGlmIHRoZSBpbnN0YW5jZSB1c2VzIFwiUEFMRVRURSBDT0xPUlwiIHBob3RvbWV0cmljIGludGVycHJldGF0aW9uXG4gICAgICAgIGlmIChpbnN0YW5jZVN1bW1hcnkucGhvdG9tZXRyaWNJbnRlcnByZXRhdGlvbiA9PT0gJ1BBTEVUVEUgQ09MT1InKSB7XG4gICAgICAgICAgICBjb25zdCByZWRQYWxldHRlQ29sb3JMb29rdXBUYWJsZURlc2NyaXB0b3IgPSBwYXJzZUZsb2F0QXJyYXkoRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDI4MTEwMSddKSk7XG4gICAgICAgICAgICBjb25zdCBncmVlblBhbGV0dGVDb2xvckxvb2t1cFRhYmxlRGVzY3JpcHRvciA9IHBhcnNlRmxvYXRBcnJheShESUNPTVdlYi5nZXRTdHJpbmcoaW5zdGFuY2VbJzAwMjgxMTAyJ10pKTtcbiAgICAgICAgICAgIGNvbnN0IGJsdWVQYWxldHRlQ29sb3JMb29rdXBUYWJsZURlc2NyaXB0b3IgPSBwYXJzZUZsb2F0QXJyYXkoRElDT01XZWIuZ2V0U3RyaW5nKGluc3RhbmNlWycwMDI4MTEwMyddKSk7XG4gICAgICAgICAgICBjb25zdCBwYWxldHRlcyA9IGdldFBhbGV0dGVDb2xvcnMoc2VydmVyLCBpbnN0YW5jZSwgcmVkUGFsZXR0ZUNvbG9yTG9va3VwVGFibGVEZXNjcmlwdG9yKTtcblxuICAgICAgICAgICAgaWYgKHBhbGV0dGVzKSB7XG4gICAgICAgICAgICAgICAgaWYgKHBhbGV0dGVzLnVpZCkge1xuICAgICAgICAgICAgICAgICAgICBpbnN0YW5jZVN1bW1hcnkucGFsZXR0ZUNvbG9yTG9va3VwVGFibGVVSUQgPSBwYWxldHRlcy51aWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGluc3RhbmNlU3VtbWFyeS5yZWRQYWxldHRlQ29sb3JMb29rdXBUYWJsZURhdGEgPSBwYWxldHRlcy5yZWQ7XG4gICAgICAgICAgICAgICAgaW5zdGFuY2VTdW1tYXJ5LmdyZWVuUGFsZXR0ZUNvbG9yTG9va3VwVGFibGVEYXRhID0gcGFsZXR0ZXMuZ3JlZW47XG4gICAgICAgICAgICAgICAgaW5zdGFuY2VTdW1tYXJ5LmJsdWVQYWxldHRlQ29sb3JMb29rdXBUYWJsZURhdGEgPSBwYWxldHRlcy5ibHVlO1xuICAgICAgICAgICAgICAgIGluc3RhbmNlU3VtbWFyeS5yZWRQYWxldHRlQ29sb3JMb29rdXBUYWJsZURlc2NyaXB0b3IgPSByZWRQYWxldHRlQ29sb3JMb29rdXBUYWJsZURlc2NyaXB0b3I7XG4gICAgICAgICAgICAgICAgaW5zdGFuY2VTdW1tYXJ5LmdyZWVuUGFsZXR0ZUNvbG9yTG9va3VwVGFibGVEZXNjcmlwdG9yID0gZ3JlZW5QYWxldHRlQ29sb3JMb29rdXBUYWJsZURlc2NyaXB0b3I7XG4gICAgICAgICAgICAgICAgaW5zdGFuY2VTdW1tYXJ5LmJsdWVQYWxldHRlQ29sb3JMb29rdXBUYWJsZURlc2NyaXB0b3IgPSBibHVlUGFsZXR0ZUNvbG9yTG9va3VwVGFibGVEZXNjcmlwdG9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgc2VyaWVzLmluc3RhbmNlcy5wdXNoKGluc3RhbmNlU3VtbWFyeSk7XG5cbiAgICB9KTtcblxuICAgIHJldHVybiBzdHVkeURhdGE7XG59XG5cbi8qKlxuICogUmV0cmlldmVkIFN0dWR5IE1ldGFEYXRhIGZyb20gYSBESUNPTSBzZXJ2ZXIgdXNpbmcgYSBXQURPIGNhbGxcbiAqIEBwYXJhbSBzZXJ2ZXJcbiAqIEBwYXJhbSBzdHVkeUluc3RhbmNlVWlkXG4gKiBAcmV0dXJucyB7e3Nlcmllc0xpc3Q6IEFycmF5LCBwYXRpZW50TmFtZTogKiwgcGF0aWVudElkOiAqLCBhY2Nlc3Npb25OdW1iZXI6ICosIHN0dWR5RGF0ZTogKiwgbW9kYWxpdGllczogKiwgc3R1ZHlEZXNjcmlwdGlvbjogKiwgaW1hZ2VDb3VudDogKiwgc3R1ZHlJbnN0YW5jZVVpZDogKn19XG4gKi9cbk9ISUYuc3R1ZGllcy5zZXJ2aWNlcy5XQURPLlJldHJpZXZlTWV0YWRhdGEgPSBmdW5jdGlvbihzZXJ2ZXIsIHN0dWR5SW5zdGFuY2VVaWQpIHtcbiAgICB2YXIgdXJsID0gYnVpbGRVcmwoc2VydmVyLCBzdHVkeUluc3RhbmNlVWlkKTtcblxuICAgIHRyeSB7XG4gICAgICAgIHZhciByZXN1bHQgPSBESUNPTVdlYi5nZXRKU09OKHVybCwgc2VydmVyLnJlcXVlc3RPcHRpb25zKTtcblxuICAgICAgICB2YXIgc3R1ZHkgPSByZXN1bHREYXRhVG9TdHVkeU1ldGFkYXRhKHNlcnZlciwgc3R1ZHlJbnN0YW5jZVVpZCwgcmVzdWx0LmRhdGEpO1xuICAgICAgICBpZiAoIXN0dWR5KSB7XG4gICAgICAgICAgICBzdHVkeSA9IHt9O1xuICAgICAgICB9XG5cbiAgICAgICAgc3R1ZHkud2Fkb1VyaVJvb3QgPSBzZXJ2ZXIud2Fkb1VyaVJvb3Q7XG4gICAgICAgIHN0dWR5LnN0dWR5SW5zdGFuY2VVaWQgPSBzdHVkeUluc3RhbmNlVWlkO1xuXG4gICAgICAgIHJldHVybiBzdHVkeTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBPSElGLmxvZy50cmFjZSgpO1xuXG4gICAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbn07XG4iXX0=
