(function () {



/* Exports */
Package._define("standard-app-packages");

})();
