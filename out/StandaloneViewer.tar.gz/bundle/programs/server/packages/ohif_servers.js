(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Collection2 = Package['aldeed:collection2'].Collection2;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

var require = meteorInstall({"node_modules":{"meteor":{"ohif:servers":{"both":{"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/both/index.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.watch(require("./base.js"));
module.watch(require("./collections"));
module.watch(require("./lib"));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"base.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/both/base.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
OHIF.servers = {
  collections: {}
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"collections":{"currentServer.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/both/collections/currentServer.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  CurrentServer: () => CurrentServer
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);
// CurrentServer is a single document collection to describe which of the Servers is being used
const CurrentServer = new Mongo.Collection('currentServer');
CurrentServer._debugName = 'CurrentServer';
OHIF.servers.collections.currentServer = CurrentServer;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/both/collections/index.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  CurrentServer: () => CurrentServer,
  Servers: () => Servers
});
let CurrentServer;
module.watch(require("./currentServer.js"), {
  CurrentServer(v) {
    CurrentServer = v;
  }

}, 0);
let Servers;
module.watch(require("./servers.js"), {
  Servers(v) {
    Servers = v;
  }

}, 1);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"servers.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/both/collections/servers.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  Servers: () => Servers
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);
// import { Servers as ServerSchema } from 'meteor/ohif:servers/both/schema/servers.js';
// Servers describe the DICOM servers configurations
const Servers = new Mongo.Collection('servers'); // TODO: Make the Schema match what we are currently sticking into the Collection
//Servers.attachSchema(ServerSchema);

Servers._debugName = 'Servers';
OHIF.servers.collections.servers = Servers;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"lib":{"getCurrentServer.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/both/lib/getCurrentServer.js                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
let Servers, CurrentServer;
module.watch(require("meteor/ohif:servers/both/collections"), {
  Servers(v) {
    Servers = v;
  },

  CurrentServer(v) {
    CurrentServer = v;
  }

}, 1);

/**
 * Retrieves the current server configuration used to retrieve studies
 */
OHIF.servers.getCurrentServer = () => {
  const currentServer = CurrentServer.findOne();

  if (!currentServer) {
    return;
  }

  const serverConfiguration = Servers.findOne({
    _id: currentServer.serverId
  });
  return serverConfiguration;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/both/lib/index.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.watch(require("./getCurrentServer.js"));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"schema":{"servers.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/both/schema/servers.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  DICOMWebRequestOptions: () => DICOMWebRequestOptions,
  DICOMWebServer: () => DICOMWebServer,
  DIMSEPeer: () => DIMSEPeer,
  DIMSEServer: () => DIMSEServer,
  UISettings: () => UISettings,
  PrefetchSchema: () => PrefetchSchema,
  MouseButtonToolSchema: () => MouseButtonToolSchema,
  PublicServerConfig: () => PublicServerConfig,
  Servers: () => Servers,
  ServerConfiguration: () => ServerConfiguration
});
let SimpleSchema;
module.watch(require("meteor/aldeed:simple-schema"), {
  SimpleSchema(v) {
    SimpleSchema = v;
  }

}, 0);
const serverNameDefinitions = {
  type: String,
  label: 'Server Name',
  max: 100
};
const serverTypeDefinitions = {
  type: String,
  label: 'Server Type',
  allowedValues: ['dicomWeb', 'dimse'],
  valuesLabels: ['DICOM Web', 'DIMSE'],
  optional: true
};
const wadoUriRootDefinitions = {
  type: String,
  label: 'WADO URI root',
  max: 1000
};
const availableMouseButtonTools = ['wwwc', 'zoom', 'pan', 'stackScroll'];
const DICOMWebRequestOptions = new SimpleSchema({
  auth: {
    type: String,
    label: 'Authentication',
    defaultValue: 'orthanc:orthanc',
    optional: true
  },
  logRequests: {
    type: Boolean,
    defaultValue: true,
    label: 'Requests'
  },
  logResponses: {
    type: Boolean,
    defaultValue: false,
    label: 'Responses'
  },
  logTiming: {
    type: Boolean,
    defaultValue: true,
    label: 'Timing'
  }
});
const DICOMWebServer = new SimpleSchema({
  name: serverNameDefinitions,
  type: serverTypeDefinitions,
  wadoUriRoot: wadoUriRootDefinitions,
  wadoRoot: {
    type: String,
    label: 'WADO root',
    max: 1000
  },
  imageRendering: {
    type: String,
    label: 'Image rendering',
    allowedValues: ['wadouri', 'orthanc'],
    valuesLabels: ['WADO URI', 'ORTHANC']
  },
  qidoRoot: {
    type: String,
    label: 'QIDO root',
    max: 1000
  },
  qidoSupportsIncludeField: {
    type: Boolean,
    label: 'QIDO supports including fields',
    defaultValue: false
  },
  requestOptions: {
    type: DICOMWebRequestOptions,
    label: 'Request Options'
  }
});
const DIMSEPeer = new SimpleSchema({
  aeTitle: {
    type: String,
    label: 'AE Title'
  },
  hostAE: {
    type: String,
    label: 'AE Host',
    optional: true
  },
  host: {
    type: String,
    label: 'Host Domain/IP',
    regEx: SimpleSchema.RegEx.WeakDomain
  },
  port: {
    type: Number,
    label: 'Port',
    min: 1,
    defaultValue: 11112,
    max: 65535
  },
  default: {
    type: Boolean,
    label: 'Default',
    defaultValue: false
  },
  server: {
    type: Boolean,
    label: 'Server',
    defaultValue: false
  },
  supportsInstanceRetrievalByStudyUid: {
    type: Boolean,
    label: 'Supports instance retrieval by StudyUid',
    defaultValue: true
  }
});
const DIMSEServer = new SimpleSchema({
  name: serverNameDefinitions,
  type: serverTypeDefinitions,
  wadoUriRoot: wadoUriRootDefinitions,
  requestOptions: {
    type: DICOMWebRequestOptions,
    label: 'Request Options'
  },
  peers: {
    type: [DIMSEPeer],
    label: 'Peer List',
    minCount: 1
  }
});
const UISettings = new SimpleSchema({
  studyListFunctionsEnabled: {
    type: Boolean,
    label: 'Study List Functions Enabled?',
    defaultValue: true
  },
  leftSidebarOpen: {
    type: Boolean,
    label: 'Left sidebar open by default?',
    defaultValue: false
  },
  leftSidebarDragAndDrop: {
    type: Boolean,
    label: 'Left sidebar allows thumbnail drag and drop. If false, images will be loaded on single click.',
    defaultValue: true
  },
  displaySetNavigationLoopOverSeries: {
    type: Boolean,
    label: 'The UP/DOWN display set navigation buttons will start over when reach the last display set in viewport?',
    defaultValue: true
  },
  displaySetNavigationMultipleViewports: {
    type: Boolean,
    label: 'The UP/DOWN display set navigation buttons will iterate over all the viewports at once?',
    defaultValue: false
  },
  displayEchoUltrasoundWorkflow: {
    type: Boolean,
    label: 'Enable cine dialog enhancements for multiframe images.',
    defaultValue: false
  },
  autoPositionMeasurementsTextCallOuts: {
    type: String,
    label: 'Auto position text call-outs for measurements when creating them.',
    defaultValue: 'TRBL'
  },
  studyListDateFilterNumDays: {
    type: Number,
    label: 'Number of days to be used on Study List date filter',
    min: 1
  },
  showStackLoadingProgressBar: {
    type: Boolean,
    label: 'Show a progress bar closest to the thumbnail showing how much the stack has loaded',
    defaultValue: true
  },
  cornerstoneRenderer: {
    type: String,
    label: 'Cornerstone default image renderer',
    defaultValue: 'webgl'
  },
  sortSeriesByIncomingOrder: {
    type: Boolean,
    label: 'Define if the series\' images shall be sorted by incoming order. Sort by Instance Number by default.',
    defaultValue: false
  },
  useMiddleSeriesInstanceAsThumbnail: {
    type: Boolean,
    label: 'Define if the middle instance of a series will be used as thumbnail. If not, the first instance will be used.',
    defaultValue: true
  }
});
const PrefetchSchema = new SimpleSchema({
  order: {
    type: String,
    label: 'Prefetch Order',
    allowedValues: ['topdown', 'downward', 'closest'],
    optional: false
  },
  displaySetCount: {
    type: Number,
    label: 'Display Set Count',
    min: 1,
    defaultValue: 1
  }
});
const MouseButtonToolSchema = new SimpleSchema({
  left: {
    type: String,
    label: 'Left Mouse Button',
    allowedValues: availableMouseButtonTools,
    optional: true
  },
  right: {
    type: String,
    label: 'Right Mouse Button',
    allowedValues: availableMouseButtonTools,
    optional: true
  },
  middle: {
    type: String,
    label: 'Middle Mouse Button',
    allowedValues: availableMouseButtonTools,
    optional: true
  }
});
const PublicServerConfig = new SimpleSchema({
  verifyEmail: {
    type: Boolean,
    label: 'Verify Email',
    defaultValue: false
  },
  demoUserEnabled: {
    type: Boolean,
    label: 'Creates demo user on startup and show TestDrive button',
    defaultValue: true
  },
  ui: {
    type: UISettings,
    label: 'UI Settings'
  },
  prefetch: {
    type: PrefetchSchema,
    label: 'Prefetch settings'
  },
  defaultMouseButtonTools: {
    type: MouseButtonToolSchema,
    label: 'Default Mouse Button Tools'
  }
});
const Servers = new SimpleSchema({
  dicomWeb: {
    type: [DICOMWebServer],
    label: 'DICOMWeb Servers',
    optional: true
  },
  dimse: {
    type: [DIMSEServer],
    label: 'DIMSE Servers',
    optional: true
  }
});
const ServerConfiguration = new SimpleSchema({
  servers: {
    type: Servers,
    label: 'Servers'
  },
  defaultServiceType: {
    type: String,
    label: 'Default Service Type',
    defaultValue: 'dicomWeb'
  },
  dropCollections: {
    type: Boolean,
    label: 'Drop database collections',
    defaultValue: false
  },
  public: {
    type: PublicServerConfig,
    label: 'Public Server Configuration'
  },
  origin: {
    type: String,
    label: 'Origin',
    optional: true
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/server/index.js                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.watch(require("./publications.js"));
module.watch(require("./methods.js"));
module.watch(require("./startup.js"));
module.watch(require("./lib"));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/server/methods.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);
Meteor.methods({
  serverFind: query => OHIF.servers.control.find(query),
  serverSave: serverSettings => OHIF.servers.control.save(serverSettings),
  serverSetActive: serverId => OHIF.servers.control.setActive(serverId),
  serverRemove: serverId => OHIF.servers.control.remove(serverId)
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/server/publications.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Servers, CurrentServer;
module.watch(require("meteor/ohif:servers/both/collections"), {
  Servers(v) {
    Servers = v;
  },

  CurrentServer(v) {
    CurrentServer = v;
  }

}, 1);
// When publishing Servers Collection, do not publish the requestOptions.headers
// field in case any authentication information is being passed
Meteor.publish('servers', () => Servers.find({}, {
  fields: {
    'requestOptions.headers': 0
  }
}));
Meteor.publish('currentServer', () => CurrentServer.find());
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"startup.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/server/startup.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _;

module.watch(require("meteor/underscore"), {
  _(v) {
    _ = v;
  }

}, 1);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 2);
let Servers;
module.watch(require("meteor/ohif:servers/both/collections"), {
  Servers(v) {
    Servers = v;
  }

}, 3);
let ServerConfiguration;
module.watch(require("meteor/ohif:servers/both/schema/servers.js"), {
  ServerConfiguration(v) {
    ServerConfiguration = v;
  }

}, 4);
// Validate the servers configuration
Meteor.startup(() => {
  // Save custom properties (if any)...
  // "Meteor.settings" and "Meteor.settings.public" are set by default...
  let custom = {
    private: Meteor.settings.custom,
    public: Meteor.settings.public.custom
  }; // ... and remove them to prevent clean up

  delete Meteor.settings.custom;
  delete Meteor.settings.public.custom;
  ServerConfiguration.clean(Meteor.settings); // TODO: Make the error messages more clear
  // Taking this out for now to prevent confusion.
  // check(Meteor.settings, ServerConfiguration);

  Meteor.settings.custom = custom.private;
  Meteor.settings.public.custom = custom.public;
  OHIF.log.info(JSON.stringify(Meteor.settings, null, 2));
}); // Check the servers on meteor startup

Meteor.startup(function () {
  OHIF.log.info('Updating servers information from JSON configuration');

  _.each(Meteor.settings.servers, function (endpoints, serverType) {
    _.each(endpoints, function (endpoint) {
      const server = _.clone(endpoint);

      server.origin = 'json';
      server.type = serverType; // Try to find a server with the same name/type/origin combination

      const existingServer = Servers.findOne({
        name: server.name,
        type: server.type,
        origin: server.origin
      }); // Check if server was already added. Update it if so and insert if not

      if (existingServer) {
        Servers.update(existingServer._id, {
          $set: server
        });
      } else {
        Servers.insert(server);
      }
    });
  });

  OHIF.servers.control.resetCurrentServer();
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"control.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/server/lib/control.js                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 1);
let Servers, CurrentServer;
module.watch(require("meteor/ohif:servers/both/collections"), {
  Servers(v) {
    Servers = v;
  },

  CurrentServer(v) {
    CurrentServer = v;
  }

}, 2);
OHIF.servers.control = {
  writeCallback(error, affected) {
    if (error) {
      throw new Meteor.Error('data-write', error);
    }
  },

  resetCurrentServer() {
    const currentServer = CurrentServer.findOne();

    if (currentServer && Servers.find({
      _id: currentServer.serverId
    }).count()) {
      return;
    }

    const newServer = Servers.findOne({
      origin: 'json',
      type: Meteor.settings.defaultServiceType || 'dicomWeb'
    });

    if (newServer) {
      CurrentServer.remove({});
      CurrentServer.insert({
        serverId: newServer._id
      });
    }
  },

  find(query) {
    return Servers.find(query).fetch();
  },

  save(serverSettings) {
    const query = {
      _id: serverSettings._id
    };
    const options = {
      upsert: true
    };

    if (!serverSettings._id) {
      delete serverSettings._id;
    }

    return Servers.update(query, serverSettings, options, this.writeCallback);
  },

  setActive(serverId) {
    CurrentServer.remove({});
    CurrentServer.insert({
      serverId: serverId
    });
  },

  remove(serverId) {
    const query = {
      _id: serverId
    };
    const removeStatus = Servers.remove(query, this.writeCallback);
    OHIF.servers.control.resetCurrentServer();
    return removeStatus;
  }

};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ohif_servers/server/lib/index.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.watch(require("./control.js"));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/node_modules/meteor/ohif:servers/both/index.js");
require("/node_modules/meteor/ohif:servers/server/index.js");

/* Exports */
Package._define("ohif:servers");

})();

//# sourceURL=meteor://💻app/packages/ohif_servers.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzZXJ2ZXJzL2JvdGgvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6c2VydmVycy9ib3RoL2Jhc2UuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6c2VydmVycy9ib3RoL2NvbGxlY3Rpb25zL2N1cnJlbnRTZXJ2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6c2VydmVycy9ib3RoL2NvbGxlY3Rpb25zL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnNlcnZlcnMvYm90aC9jb2xsZWN0aW9ucy9zZXJ2ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnNlcnZlcnMvYm90aC9saWIvZ2V0Q3VycmVudFNlcnZlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzZXJ2ZXJzL2JvdGgvbGliL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnNlcnZlcnMvYm90aC9zY2hlbWEvc2VydmVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzZXJ2ZXJzL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzZXJ2ZXJzL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnNlcnZlcnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpzZXJ2ZXJzL3NlcnZlci9zdGFydHVwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnNlcnZlcnMvc2VydmVyL2xpYi9jb250cm9sLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOnNlcnZlcnMvc2VydmVyL2xpYi9pbmRleC5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJPSElGIiwidiIsInNlcnZlcnMiLCJjb2xsZWN0aW9ucyIsImV4cG9ydCIsIkN1cnJlbnRTZXJ2ZXIiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJfZGVidWdOYW1lIiwiY3VycmVudFNlcnZlciIsIlNlcnZlcnMiLCJnZXRDdXJyZW50U2VydmVyIiwiZmluZE9uZSIsInNlcnZlckNvbmZpZ3VyYXRpb24iLCJfaWQiLCJzZXJ2ZXJJZCIsIkRJQ09NV2ViUmVxdWVzdE9wdGlvbnMiLCJESUNPTVdlYlNlcnZlciIsIkRJTVNFUGVlciIsIkRJTVNFU2VydmVyIiwiVUlTZXR0aW5ncyIsIlByZWZldGNoU2NoZW1hIiwiTW91c2VCdXR0b25Ub29sU2NoZW1hIiwiUHVibGljU2VydmVyQ29uZmlnIiwiU2VydmVyQ29uZmlndXJhdGlvbiIsIlNpbXBsZVNjaGVtYSIsInNlcnZlck5hbWVEZWZpbml0aW9ucyIsInR5cGUiLCJTdHJpbmciLCJsYWJlbCIsIm1heCIsInNlcnZlclR5cGVEZWZpbml0aW9ucyIsImFsbG93ZWRWYWx1ZXMiLCJ2YWx1ZXNMYWJlbHMiLCJvcHRpb25hbCIsIndhZG9VcmlSb290RGVmaW5pdGlvbnMiLCJhdmFpbGFibGVNb3VzZUJ1dHRvblRvb2xzIiwiYXV0aCIsImRlZmF1bHRWYWx1ZSIsImxvZ1JlcXVlc3RzIiwiQm9vbGVhbiIsImxvZ1Jlc3BvbnNlcyIsImxvZ1RpbWluZyIsIm5hbWUiLCJ3YWRvVXJpUm9vdCIsIndhZG9Sb290IiwiaW1hZ2VSZW5kZXJpbmciLCJxaWRvUm9vdCIsInFpZG9TdXBwb3J0c0luY2x1ZGVGaWVsZCIsInJlcXVlc3RPcHRpb25zIiwiYWVUaXRsZSIsImhvc3RBRSIsImhvc3QiLCJyZWdFeCIsIlJlZ0V4IiwiV2Vha0RvbWFpbiIsInBvcnQiLCJOdW1iZXIiLCJtaW4iLCJkZWZhdWx0Iiwic2VydmVyIiwic3VwcG9ydHNJbnN0YW5jZVJldHJpZXZhbEJ5U3R1ZHlVaWQiLCJwZWVycyIsIm1pbkNvdW50Iiwic3R1ZHlMaXN0RnVuY3Rpb25zRW5hYmxlZCIsImxlZnRTaWRlYmFyT3BlbiIsImxlZnRTaWRlYmFyRHJhZ0FuZERyb3AiLCJkaXNwbGF5U2V0TmF2aWdhdGlvbkxvb3BPdmVyU2VyaWVzIiwiZGlzcGxheVNldE5hdmlnYXRpb25NdWx0aXBsZVZpZXdwb3J0cyIsImRpc3BsYXlFY2hvVWx0cmFzb3VuZFdvcmtmbG93IiwiYXV0b1Bvc2l0aW9uTWVhc3VyZW1lbnRzVGV4dENhbGxPdXRzIiwic3R1ZHlMaXN0RGF0ZUZpbHRlck51bURheXMiLCJzaG93U3RhY2tMb2FkaW5nUHJvZ3Jlc3NCYXIiLCJjb3JuZXJzdG9uZVJlbmRlcmVyIiwic29ydFNlcmllc0J5SW5jb21pbmdPcmRlciIsInVzZU1pZGRsZVNlcmllc0luc3RhbmNlQXNUaHVtYm5haWwiLCJvcmRlciIsImRpc3BsYXlTZXRDb3VudCIsImxlZnQiLCJyaWdodCIsIm1pZGRsZSIsInZlcmlmeUVtYWlsIiwiZGVtb1VzZXJFbmFibGVkIiwidWkiLCJwcmVmZXRjaCIsImRlZmF1bHRNb3VzZUJ1dHRvblRvb2xzIiwiZGljb21XZWIiLCJkaW1zZSIsImRlZmF1bHRTZXJ2aWNlVHlwZSIsImRyb3BDb2xsZWN0aW9ucyIsInB1YmxpYyIsIm9yaWdpbiIsIk1ldGVvciIsIm1ldGhvZHMiLCJzZXJ2ZXJGaW5kIiwicXVlcnkiLCJjb250cm9sIiwiZmluZCIsInNlcnZlclNhdmUiLCJzZXJ2ZXJTZXR0aW5ncyIsInNhdmUiLCJzZXJ2ZXJTZXRBY3RpdmUiLCJzZXRBY3RpdmUiLCJzZXJ2ZXJSZW1vdmUiLCJyZW1vdmUiLCJwdWJsaXNoIiwiZmllbGRzIiwiXyIsInN0YXJ0dXAiLCJjdXN0b20iLCJwcml2YXRlIiwic2V0dGluZ3MiLCJjbGVhbiIsImxvZyIsImluZm8iLCJKU09OIiwic3RyaW5naWZ5IiwiZWFjaCIsImVuZHBvaW50cyIsInNlcnZlclR5cGUiLCJlbmRwb2ludCIsImNsb25lIiwiZXhpc3RpbmdTZXJ2ZXIiLCJ1cGRhdGUiLCIkc2V0IiwiaW5zZXJ0IiwicmVzZXRDdXJyZW50U2VydmVyIiwid3JpdGVDYWxsYmFjayIsImVycm9yIiwiYWZmZWN0ZWQiLCJFcnJvciIsImNvdW50IiwibmV3U2VydmVyIiwiZmV0Y2giLCJvcHRpb25zIiwidXBzZXJ0IiwicmVtb3ZlU3RhdHVzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYjtBQUFtQ0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYjtBQUF1Q0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0ExRSxJQUFJQyxJQUFKO0FBQVNILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNDLE9BQUtDLENBQUwsRUFBTztBQUFDRCxXQUFLQyxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBRVRELEtBQUtFLE9BQUwsR0FBZTtBQUNYQyxlQUFhO0FBREYsQ0FBZixDOzs7Ozs7Ozs7OztBQ0ZBTixPQUFPTyxNQUFQLENBQWM7QUFBQ0MsaUJBQWMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJQyxLQUFKO0FBQVVULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ08sUUFBTUwsQ0FBTixFQUFRO0FBQUNLLFlBQU1MLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUQsSUFBSjtBQUFTSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDQyxPQUFLQyxDQUFMLEVBQU87QUFBQ0QsV0FBS0MsQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUdoSTtBQUNBLE1BQU1JLGdCQUFnQixJQUFJQyxNQUFNQyxVQUFWLENBQXFCLGVBQXJCLENBQXRCO0FBQ0FGLGNBQWNHLFVBQWQsR0FBMkIsZUFBM0I7QUFDQVIsS0FBS0UsT0FBTCxDQUFhQyxXQUFiLENBQXlCTSxhQUF6QixHQUF5Q0osYUFBekMsQzs7Ozs7Ozs7Ozs7QUNOQVIsT0FBT08sTUFBUCxDQUFjO0FBQUNDLGlCQUFjLE1BQUlBLGFBQW5CO0FBQWlDSyxXQUFRLE1BQUlBO0FBQTdDLENBQWQ7QUFBcUUsSUFBSUwsYUFBSjtBQUFrQlIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ00sZ0JBQWNKLENBQWQsRUFBZ0I7QUFBQ0ksb0JBQWNKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQTNDLEVBQStFLENBQS9FO0FBQWtGLElBQUlTLE9BQUo7QUFBWWIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDVyxVQUFRVCxDQUFSLEVBQVU7QUFBQ1MsY0FBUVQsQ0FBUjtBQUFVOztBQUF0QixDQUFyQyxFQUE2RCxDQUE3RCxFOzs7Ozs7Ozs7OztBQ0FyTEosT0FBT08sTUFBUCxDQUFjO0FBQUNNLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUlKLEtBQUo7QUFBVVQsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDTyxRQUFNTCxDQUFOLEVBQVE7QUFBQ0ssWUFBTUwsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRCxJQUFKO0FBQVNILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNDLE9BQUtDLENBQUwsRUFBTztBQUFDRCxXQUFLQyxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBRXBIO0FBRUE7QUFDQSxNQUFNUyxVQUFVLElBQUlKLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsQ0FBaEIsQyxDQUNBO0FBQ0E7O0FBQ0FHLFFBQVFGLFVBQVIsR0FBcUIsU0FBckI7QUFDQVIsS0FBS0UsT0FBTCxDQUFhQyxXQUFiLENBQXlCRCxPQUF6QixHQUFtQ1EsT0FBbkMsQzs7Ozs7Ozs7Ozs7QUNUQSxJQUFJVixJQUFKO0FBQVNILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNDLE9BQUtDLENBQUwsRUFBTztBQUFDRCxXQUFLQyxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBQThELElBQUlTLE9BQUosRUFBWUwsYUFBWjtBQUEwQlIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNDQUFSLENBQWIsRUFBNkQ7QUFBQ1csVUFBUVQsQ0FBUixFQUFVO0FBQUNTLGNBQVFULENBQVI7QUFBVSxHQUF0Qjs7QUFBdUJJLGdCQUFjSixDQUFkLEVBQWdCO0FBQUNJLG9CQUFjSixDQUFkO0FBQWdCOztBQUF4RCxDQUE3RCxFQUF1SCxDQUF2SDs7QUFHakc7OztBQUdBRCxLQUFLRSxPQUFMLENBQWFTLGdCQUFiLEdBQWdDLE1BQU07QUFDbEMsUUFBTUYsZ0JBQWdCSixjQUFjTyxPQUFkLEVBQXRCOztBQUVBLE1BQUksQ0FBQ0gsYUFBTCxFQUFvQjtBQUNoQjtBQUNIOztBQUVELFFBQU1JLHNCQUFzQkgsUUFBUUUsT0FBUixDQUFnQjtBQUFFRSxTQUFLTCxjQUFjTTtBQUFyQixHQUFoQixDQUE1QjtBQUVBLFNBQU9GLG1CQUFQO0FBQ0gsQ0FWRCxDOzs7Ozs7Ozs7OztBQ05BaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBQUYsT0FBT08sTUFBUCxDQUFjO0FBQUNZLDBCQUF1QixNQUFJQSxzQkFBNUI7QUFBbURDLGtCQUFlLE1BQUlBLGNBQXRFO0FBQXFGQyxhQUFVLE1BQUlBLFNBQW5HO0FBQTZHQyxlQUFZLE1BQUlBLFdBQTdIO0FBQXlJQyxjQUFXLE1BQUlBLFVBQXhKO0FBQW1LQyxrQkFBZSxNQUFJQSxjQUF0TDtBQUFxTUMseUJBQXNCLE1BQUlBLHFCQUEvTjtBQUFxUEMsc0JBQW1CLE1BQUlBLGtCQUE1UTtBQUErUmIsV0FBUSxNQUFJQSxPQUEzUztBQUFtVGMsdUJBQW9CLE1BQUlBO0FBQTNVLENBQWQ7QUFBK1csSUFBSUMsWUFBSjtBQUFpQjVCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUMwQixlQUFheEIsQ0FBYixFQUFlO0FBQUN3QixtQkFBYXhCLENBQWI7QUFBZTs7QUFBaEMsQ0FBcEQsRUFBc0YsQ0FBdEY7QUFFaFksTUFBTXlCLHdCQUF3QjtBQUMxQkMsUUFBTUMsTUFEb0I7QUFFMUJDLFNBQU8sYUFGbUI7QUFHMUJDLE9BQUs7QUFIcUIsQ0FBOUI7QUFNQSxNQUFNQyx3QkFBd0I7QUFDMUJKLFFBQU1DLE1BRG9CO0FBRTFCQyxTQUFPLGFBRm1CO0FBRzFCRyxpQkFBZSxDQUFDLFVBQUQsRUFBYSxPQUFiLENBSFc7QUFJMUJDLGdCQUFjLENBQUMsV0FBRCxFQUFjLE9BQWQsQ0FKWTtBQUsxQkMsWUFBVTtBQUxnQixDQUE5QjtBQVFBLE1BQU1DLHlCQUF5QjtBQUMzQlIsUUFBTUMsTUFEcUI7QUFFM0JDLFNBQU8sZUFGb0I7QUFHM0JDLE9BQUs7QUFIc0IsQ0FBL0I7QUFNQSxNQUFNTSw0QkFBNEIsQ0FBQyxNQUFELEVBQVMsTUFBVCxFQUFpQixLQUFqQixFQUF3QixhQUF4QixDQUFsQztBQUVPLE1BQU1wQix5QkFBeUIsSUFBSVMsWUFBSixDQUFpQjtBQUNuRFksUUFBTTtBQUNGVixVQUFNQyxNQURKO0FBRUZDLFdBQU8sZ0JBRkw7QUFHRlMsa0JBQWMsaUJBSFo7QUFJRkosY0FBVTtBQUpSLEdBRDZDO0FBT25ESyxlQUFhO0FBQ1RaLFVBQU1hLE9BREc7QUFFVEYsa0JBQWMsSUFGTDtBQUdUVCxXQUFPO0FBSEUsR0FQc0M7QUFZbkRZLGdCQUFjO0FBQ1ZkLFVBQU1hLE9BREk7QUFFVkYsa0JBQWMsS0FGSjtBQUdWVCxXQUFPO0FBSEcsR0FacUM7QUFpQm5EYSxhQUFXO0FBQ1BmLFVBQU1hLE9BREM7QUFFUEYsa0JBQWMsSUFGUDtBQUdQVCxXQUFPO0FBSEE7QUFqQndDLENBQWpCLENBQS9CO0FBd0JBLE1BQU1aLGlCQUFpQixJQUFJUSxZQUFKLENBQWlCO0FBQzNDa0IsUUFBTWpCLHFCQURxQztBQUUzQ0MsUUFBTUkscUJBRnFDO0FBRzNDYSxlQUFhVCxzQkFIOEI7QUFJM0NVLFlBQVU7QUFDTmxCLFVBQU1DLE1BREE7QUFFTkMsV0FBTyxXQUZEO0FBR05DLFNBQUs7QUFIQyxHQUppQztBQVMzQ2dCLGtCQUFnQjtBQUNabkIsVUFBTUMsTUFETTtBQUVaQyxXQUFPLGlCQUZLO0FBR1pHLG1CQUFlLENBQUMsU0FBRCxFQUFZLFNBQVosQ0FISDtBQUlaQyxrQkFBYyxDQUFDLFVBQUQsRUFBYSxTQUFiO0FBSkYsR0FUMkI7QUFlM0NjLFlBQVU7QUFDTnBCLFVBQU1DLE1BREE7QUFFTkMsV0FBTyxXQUZEO0FBR05DLFNBQUs7QUFIQyxHQWZpQztBQW9CM0NrQiw0QkFBMEI7QUFDdEJyQixVQUFNYSxPQURnQjtBQUV0QlgsV0FBTyxnQ0FGZTtBQUd0QlMsa0JBQWM7QUFIUSxHQXBCaUI7QUF5QjNDVyxrQkFBZ0I7QUFDWnRCLFVBQU1YLHNCQURNO0FBRVphLFdBQU87QUFGSztBQXpCMkIsQ0FBakIsQ0FBdkI7QUErQkEsTUFBTVgsWUFBWSxJQUFJTyxZQUFKLENBQWlCO0FBQ3RDeUIsV0FBUztBQUNMdkIsVUFBTUMsTUFERDtBQUVMQyxXQUFPO0FBRkYsR0FENkI7QUFLdENzQixVQUFRO0FBQ0p4QixVQUFNQyxNQURGO0FBRUpDLFdBQU8sU0FGSDtBQUdKSyxjQUFVO0FBSE4sR0FMOEI7QUFVdENrQixRQUFNO0FBQ0Z6QixVQUFNQyxNQURKO0FBRUZDLFdBQU8sZ0JBRkw7QUFHRndCLFdBQU81QixhQUFhNkIsS0FBYixDQUFtQkM7QUFIeEIsR0FWZ0M7QUFldENDLFFBQU07QUFDRjdCLFVBQU04QixNQURKO0FBRUY1QixXQUFPLE1BRkw7QUFHRjZCLFNBQUssQ0FISDtBQUlGcEIsa0JBQWMsS0FKWjtBQUtGUixTQUFLO0FBTEgsR0FmZ0M7QUFzQnRDNkIsV0FBUztBQUNMaEMsVUFBTWEsT0FERDtBQUVMWCxXQUFPLFNBRkY7QUFHTFMsa0JBQWM7QUFIVCxHQXRCNkI7QUEyQnRDc0IsVUFBUTtBQUNKakMsVUFBTWEsT0FERjtBQUVKWCxXQUFPLFFBRkg7QUFHSlMsa0JBQWM7QUFIVixHQTNCOEI7QUFnQ3RDdUIsdUNBQXFDO0FBQ2pDbEMsVUFBTWEsT0FEMkI7QUFFakNYLFdBQU8seUNBRjBCO0FBR2pDUyxrQkFBYztBQUhtQjtBQWhDQyxDQUFqQixDQUFsQjtBQXVDQSxNQUFNbkIsY0FBYyxJQUFJTSxZQUFKLENBQWlCO0FBQ3hDa0IsUUFBTWpCLHFCQURrQztBQUV4Q0MsUUFBTUkscUJBRmtDO0FBR3hDYSxlQUFhVCxzQkFIMkI7QUFJeENjLGtCQUFnQjtBQUNadEIsVUFBTVgsc0JBRE07QUFFWmEsV0FBTztBQUZLLEdBSndCO0FBUXhDaUMsU0FBTztBQUNIbkMsVUFBTSxDQUFDVCxTQUFELENBREg7QUFFSFcsV0FBTyxXQUZKO0FBR0hrQyxjQUFVO0FBSFA7QUFSaUMsQ0FBakIsQ0FBcEI7QUFlQSxNQUFNM0MsYUFBYSxJQUFJSyxZQUFKLENBQWlCO0FBQ3ZDdUMsNkJBQTJCO0FBQ3ZCckMsVUFBTWEsT0FEaUI7QUFFdkJYLFdBQU8sK0JBRmdCO0FBR3ZCUyxrQkFBYztBQUhTLEdBRFk7QUFNdkMyQixtQkFBaUI7QUFDYnRDLFVBQU1hLE9BRE87QUFFYlgsV0FBTywrQkFGTTtBQUdiUyxrQkFBYztBQUhELEdBTnNCO0FBV3ZDNEIsMEJBQXdCO0FBQ3BCdkMsVUFBTWEsT0FEYztBQUVwQlgsV0FBTywrRkFGYTtBQUdwQlMsa0JBQWM7QUFITSxHQVhlO0FBZ0J2QzZCLHNDQUFvQztBQUNoQ3hDLFVBQU1hLE9BRDBCO0FBRWhDWCxXQUFPLHlHQUZ5QjtBQUdoQ1Msa0JBQWM7QUFIa0IsR0FoQkc7QUFxQnZDOEIseUNBQXVDO0FBQ25DekMsVUFBTWEsT0FENkI7QUFFbkNYLFdBQU8seUZBRjRCO0FBR25DUyxrQkFBYztBQUhxQixHQXJCQTtBQTBCdkMrQixpQ0FBK0I7QUFDM0IxQyxVQUFNYSxPQURxQjtBQUUzQlgsV0FBTyx3REFGb0I7QUFHM0JTLGtCQUFjO0FBSGEsR0ExQlE7QUErQnZDZ0Msd0NBQXNDO0FBQ2xDM0MsVUFBTUMsTUFENEI7QUFFbENDLFdBQU8sbUVBRjJCO0FBR2xDUyxrQkFBYztBQUhvQixHQS9CQztBQW9DdkNpQyw4QkFBNEI7QUFDeEI1QyxVQUFNOEIsTUFEa0I7QUFFeEI1QixXQUFPLHFEQUZpQjtBQUd4QjZCLFNBQUs7QUFIbUIsR0FwQ1c7QUF5Q3ZDYywrQkFBNkI7QUFDekI3QyxVQUFNYSxPQURtQjtBQUV6QlgsV0FBTyxvRkFGa0I7QUFHekJTLGtCQUFjO0FBSFcsR0F6Q1U7QUE4Q3ZDbUMsdUJBQXFCO0FBQ2pCOUMsVUFBTUMsTUFEVztBQUVqQkMsV0FBTyxvQ0FGVTtBQUdqQlMsa0JBQWM7QUFIRyxHQTlDa0I7QUFtRHZDb0MsNkJBQTJCO0FBQ3ZCL0MsVUFBTWEsT0FEaUI7QUFFdkJYLFdBQU8sc0dBRmdCO0FBR3ZCUyxrQkFBYztBQUhTLEdBbkRZO0FBd0R2Q3FDLHNDQUFvQztBQUNoQ2hELFVBQU1hLE9BRDBCO0FBRWhDWCxXQUFPLCtHQUZ5QjtBQUdoQ1Msa0JBQWM7QUFIa0I7QUF4REcsQ0FBakIsQ0FBbkI7QUErREEsTUFBTWpCLGlCQUFpQixJQUFJSSxZQUFKLENBQWlCO0FBQzNDbUQsU0FBTztBQUNIakQsVUFBTUMsTUFESDtBQUVIQyxXQUFPLGdCQUZKO0FBR0hHLG1CQUFlLENBQUMsU0FBRCxFQUFZLFVBQVosRUFBd0IsU0FBeEIsQ0FIWjtBQUlIRSxjQUFVO0FBSlAsR0FEb0M7QUFPM0MyQyxtQkFBaUI7QUFDYmxELFVBQU04QixNQURPO0FBRWI1QixXQUFPLG1CQUZNO0FBR2I2QixTQUFLLENBSFE7QUFJYnBCLGtCQUFjO0FBSkQ7QUFQMEIsQ0FBakIsQ0FBdkI7QUFlQSxNQUFNaEIsd0JBQXdCLElBQUlHLFlBQUosQ0FBaUI7QUFDbERxRCxRQUFNO0FBQ0ZuRCxVQUFNQyxNQURKO0FBRUZDLFdBQU8sbUJBRkw7QUFHRkcsbUJBQWVJLHlCQUhiO0FBSUZGLGNBQVU7QUFKUixHQUQ0QztBQU9sRDZDLFNBQU87QUFDSHBELFVBQU1DLE1BREg7QUFFSEMsV0FBTyxvQkFGSjtBQUdIRyxtQkFBZUkseUJBSFo7QUFJSEYsY0FBVTtBQUpQLEdBUDJDO0FBYWxEOEMsVUFBUTtBQUNKckQsVUFBTUMsTUFERjtBQUVKQyxXQUFPLHFCQUZIO0FBR0pHLG1CQUFlSSx5QkFIWDtBQUlKRixjQUFVO0FBSk47QUFiMEMsQ0FBakIsQ0FBOUI7QUFxQkEsTUFBTVgscUJBQXFCLElBQUlFLFlBQUosQ0FBaUI7QUFDL0N3RCxlQUFhO0FBQ1R0RCxVQUFNYSxPQURHO0FBRVRYLFdBQU8sY0FGRTtBQUdUUyxrQkFBYztBQUhMLEdBRGtDO0FBTS9DNEMsbUJBQWlCO0FBQ2J2RCxVQUFNYSxPQURPO0FBRWJYLFdBQU8sd0RBRk07QUFHYlMsa0JBQWM7QUFIRCxHQU44QjtBQVcvQzZDLE1BQUk7QUFDQXhELFVBQU1QLFVBRE47QUFFQVMsV0FBTztBQUZQLEdBWDJDO0FBZS9DdUQsWUFBVTtBQUNOekQsVUFBTU4sY0FEQTtBQUVOUSxXQUFPO0FBRkQsR0FmcUM7QUFtQi9Dd0QsMkJBQXlCO0FBQ3JCMUQsVUFBTUwscUJBRGU7QUFFckJPLFdBQU87QUFGYztBQW5Cc0IsQ0FBakIsQ0FBM0I7QUF5QkEsTUFBTW5CLFVBQVUsSUFBSWUsWUFBSixDQUFpQjtBQUNwQzZELFlBQVU7QUFDTjNELFVBQU0sQ0FBQ1YsY0FBRCxDQURBO0FBRU5ZLFdBQU8sa0JBRkQ7QUFHTkssY0FBVTtBQUhKLEdBRDBCO0FBTXBDcUQsU0FBTztBQUNINUQsVUFBTSxDQUFDUixXQUFELENBREg7QUFFSFUsV0FBTyxlQUZKO0FBR0hLLGNBQVU7QUFIUDtBQU42QixDQUFqQixDQUFoQjtBQWFBLE1BQU1WLHNCQUFzQixJQUFJQyxZQUFKLENBQWlCO0FBQ2hEdkIsV0FBUztBQUNMeUIsVUFBTWpCLE9BREQ7QUFFTG1CLFdBQU87QUFGRixHQUR1QztBQUtoRDJELHNCQUFvQjtBQUNoQjdELFVBQU1DLE1BRFU7QUFFaEJDLFdBQU8sc0JBRlM7QUFHaEJTLGtCQUFjO0FBSEUsR0FMNEI7QUFVaERtRCxtQkFBaUI7QUFDYjlELFVBQU1hLE9BRE87QUFFYlgsV0FBTywyQkFGTTtBQUdiUyxrQkFBYztBQUhELEdBVitCO0FBZWhEb0QsVUFBUTtBQUNKL0QsVUFBTUosa0JBREY7QUFFSk0sV0FBTztBQUZILEdBZndDO0FBbUJoRDhELFVBQVE7QUFDSmhFLFVBQU1DLE1BREY7QUFFSkMsV0FBTyxRQUZIO0FBR0pLLGNBQVU7QUFITjtBQW5Cd0MsQ0FBakIsQ0FBNUIsQzs7Ozs7Ozs7Ozs7QUM5UVByQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYjtBQUEyQ0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYjtBQUFzQ0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYjtBQUFzQ0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0F2SCxJQUFJNkYsTUFBSjtBQUFXL0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDNkYsU0FBTzNGLENBQVAsRUFBUztBQUFDMkYsYUFBTzNGLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUQsSUFBSjtBQUFTSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDQyxPQUFLQyxDQUFMLEVBQU87QUFBQ0QsV0FBS0MsQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUduRjJGLE9BQU9DLE9BQVAsQ0FBZTtBQUNYQyxjQUFZQyxTQUFTL0YsS0FBS0UsT0FBTCxDQUFhOEYsT0FBYixDQUFxQkMsSUFBckIsQ0FBMEJGLEtBQTFCLENBRFY7QUFFWEcsY0FBWUMsa0JBQWtCbkcsS0FBS0UsT0FBTCxDQUFhOEYsT0FBYixDQUFxQkksSUFBckIsQ0FBMEJELGNBQTFCLENBRm5CO0FBR1hFLG1CQUFpQnRGLFlBQVlmLEtBQUtFLE9BQUwsQ0FBYThGLE9BQWIsQ0FBcUJNLFNBQXJCLENBQStCdkYsUUFBL0IsQ0FIbEI7QUFJWHdGLGdCQUFjeEYsWUFBWWYsS0FBS0UsT0FBTCxDQUFhOEYsT0FBYixDQUFxQlEsTUFBckIsQ0FBNEJ6RixRQUE1QjtBQUpmLENBQWYsRTs7Ozs7Ozs7Ozs7QUNIQSxJQUFJNkUsTUFBSjtBQUFXL0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDNkYsU0FBTzNGLENBQVAsRUFBUztBQUFDMkYsYUFBTzNGLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSVMsT0FBSixFQUFZTCxhQUFaO0FBQTBCUixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0NBQVIsQ0FBYixFQUE2RDtBQUFDVyxVQUFRVCxDQUFSLEVBQVU7QUFBQ1MsY0FBUVQsQ0FBUjtBQUFVLEdBQXRCOztBQUF1QkksZ0JBQWNKLENBQWQsRUFBZ0I7QUFBQ0ksb0JBQWNKLENBQWQ7QUFBZ0I7O0FBQXhELENBQTdELEVBQXVILENBQXZIO0FBR3BHO0FBQ0E7QUFDQTJGLE9BQU9hLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLE1BQU0vRixRQUFRdUYsSUFBUixDQUFhLEVBQWIsRUFBaUI7QUFDN0NTLFVBQVE7QUFBRSw4QkFBMEI7QUFBNUI7QUFEcUMsQ0FBakIsQ0FBaEM7QUFJQWQsT0FBT2EsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsTUFBTXBHLGNBQWM0RixJQUFkLEVBQXRDLEU7Ozs7Ozs7Ozs7O0FDVEEsSUFBSUwsTUFBSjtBQUFXL0YsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDNkYsU0FBTzNGLENBQVAsRUFBUztBQUFDMkYsYUFBTzNGLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBQStELElBQUkwRyxDQUFKOztBQUFNOUcsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1CQUFSLENBQWIsRUFBMEM7QUFBQzRHLElBQUUxRyxDQUFGLEVBQUk7QUFBQzBHLFFBQUUxRyxDQUFGO0FBQUk7O0FBQVYsQ0FBMUMsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUQsSUFBSjtBQUFTSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDQyxPQUFLQyxDQUFMLEVBQU87QUFBQ0QsV0FBS0MsQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUE4RCxJQUFJUyxPQUFKO0FBQVliLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQ0FBUixDQUFiLEVBQTZEO0FBQUNXLFVBQVFULENBQVIsRUFBVTtBQUFDUyxjQUFRVCxDQUFSO0FBQVU7O0FBQXRCLENBQTdELEVBQXFGLENBQXJGO0FBQXdGLElBQUl1QixtQkFBSjtBQUF3QjNCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw0Q0FBUixDQUFiLEVBQW1FO0FBQUN5QixzQkFBb0J2QixDQUFwQixFQUFzQjtBQUFDdUIsMEJBQW9CdkIsQ0FBcEI7QUFBc0I7O0FBQTlDLENBQW5FLEVBQW1ILENBQW5IO0FBTTVVO0FBQ0EyRixPQUFPZ0IsT0FBUCxDQUFlLE1BQU07QUFDakI7QUFDQTtBQUNBLE1BQUlDLFNBQVM7QUFDVEMsYUFBU2xCLE9BQU9tQixRQUFQLENBQWdCRixNQURoQjtBQUVUbkIsWUFBUUUsT0FBT21CLFFBQVAsQ0FBZ0JyQixNQUFoQixDQUF1Qm1CO0FBRnRCLEdBQWIsQ0FIaUIsQ0FRakI7O0FBQ0EsU0FBT2pCLE9BQU9tQixRQUFQLENBQWdCRixNQUF2QjtBQUNBLFNBQU9qQixPQUFPbUIsUUFBUCxDQUFnQnJCLE1BQWhCLENBQXVCbUIsTUFBOUI7QUFFQXJGLHNCQUFvQndGLEtBQXBCLENBQTBCcEIsT0FBT21CLFFBQWpDLEVBWmlCLENBY2pCO0FBQ0E7QUFDQTs7QUFFQW5CLFNBQU9tQixRQUFQLENBQWdCRixNQUFoQixHQUF5QkEsT0FBT0MsT0FBaEM7QUFDQWxCLFNBQU9tQixRQUFQLENBQWdCckIsTUFBaEIsQ0FBdUJtQixNQUF2QixHQUFnQ0EsT0FBT25CLE1BQXZDO0FBRUExRixPQUFLaUgsR0FBTCxDQUFTQyxJQUFULENBQWNDLEtBQUtDLFNBQUwsQ0FBZXhCLE9BQU9tQixRQUF0QixFQUFnQyxJQUFoQyxFQUFzQyxDQUF0QyxDQUFkO0FBQ0gsQ0F0QkQsRSxDQXdCQTs7QUFDQW5CLE9BQU9nQixPQUFQLENBQWUsWUFBVztBQUN0QjVHLE9BQUtpSCxHQUFMLENBQVNDLElBQVQsQ0FBYyxzREFBZDs7QUFFQVAsSUFBRVUsSUFBRixDQUFPekIsT0FBT21CLFFBQVAsQ0FBZ0I3RyxPQUF2QixFQUFnQyxVQUFTb0gsU0FBVCxFQUFvQkMsVUFBcEIsRUFBZ0M7QUFDNURaLE1BQUVVLElBQUYsQ0FBT0MsU0FBUCxFQUFrQixVQUFTRSxRQUFULEVBQW1CO0FBQ2pDLFlBQU01RCxTQUFTK0MsRUFBRWMsS0FBRixDQUFRRCxRQUFSLENBQWY7O0FBQ0E1RCxhQUFPK0IsTUFBUCxHQUFnQixNQUFoQjtBQUNBL0IsYUFBT2pDLElBQVAsR0FBYzRGLFVBQWQsQ0FIaUMsQ0FLakM7O0FBQ0EsWUFBTUcsaUJBQWlCaEgsUUFBUUUsT0FBUixDQUFnQjtBQUNuQytCLGNBQU1pQixPQUFPakIsSUFEc0I7QUFFbkNoQixjQUFNaUMsT0FBT2pDLElBRnNCO0FBR25DZ0UsZ0JBQVEvQixPQUFPK0I7QUFIb0IsT0FBaEIsQ0FBdkIsQ0FOaUMsQ0FZakM7O0FBQ0EsVUFBSStCLGNBQUosRUFBb0I7QUFDaEJoSCxnQkFBUWlILE1BQVIsQ0FBZUQsZUFBZTVHLEdBQTlCLEVBQW1DO0FBQUU4RyxnQkFBTWhFO0FBQVIsU0FBbkM7QUFDSCxPQUZELE1BRU87QUFDSGxELGdCQUFRbUgsTUFBUixDQUFlakUsTUFBZjtBQUNIO0FBQ0osS0FsQkQ7QUFtQkgsR0FwQkQ7O0FBc0JBNUQsT0FBS0UsT0FBTCxDQUFhOEYsT0FBYixDQUFxQjhCLGtCQUFyQjtBQUNILENBMUJELEU7Ozs7Ozs7Ozs7O0FDaENBLElBQUlsQyxNQUFKO0FBQVcvRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUM2RixTQUFPM0YsQ0FBUCxFQUFTO0FBQUMyRixhQUFPM0YsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJRCxJQUFKO0FBQVNILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQkFBUixDQUFiLEVBQXlDO0FBQUNDLE9BQUtDLENBQUwsRUFBTztBQUFDRCxXQUFLQyxDQUFMO0FBQU87O0FBQWhCLENBQXpDLEVBQTJELENBQTNEO0FBQThELElBQUlTLE9BQUosRUFBWUwsYUFBWjtBQUEwQlIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNDQUFSLENBQWIsRUFBNkQ7QUFBQ1csVUFBUVQsQ0FBUixFQUFVO0FBQUNTLGNBQVFULENBQVI7QUFBVSxHQUF0Qjs7QUFBdUJJLGdCQUFjSixDQUFkLEVBQWdCO0FBQUNJLG9CQUFjSixDQUFkO0FBQWdCOztBQUF4RCxDQUE3RCxFQUF1SCxDQUF2SDtBQUkzS0QsS0FBS0UsT0FBTCxDQUFhOEYsT0FBYixHQUF1QjtBQUNuQitCLGdCQUFjQyxLQUFkLEVBQXFCQyxRQUFyQixFQUErQjtBQUMzQixRQUFJRCxLQUFKLEVBQVc7QUFDUCxZQUFNLElBQUlwQyxPQUFPc0MsS0FBWCxDQUFpQixZQUFqQixFQUErQkYsS0FBL0IsQ0FBTjtBQUNIO0FBQ0osR0FMa0I7O0FBT25CRix1QkFBcUI7QUFDakIsVUFBTXJILGdCQUFnQkosY0FBY08sT0FBZCxFQUF0Qjs7QUFDQSxRQUFJSCxpQkFBaUJDLFFBQVF1RixJQUFSLENBQWE7QUFBRW5GLFdBQUtMLGNBQWNNO0FBQXJCLEtBQWIsRUFBOENvSCxLQUE5QyxFQUFyQixFQUE0RTtBQUN4RTtBQUNIOztBQUVELFVBQU1DLFlBQVkxSCxRQUFRRSxPQUFSLENBQWdCO0FBQzlCK0UsY0FBUSxNQURzQjtBQUU5QmhFLFlBQU1pRSxPQUFPbUIsUUFBUCxDQUFnQnZCLGtCQUFoQixJQUFzQztBQUZkLEtBQWhCLENBQWxCOztBQUtBLFFBQUk0QyxTQUFKLEVBQWU7QUFDWC9ILG9CQUFjbUcsTUFBZCxDQUFxQixFQUFyQjtBQUNBbkcsb0JBQWN3SCxNQUFkLENBQXFCO0FBQ2pCOUcsa0JBQVVxSCxVQUFVdEg7QUFESCxPQUFyQjtBQUdIO0FBQ0osR0F4QmtCOztBQTBCbkJtRixPQUFLRixLQUFMLEVBQVk7QUFDUixXQUFPckYsUUFBUXVGLElBQVIsQ0FBYUYsS0FBYixFQUFvQnNDLEtBQXBCLEVBQVA7QUFDSCxHQTVCa0I7O0FBOEJuQmpDLE9BQUtELGNBQUwsRUFBcUI7QUFDakIsVUFBTUosUUFBUTtBQUNWakYsV0FBS3FGLGVBQWVyRjtBQURWLEtBQWQ7QUFHQSxVQUFNd0gsVUFBVTtBQUNaQyxjQUFRO0FBREksS0FBaEI7O0FBSUEsUUFBSSxDQUFDcEMsZUFBZXJGLEdBQXBCLEVBQXlCO0FBQ3JCLGFBQU9xRixlQUFlckYsR0FBdEI7QUFDSDs7QUFFRCxXQUFPSixRQUFRaUgsTUFBUixDQUFlNUIsS0FBZixFQUFzQkksY0FBdEIsRUFBc0NtQyxPQUF0QyxFQUErQyxLQUFLUCxhQUFwRCxDQUFQO0FBQ0gsR0EzQ2tCOztBQTZDbkJ6QixZQUFVdkYsUUFBVixFQUFvQjtBQUNoQlYsa0JBQWNtRyxNQUFkLENBQXFCLEVBQXJCO0FBQ0FuRyxrQkFBY3dILE1BQWQsQ0FBcUI7QUFDakI5RyxnQkFBVUE7QUFETyxLQUFyQjtBQUdILEdBbERrQjs7QUFvRG5CeUYsU0FBT3pGLFFBQVAsRUFBaUI7QUFDYixVQUFNZ0YsUUFBUTtBQUNWakYsV0FBS0M7QUFESyxLQUFkO0FBSUEsVUFBTXlILGVBQWU5SCxRQUFROEYsTUFBUixDQUFlVCxLQUFmLEVBQXNCLEtBQUtnQyxhQUEzQixDQUFyQjtBQUVBL0gsU0FBS0UsT0FBTCxDQUFhOEYsT0FBYixDQUFxQjhCLGtCQUFyQjtBQUVBLFdBQU9VLFlBQVA7QUFDSDs7QUE5RGtCLENBQXZCLEM7Ozs7Ozs7Ozs7O0FDSkEzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEUiLCJmaWxlIjoiL3BhY2thZ2VzL29oaWZfc2VydmVycy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi9iYXNlLmpzJztcbmltcG9ydCAnLi9jb2xsZWN0aW9ucyc7XG5pbXBvcnQgJy4vbGliJztcbiIsImltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcblxuT0hJRi5zZXJ2ZXJzID0ge1xuICAgIGNvbGxlY3Rpb25zOiB7fVxufTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcblxuLy8gQ3VycmVudFNlcnZlciBpcyBhIHNpbmdsZSBkb2N1bWVudCBjb2xsZWN0aW9uIHRvIGRlc2NyaWJlIHdoaWNoIG9mIHRoZSBTZXJ2ZXJzIGlzIGJlaW5nIHVzZWRcbmNvbnN0IEN1cnJlbnRTZXJ2ZXIgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY3VycmVudFNlcnZlcicpO1xuQ3VycmVudFNlcnZlci5fZGVidWdOYW1lID0gJ0N1cnJlbnRTZXJ2ZXInO1xuT0hJRi5zZXJ2ZXJzLmNvbGxlY3Rpb25zLmN1cnJlbnRTZXJ2ZXIgPSBDdXJyZW50U2VydmVyO1xuXG5leHBvcnQgeyBDdXJyZW50U2VydmVyIH07XG4iLCJpbXBvcnQgeyBDdXJyZW50U2VydmVyIH0gZnJvbSAnLi9jdXJyZW50U2VydmVyLmpzJztcbmltcG9ydCB7IFNlcnZlcnMgfSBmcm9tICcuL3NlcnZlcnMuanMnO1xuXG5leHBvcnQgeyBDdXJyZW50U2VydmVyLCBTZXJ2ZXJzIH07XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG4vLyBpbXBvcnQgeyBTZXJ2ZXJzIGFzIFNlcnZlclNjaGVtYSB9IGZyb20gJ21ldGVvci9vaGlmOnNlcnZlcnMvYm90aC9zY2hlbWEvc2VydmVycy5qcyc7XG5cbi8vIFNlcnZlcnMgZGVzY3JpYmUgdGhlIERJQ09NIHNlcnZlcnMgY29uZmlndXJhdGlvbnNcbmNvbnN0IFNlcnZlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc2VydmVycycpO1xuLy8gVE9ETzogTWFrZSB0aGUgU2NoZW1hIG1hdGNoIHdoYXQgd2UgYXJlIGN1cnJlbnRseSBzdGlja2luZyBpbnRvIHRoZSBDb2xsZWN0aW9uXG4vL1NlcnZlcnMuYXR0YWNoU2NoZW1hKFNlcnZlclNjaGVtYSk7XG5TZXJ2ZXJzLl9kZWJ1Z05hbWUgPSAnU2VydmVycyc7XG5PSElGLnNlcnZlcnMuY29sbGVjdGlvbnMuc2VydmVycyA9IFNlcnZlcnM7XG5cbmV4cG9ydCB7IFNlcnZlcnMgfTtcbiIsImltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcbmltcG9ydCB7IFNlcnZlcnMsIEN1cnJlbnRTZXJ2ZXIgfSBmcm9tICdtZXRlb3Ivb2hpZjpzZXJ2ZXJzL2JvdGgvY29sbGVjdGlvbnMnO1xuXG4vKipcbiAqIFJldHJpZXZlcyB0aGUgY3VycmVudCBzZXJ2ZXIgY29uZmlndXJhdGlvbiB1c2VkIHRvIHJldHJpZXZlIHN0dWRpZXNcbiAqL1xuT0hJRi5zZXJ2ZXJzLmdldEN1cnJlbnRTZXJ2ZXIgPSAoKSA9PiB7XG4gICAgY29uc3QgY3VycmVudFNlcnZlciA9IEN1cnJlbnRTZXJ2ZXIuZmluZE9uZSgpO1xuXG4gICAgaWYgKCFjdXJyZW50U2VydmVyKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBzZXJ2ZXJDb25maWd1cmF0aW9uID0gU2VydmVycy5maW5kT25lKHsgX2lkOiBjdXJyZW50U2VydmVyLnNlcnZlcklkIH0pO1xuXG4gICAgcmV0dXJuIHNlcnZlckNvbmZpZ3VyYXRpb247XG59O1xuIiwiaW1wb3J0ICcuL2dldEN1cnJlbnRTZXJ2ZXIuanMnO1xuIiwiaW1wb3J0IHsgU2ltcGxlU2NoZW1hIH0gZnJvbSAnbWV0ZW9yL2FsZGVlZDpzaW1wbGUtc2NoZW1hJztcblxuY29uc3Qgc2VydmVyTmFtZURlZmluaXRpb25zID0ge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1NlcnZlciBOYW1lJyxcbiAgICBtYXg6IDEwMFxufTtcblxuY29uc3Qgc2VydmVyVHlwZURlZmluaXRpb25zID0ge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1NlcnZlciBUeXBlJyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ2RpY29tV2ViJywgJ2RpbXNlJ10sXG4gICAgdmFsdWVzTGFiZWxzOiBbJ0RJQ09NIFdlYicsICdESU1TRSddLFxuICAgIG9wdGlvbmFsOiB0cnVlXG59O1xuXG5jb25zdCB3YWRvVXJpUm9vdERlZmluaXRpb25zID0ge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1dBRE8gVVJJIHJvb3QnLFxuICAgIG1heDogMTAwMFxufTtcblxuY29uc3QgYXZhaWxhYmxlTW91c2VCdXR0b25Ub29scyA9IFsnd3d3YycsICd6b29tJywgJ3BhbicsICdzdGFja1Njcm9sbCddO1xuXG5leHBvcnQgY29uc3QgRElDT01XZWJSZXF1ZXN0T3B0aW9ucyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIGF1dGg6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBsYWJlbDogJ0F1dGhlbnRpY2F0aW9uJyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiAnb3J0aGFuYzpvcnRoYW5jJyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGxvZ1JlcXVlc3RzOiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICAgICAgbGFiZWw6ICdSZXF1ZXN0cydcbiAgICB9LFxuICAgIGxvZ1Jlc3BvbnNlczoge1xuICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlLFxuICAgICAgICBsYWJlbDogJ1Jlc3BvbnNlcydcbiAgICB9LFxuICAgIGxvZ1RpbWluZzoge1xuICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IHRydWUsXG4gICAgICAgIGxhYmVsOiAnVGltaW5nJ1xuICAgIH1cbn0pO1xuXG5leHBvcnQgY29uc3QgRElDT01XZWJTZXJ2ZXIgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBuYW1lOiBzZXJ2ZXJOYW1lRGVmaW5pdGlvbnMsXG4gICAgdHlwZTogc2VydmVyVHlwZURlZmluaXRpb25zLFxuICAgIHdhZG9VcmlSb290OiB3YWRvVXJpUm9vdERlZmluaXRpb25zLFxuICAgIHdhZG9Sb290OiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgbGFiZWw6ICdXQURPIHJvb3QnLFxuICAgICAgICBtYXg6IDEwMDBcbiAgICB9LFxuICAgIGltYWdlUmVuZGVyaW5nOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgbGFiZWw6ICdJbWFnZSByZW5kZXJpbmcnLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ3dhZG91cmknLCAnb3J0aGFuYyddLFxuICAgICAgICB2YWx1ZXNMYWJlbHM6IFsnV0FETyBVUkknLCAnT1JUSEFOQyddXG4gICAgfSxcbiAgICBxaWRvUm9vdDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGxhYmVsOiAnUUlETyByb290JyxcbiAgICAgICAgbWF4OiAxMDAwXG4gICAgfSxcbiAgICBxaWRvU3VwcG9ydHNJbmNsdWRlRmllbGQ6IHtcbiAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgbGFiZWw6ICdRSURPIHN1cHBvcnRzIGluY2x1ZGluZyBmaWVsZHMnLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlXG4gICAgfSxcbiAgICByZXF1ZXN0T3B0aW9uczoge1xuICAgICAgICB0eXBlOiBESUNPTVdlYlJlcXVlc3RPcHRpb25zLFxuICAgICAgICBsYWJlbDogJ1JlcXVlc3QgT3B0aW9ucydcbiAgICB9XG59KTtcblxuZXhwb3J0IGNvbnN0IERJTVNFUGVlciA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIGFlVGl0bGU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBsYWJlbDogJ0FFIFRpdGxlJ1xuICAgIH0sXG4gICAgaG9zdEFFOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgbGFiZWw6ICdBRSBIb3N0JyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGhvc3Q6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBsYWJlbDogJ0hvc3QgRG9tYWluL0lQJyxcbiAgICAgICAgcmVnRXg6IFNpbXBsZVNjaGVtYS5SZWdFeC5XZWFrRG9tYWluXG4gICAgfSxcbiAgICBwb3J0OiB7XG4gICAgICAgIHR5cGU6IE51bWJlcixcbiAgICAgICAgbGFiZWw6ICdQb3J0JyxcbiAgICAgICAgbWluOiAxLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IDExMTEyLFxuICAgICAgICBtYXg6IDY1NTM1XG4gICAgfSxcbiAgICBkZWZhdWx0OiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGxhYmVsOiAnRGVmYXVsdCcsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogZmFsc2VcbiAgICB9LFxuICAgIHNlcnZlcjoge1xuICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICBsYWJlbDogJ1NlcnZlcicsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogZmFsc2VcbiAgICB9LFxuICAgIHN1cHBvcnRzSW5zdGFuY2VSZXRyaWV2YWxCeVN0dWR5VWlkOiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGxhYmVsOiAnU3VwcG9ydHMgaW5zdGFuY2UgcmV0cmlldmFsIGJ5IFN0dWR5VWlkJyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiB0cnVlXG4gICAgfVxufSk7XG5cbmV4cG9ydCBjb25zdCBESU1TRVNlcnZlciA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIG5hbWU6IHNlcnZlck5hbWVEZWZpbml0aW9ucyxcbiAgICB0eXBlOiBzZXJ2ZXJUeXBlRGVmaW5pdGlvbnMsXG4gICAgd2Fkb1VyaVJvb3Q6IHdhZG9VcmlSb290RGVmaW5pdGlvbnMsXG4gICAgcmVxdWVzdE9wdGlvbnM6IHtcbiAgICAgICAgdHlwZTogRElDT01XZWJSZXF1ZXN0T3B0aW9ucyxcbiAgICAgICAgbGFiZWw6ICdSZXF1ZXN0IE9wdGlvbnMnXG4gICAgfSxcbiAgICBwZWVyczoge1xuICAgICAgICB0eXBlOiBbRElNU0VQZWVyXSxcbiAgICAgICAgbGFiZWw6ICdQZWVyIExpc3QnLFxuICAgICAgICBtaW5Db3VudDogMVxuICAgIH1cbn0pO1xuXG5leHBvcnQgY29uc3QgVUlTZXR0aW5ncyA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIHN0dWR5TGlzdEZ1bmN0aW9uc0VuYWJsZWQ6IHtcbiAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgbGFiZWw6ICdTdHVkeSBMaXN0IEZ1bmN0aW9ucyBFbmFibGVkPycsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZVxuICAgIH0sXG4gICAgbGVmdFNpZGViYXJPcGVuOiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGxhYmVsOiAnTGVmdCBzaWRlYmFyIG9wZW4gYnkgZGVmYXVsdD8nLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlXG4gICAgfSxcbiAgICBsZWZ0U2lkZWJhckRyYWdBbmREcm9wOiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGxhYmVsOiAnTGVmdCBzaWRlYmFyIGFsbG93cyB0aHVtYm5haWwgZHJhZyBhbmQgZHJvcC4gSWYgZmFsc2UsIGltYWdlcyB3aWxsIGJlIGxvYWRlZCBvbiBzaW5nbGUgY2xpY2suJyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiB0cnVlXG4gICAgfSxcbiAgICBkaXNwbGF5U2V0TmF2aWdhdGlvbkxvb3BPdmVyU2VyaWVzOiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGxhYmVsOiAnVGhlIFVQL0RPV04gZGlzcGxheSBzZXQgbmF2aWdhdGlvbiBidXR0b25zIHdpbGwgc3RhcnQgb3ZlciB3aGVuIHJlYWNoIHRoZSBsYXN0IGRpc3BsYXkgc2V0IGluIHZpZXdwb3J0PycsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZVxuICAgIH0sXG4gICAgZGlzcGxheVNldE5hdmlnYXRpb25NdWx0aXBsZVZpZXdwb3J0czoge1xuICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICBsYWJlbDogJ1RoZSBVUC9ET1dOIGRpc3BsYXkgc2V0IG5hdmlnYXRpb24gYnV0dG9ucyB3aWxsIGl0ZXJhdGUgb3ZlciBhbGwgdGhlIHZpZXdwb3J0cyBhdCBvbmNlPycsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogZmFsc2VcbiAgICB9LFxuICAgIGRpc3BsYXlFY2hvVWx0cmFzb3VuZFdvcmtmbG93OiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGxhYmVsOiAnRW5hYmxlIGNpbmUgZGlhbG9nIGVuaGFuY2VtZW50cyBmb3IgbXVsdGlmcmFtZSBpbWFnZXMuJyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiBmYWxzZVxuICAgIH0sXG4gICAgYXV0b1Bvc2l0aW9uTWVhc3VyZW1lbnRzVGV4dENhbGxPdXRzOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgbGFiZWw6ICdBdXRvIHBvc2l0aW9uIHRleHQgY2FsbC1vdXRzIGZvciBtZWFzdXJlbWVudHMgd2hlbiBjcmVhdGluZyB0aGVtLicsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogJ1RSQkwnXG4gICAgfSxcbiAgICBzdHVkeUxpc3REYXRlRmlsdGVyTnVtRGF5czoge1xuICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgIGxhYmVsOiAnTnVtYmVyIG9mIGRheXMgdG8gYmUgdXNlZCBvbiBTdHVkeSBMaXN0IGRhdGUgZmlsdGVyJyxcbiAgICAgICAgbWluOiAxXG4gICAgfSxcbiAgICBzaG93U3RhY2tMb2FkaW5nUHJvZ3Jlc3NCYXI6IHtcbiAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgbGFiZWw6ICdTaG93IGEgcHJvZ3Jlc3MgYmFyIGNsb3Nlc3QgdG8gdGhlIHRodW1ibmFpbCBzaG93aW5nIGhvdyBtdWNoIHRoZSBzdGFjayBoYXMgbG9hZGVkJyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiB0cnVlXG4gICAgfSxcbiAgICBjb3JuZXJzdG9uZVJlbmRlcmVyOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgbGFiZWw6ICdDb3JuZXJzdG9uZSBkZWZhdWx0IGltYWdlIHJlbmRlcmVyJyxcbiAgICAgICAgZGVmYXVsdFZhbHVlOiAnd2ViZ2wnXG4gICAgfSxcbiAgICBzb3J0U2VyaWVzQnlJbmNvbWluZ09yZGVyOiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGxhYmVsOiAnRGVmaW5lIGlmIHRoZSBzZXJpZXNcXCcgaW1hZ2VzIHNoYWxsIGJlIHNvcnRlZCBieSBpbmNvbWluZyBvcmRlci4gU29ydCBieSBJbnN0YW5jZSBOdW1iZXIgYnkgZGVmYXVsdC4nLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlXG4gICAgfSxcbiAgICB1c2VNaWRkbGVTZXJpZXNJbnN0YW5jZUFzVGh1bWJuYWlsOiB7XG4gICAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICAgIGxhYmVsOiAnRGVmaW5lIGlmIHRoZSBtaWRkbGUgaW5zdGFuY2Ugb2YgYSBzZXJpZXMgd2lsbCBiZSB1c2VkIGFzIHRodW1ibmFpbC4gSWYgbm90LCB0aGUgZmlyc3QgaW5zdGFuY2Ugd2lsbCBiZSB1c2VkLicsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZVxuICAgIH1cbn0pO1xuXG5leHBvcnQgY29uc3QgUHJlZmV0Y2hTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBvcmRlcjoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGxhYmVsOiAnUHJlZmV0Y2ggT3JkZXInLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBbJ3RvcGRvd24nLCAnZG93bndhcmQnLCAnY2xvc2VzdCddLFxuICAgICAgICBvcHRpb25hbDogZmFsc2VcbiAgICB9LFxuICAgIGRpc3BsYXlTZXRDb3VudDoge1xuICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgIGxhYmVsOiAnRGlzcGxheSBTZXQgQ291bnQnLFxuICAgICAgICBtaW46IDEsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogMVxuICAgIH1cbn0pO1xuXG5leHBvcnQgY29uc3QgTW91c2VCdXR0b25Ub29sU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgbGVmdDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGxhYmVsOiAnTGVmdCBNb3VzZSBCdXR0b24nLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBhdmFpbGFibGVNb3VzZUJ1dHRvblRvb2xzLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgcmlnaHQ6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBsYWJlbDogJ1JpZ2h0IE1vdXNlIEJ1dHRvbicsXG4gICAgICAgIGFsbG93ZWRWYWx1ZXM6IGF2YWlsYWJsZU1vdXNlQnV0dG9uVG9vbHMsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBtaWRkbGU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBsYWJlbDogJ01pZGRsZSBNb3VzZSBCdXR0b24nLFxuICAgICAgICBhbGxvd2VkVmFsdWVzOiBhdmFpbGFibGVNb3VzZUJ1dHRvblRvb2xzLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH1cbn0pO1xuXG5leHBvcnQgY29uc3QgUHVibGljU2VydmVyQ29uZmlnID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgdmVyaWZ5RW1haWw6IHtcbiAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgbGFiZWw6ICdWZXJpZnkgRW1haWwnLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlXG4gICAgfSxcbiAgICBkZW1vVXNlckVuYWJsZWQ6IHtcbiAgICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgICAgbGFiZWw6ICdDcmVhdGVzIGRlbW8gdXNlciBvbiBzdGFydHVwIGFuZCBzaG93IFRlc3REcml2ZSBidXR0b24nLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IHRydWVcbiAgICB9LFxuICAgIHVpOiB7XG4gICAgICAgIHR5cGU6IFVJU2V0dGluZ3MsXG4gICAgICAgIGxhYmVsOiAnVUkgU2V0dGluZ3MnXG4gICAgfSxcbiAgICBwcmVmZXRjaDoge1xuICAgICAgICB0eXBlOiBQcmVmZXRjaFNjaGVtYSxcbiAgICAgICAgbGFiZWw6ICdQcmVmZXRjaCBzZXR0aW5ncydcbiAgICB9LFxuICAgIGRlZmF1bHRNb3VzZUJ1dHRvblRvb2xzOiB7XG4gICAgICAgIHR5cGU6IE1vdXNlQnV0dG9uVG9vbFNjaGVtYSxcbiAgICAgICAgbGFiZWw6ICdEZWZhdWx0IE1vdXNlIEJ1dHRvbiBUb29scydcbiAgICB9XG59KTtcblxuZXhwb3J0IGNvbnN0IFNlcnZlcnMgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBkaWNvbVdlYjoge1xuICAgICAgICB0eXBlOiBbRElDT01XZWJTZXJ2ZXJdLFxuICAgICAgICBsYWJlbDogJ0RJQ09NV2ViIFNlcnZlcnMnLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgZGltc2U6IHtcbiAgICAgICAgdHlwZTogW0RJTVNFU2VydmVyXSxcbiAgICAgICAgbGFiZWw6ICdESU1TRSBTZXJ2ZXJzJyxcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9XG59KTtcblxuZXhwb3J0IGNvbnN0IFNlcnZlckNvbmZpZ3VyYXRpb24gPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBzZXJ2ZXJzOiB7XG4gICAgICAgIHR5cGU6IFNlcnZlcnMsXG4gICAgICAgIGxhYmVsOiAnU2VydmVycydcbiAgICB9LFxuICAgIGRlZmF1bHRTZXJ2aWNlVHlwZToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGxhYmVsOiAnRGVmYXVsdCBTZXJ2aWNlIFR5cGUnLFxuICAgICAgICBkZWZhdWx0VmFsdWU6ICdkaWNvbVdlYidcbiAgICB9LFxuICAgIGRyb3BDb2xsZWN0aW9uczoge1xuICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICBsYWJlbDogJ0Ryb3AgZGF0YWJhc2UgY29sbGVjdGlvbnMnLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlXG4gICAgfSxcbiAgICBwdWJsaWM6IHtcbiAgICAgICAgdHlwZTogUHVibGljU2VydmVyQ29uZmlnLFxuICAgICAgICBsYWJlbDogJ1B1YmxpYyBTZXJ2ZXIgQ29uZmlndXJhdGlvbicsXG4gICAgfSxcbiAgICBvcmlnaW46IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBsYWJlbDogJ09yaWdpbicsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgJy4vcHVibGljYXRpb25zLmpzJztcbmltcG9ydCAnLi9tZXRob2RzLmpzJztcbmltcG9ydCAnLi9zdGFydHVwLmpzJztcbmltcG9ydCAnLi9saWInO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBzZXJ2ZXJGaW5kOiBxdWVyeSA9PiBPSElGLnNlcnZlcnMuY29udHJvbC5maW5kKHF1ZXJ5KSxcbiAgICBzZXJ2ZXJTYXZlOiBzZXJ2ZXJTZXR0aW5ncyA9PiBPSElGLnNlcnZlcnMuY29udHJvbC5zYXZlKHNlcnZlclNldHRpbmdzKSxcbiAgICBzZXJ2ZXJTZXRBY3RpdmU6IHNlcnZlcklkID0+IE9ISUYuc2VydmVycy5jb250cm9sLnNldEFjdGl2ZShzZXJ2ZXJJZCksXG4gICAgc2VydmVyUmVtb3ZlOiBzZXJ2ZXJJZCA9PiBPSElGLnNlcnZlcnMuY29udHJvbC5yZW1vdmUoc2VydmVySWQpXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgU2VydmVycywgQ3VycmVudFNlcnZlciB9IGZyb20gJ21ldGVvci9vaGlmOnNlcnZlcnMvYm90aC9jb2xsZWN0aW9ucyc7XG5cbi8vIFdoZW4gcHVibGlzaGluZyBTZXJ2ZXJzIENvbGxlY3Rpb24sIGRvIG5vdCBwdWJsaXNoIHRoZSByZXF1ZXN0T3B0aW9ucy5oZWFkZXJzXG4vLyBmaWVsZCBpbiBjYXNlIGFueSBhdXRoZW50aWNhdGlvbiBpbmZvcm1hdGlvbiBpcyBiZWluZyBwYXNzZWRcbk1ldGVvci5wdWJsaXNoKCdzZXJ2ZXJzJywgKCkgPT4gU2VydmVycy5maW5kKHt9LCB7XG4gICAgZmllbGRzOiB7ICdyZXF1ZXN0T3B0aW9ucy5oZWFkZXJzJzogMCB9XG59KSk7XG5cbk1ldGVvci5wdWJsaXNoKCdjdXJyZW50U2VydmVyJywgKCkgPT4gQ3VycmVudFNlcnZlci5maW5kKCkpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBfIH0gZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnO1xuaW1wb3J0IHsgT0hJRiB9IGZyb20gJ21ldGVvci9vaGlmOmNvcmUnO1xuaW1wb3J0IHsgU2VydmVycyB9IGZyb20gJ21ldGVvci9vaGlmOnNlcnZlcnMvYm90aC9jb2xsZWN0aW9ucyc7XG5pbXBvcnQgeyBTZXJ2ZXJDb25maWd1cmF0aW9uIH0gZnJvbSAnbWV0ZW9yL29oaWY6c2VydmVycy9ib3RoL3NjaGVtYS9zZXJ2ZXJzLmpzJztcblxuLy8gVmFsaWRhdGUgdGhlIHNlcnZlcnMgY29uZmlndXJhdGlvblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgIC8vIFNhdmUgY3VzdG9tIHByb3BlcnRpZXMgKGlmIGFueSkuLi5cbiAgICAvLyBcIk1ldGVvci5zZXR0aW5nc1wiIGFuZCBcIk1ldGVvci5zZXR0aW5ncy5wdWJsaWNcIiBhcmUgc2V0IGJ5IGRlZmF1bHQuLi5cbiAgICBsZXQgY3VzdG9tID0ge1xuICAgICAgICBwcml2YXRlOiBNZXRlb3Iuc2V0dGluZ3MuY3VzdG9tLFxuICAgICAgICBwdWJsaWM6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY3VzdG9tXG4gICAgfTtcblxuICAgIC8vIC4uLiBhbmQgcmVtb3ZlIHRoZW0gdG8gcHJldmVudCBjbGVhbiB1cFxuICAgIGRlbGV0ZSBNZXRlb3Iuc2V0dGluZ3MuY3VzdG9tO1xuICAgIGRlbGV0ZSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmN1c3RvbTtcblxuICAgIFNlcnZlckNvbmZpZ3VyYXRpb24uY2xlYW4oTWV0ZW9yLnNldHRpbmdzKTtcblxuICAgIC8vIFRPRE86IE1ha2UgdGhlIGVycm9yIG1lc3NhZ2VzIG1vcmUgY2xlYXJcbiAgICAvLyBUYWtpbmcgdGhpcyBvdXQgZm9yIG5vdyB0byBwcmV2ZW50IGNvbmZ1c2lvbi5cbiAgICAvLyBjaGVjayhNZXRlb3Iuc2V0dGluZ3MsIFNlcnZlckNvbmZpZ3VyYXRpb24pO1xuXG4gICAgTWV0ZW9yLnNldHRpbmdzLmN1c3RvbSA9IGN1c3RvbS5wcml2YXRlO1xuICAgIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY3VzdG9tID0gY3VzdG9tLnB1YmxpYztcblxuICAgIE9ISUYubG9nLmluZm8oSlNPTi5zdHJpbmdpZnkoTWV0ZW9yLnNldHRpbmdzLCBudWxsLCAyKSk7XG59KTtcblxuLy8gQ2hlY2sgdGhlIHNlcnZlcnMgb24gbWV0ZW9yIHN0YXJ0dXBcbk1ldGVvci5zdGFydHVwKGZ1bmN0aW9uKCkge1xuICAgIE9ISUYubG9nLmluZm8oJ1VwZGF0aW5nIHNlcnZlcnMgaW5mb3JtYXRpb24gZnJvbSBKU09OIGNvbmZpZ3VyYXRpb24nKTtcblxuICAgIF8uZWFjaChNZXRlb3Iuc2V0dGluZ3Muc2VydmVycywgZnVuY3Rpb24oZW5kcG9pbnRzLCBzZXJ2ZXJUeXBlKSB7XG4gICAgICAgIF8uZWFjaChlbmRwb2ludHMsIGZ1bmN0aW9uKGVuZHBvaW50KSB7XG4gICAgICAgICAgICBjb25zdCBzZXJ2ZXIgPSBfLmNsb25lKGVuZHBvaW50KTtcbiAgICAgICAgICAgIHNlcnZlci5vcmlnaW4gPSAnanNvbic7XG4gICAgICAgICAgICBzZXJ2ZXIudHlwZSA9IHNlcnZlclR5cGU7XG5cbiAgICAgICAgICAgIC8vIFRyeSB0byBmaW5kIGEgc2VydmVyIHdpdGggdGhlIHNhbWUgbmFtZS90eXBlL29yaWdpbiBjb21iaW5hdGlvblxuICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdTZXJ2ZXIgPSBTZXJ2ZXJzLmZpbmRPbmUoe1xuICAgICAgICAgICAgICAgIG5hbWU6IHNlcnZlci5uYW1lLFxuICAgICAgICAgICAgICAgIHR5cGU6IHNlcnZlci50eXBlLFxuICAgICAgICAgICAgICAgIG9yaWdpbjogc2VydmVyLm9yaWdpblxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIC8vIENoZWNrIGlmIHNlcnZlciB3YXMgYWxyZWFkeSBhZGRlZC4gVXBkYXRlIGl0IGlmIHNvIGFuZCBpbnNlcnQgaWYgbm90XG4gICAgICAgICAgICBpZiAoZXhpc3RpbmdTZXJ2ZXIpIHtcbiAgICAgICAgICAgICAgICBTZXJ2ZXJzLnVwZGF0ZShleGlzdGluZ1NlcnZlci5faWQsIHsgJHNldDogc2VydmVyIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBTZXJ2ZXJzLmluc2VydChzZXJ2ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcblxuICAgIE9ISUYuc2VydmVycy5jb250cm9sLnJlc2V0Q3VycmVudFNlcnZlcigpO1xufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcbmltcG9ydCB7IFNlcnZlcnMsIEN1cnJlbnRTZXJ2ZXIgfSBmcm9tICdtZXRlb3Ivb2hpZjpzZXJ2ZXJzL2JvdGgvY29sbGVjdGlvbnMnO1xuXG5PSElGLnNlcnZlcnMuY29udHJvbCA9IHtcbiAgICB3cml0ZUNhbGxiYWNrKGVycm9yLCBhZmZlY3RlZCkge1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2RhdGEtd3JpdGUnLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgcmVzZXRDdXJyZW50U2VydmVyKCkge1xuICAgICAgICBjb25zdCBjdXJyZW50U2VydmVyID0gQ3VycmVudFNlcnZlci5maW5kT25lKCk7XG4gICAgICAgIGlmIChjdXJyZW50U2VydmVyICYmIFNlcnZlcnMuZmluZCh7IF9pZDogY3VycmVudFNlcnZlci5zZXJ2ZXJJZCB9KS5jb3VudCgpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXdTZXJ2ZXIgPSBTZXJ2ZXJzLmZpbmRPbmUoe1xuICAgICAgICAgICAgb3JpZ2luOiAnanNvbicsXG4gICAgICAgICAgICB0eXBlOiBNZXRlb3Iuc2V0dGluZ3MuZGVmYXVsdFNlcnZpY2VUeXBlIHx8ICdkaWNvbVdlYidcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKG5ld1NlcnZlcikge1xuICAgICAgICAgICAgQ3VycmVudFNlcnZlci5yZW1vdmUoe30pO1xuICAgICAgICAgICAgQ3VycmVudFNlcnZlci5pbnNlcnQoe1xuICAgICAgICAgICAgICAgIHNlcnZlcklkOiBuZXdTZXJ2ZXIuX2lkXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBmaW5kKHF1ZXJ5KSB7XG4gICAgICAgIHJldHVybiBTZXJ2ZXJzLmZpbmQocXVlcnkpLmZldGNoKCk7XG4gICAgfSxcblxuICAgIHNhdmUoc2VydmVyU2V0dGluZ3MpIHtcbiAgICAgICAgY29uc3QgcXVlcnkgPSB7XG4gICAgICAgICAgICBfaWQ6IHNlcnZlclNldHRpbmdzLl9pZFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAgICAgdXBzZXJ0OiB0cnVlXG4gICAgICAgIH07XG5cbiAgICAgICAgaWYgKCFzZXJ2ZXJTZXR0aW5ncy5faWQpIHtcbiAgICAgICAgICAgIGRlbGV0ZSBzZXJ2ZXJTZXR0aW5ncy5faWQ7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gU2VydmVycy51cGRhdGUocXVlcnksIHNlcnZlclNldHRpbmdzLCBvcHRpb25zLCB0aGlzLndyaXRlQ2FsbGJhY2spO1xuICAgIH0sXG5cbiAgICBzZXRBY3RpdmUoc2VydmVySWQpIHtcbiAgICAgICAgQ3VycmVudFNlcnZlci5yZW1vdmUoe30pO1xuICAgICAgICBDdXJyZW50U2VydmVyLmluc2VydCh7XG4gICAgICAgICAgICBzZXJ2ZXJJZDogc2VydmVySWRcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIHJlbW92ZShzZXJ2ZXJJZCkge1xuICAgICAgICBjb25zdCBxdWVyeSA9IHtcbiAgICAgICAgICAgIF9pZDogc2VydmVySWRcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCByZW1vdmVTdGF0dXMgPSBTZXJ2ZXJzLnJlbW92ZShxdWVyeSwgdGhpcy53cml0ZUNhbGxiYWNrKTtcblxuICAgICAgICBPSElGLnNlcnZlcnMuY29udHJvbC5yZXNldEN1cnJlbnRTZXJ2ZXIoKTtcblxuICAgICAgICByZXR1cm4gcmVtb3ZlU3RhdHVzO1xuICAgIH1cbn07XG4iLCJpbXBvcnQgJy4vY29udHJvbC5qcyc7XG4iXX0=
