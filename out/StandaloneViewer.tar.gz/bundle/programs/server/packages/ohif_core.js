(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

var require = meteorInstall({"node_modules":{"meteor":{"ohif:core":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/main.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  OHIF: () => OHIF
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

/*
 * Defines the base OHIF object
 */
const OHIF = {
  log: {},
  ui: {},
  utils: {},
  viewer: {},
  cornerstone: {}
}; // Expose the OHIF object to the client if it is on development mode
// @TODO: remove this after applying namespace to this package

if (Meteor.isClient) {
  window.OHIF = OHIF;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server":{"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/server/index.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("./mongo.js"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/server/mongo.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

// Mongo data manipulation utilities
class MongoUtils {
  // Check if there is an user logged in
  static validateUser() {
    // Throw error if there is no user logged in
    if (!Meteor.userId()) {
      throw new Meteor.Error('not-authorized');
    }
  } // Generic callback to MongoDB write operations


  static writeCallback(error, affected) {
    // Throw error if it was not possible to complete the write operation
    if (error) {
      throw new Meteor.Error('data-write', error);
    }
  }

} // Expose the class in the OHIF object


OHIF.MongoUtils = MongoUtils;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"both":{"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/both/index.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("./lib"));
module.watch(require("./utils"));
module.watch(require("./schema.js"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"schema.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/both/schema.js                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let SimpleSchema;
module.watch(require("meteor/aldeed:simple-schema"), {
  SimpleSchema(v) {
    SimpleSchema = v;
  }

}, 0);

/*
 Extend the available options on schema definitions:

  * valuesLabels: Used in conjunction with allowedValues to define the text
    label for each value (used on forms)

  * textOptional: Used to allow empty strings

 */
SimpleSchema.extendOptions({
  valuesLabels: Match.Optional([String]),
  textOptional: Match.Optional(Boolean)
}); // Add default required validation for empty strings which can be bypassed
// using textOptional=true definition

SimpleSchema.addValidator(function () {
  if (this.definition.optional !== true && this.definition.textOptional !== true && this.value === '') {
    return 'required';
  }
}); // Including [label] for some messages

SimpleSchema.messages({
  maxCount: '[label] can not have more than [maxCount] values',
  minCount: '[label] must have at least [minCount] values',
  notAllowed: '[label] has an invalid value: "[value]"'
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/both/lib/index.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("./object.js"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"object.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/both/lib/object.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);
OHIF.object = {}; // Transforms a shallow object with keys separated by "." into a nested object

OHIF.object.getNestedObject = shallowObject => {
  const nestedObject = {};

  for (let key in shallowObject) {
    if (!shallowObject.hasOwnProperty(key)) continue;
    const value = shallowObject[key];
    const propertyArray = key.split('.');
    let currentObject = nestedObject;

    while (propertyArray.length) {
      const currentProperty = propertyArray.shift();

      if (!propertyArray.length) {
        currentObject[currentProperty] = value;
      } else {
        if (!currentObject[currentProperty]) {
          currentObject[currentProperty] = {};
        }

        currentObject = currentObject[currentProperty];
      }
    }
  }

  return nestedObject;
}; // Transforms a nested object into a shallowObject merging its keys with "." character


OHIF.object.getShallowObject = nestedObject => {
  const shallowObject = {};

  const putValues = (baseKey, nestedObject, resultObject) => {
    for (let key in nestedObject) {
      if (!nestedObject.hasOwnProperty(key)) continue;
      let currentKey = baseKey ? `${baseKey}.${key}` : key;
      const currentValue = nestedObject[key];

      if (typeof currentValue === 'object') {
        if (currentValue instanceof Array) {
          currentKey += '[]';
        }

        putValues(currentKey, currentValue, resultObject);
      } else {
        resultObject[currentKey] = currentValue;
      }
    }
  };

  putValues('', nestedObject, shallowObject);
  return shallowObject;
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"absoluteUrl.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/both/utils/absoluteUrl.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);

// Return an absolute URL with the page domain using sub path of ROOT_URL
// to let multiple domains directed to the same server work
OHIF.utils.absoluteUrl = function (path) {
  let absolutePath = '/';
  const absoluteUrl = Meteor.absoluteUrl();
  const absoluteUrlParts = absoluteUrl.split('/');

  if (absoluteUrlParts.length > 4) {
    const rootUrlPrefixIndex = absoluteUrl.indexOf(absoluteUrlParts[3]);
    absolutePath += absoluteUrl.substring(rootUrlPrefixIndex) + path;
  } else {
    absolutePath += path;
  }

  return absolutePath.replace(/\/\/+/g, '/');
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/both/utils/index.js                                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("./absoluteUrl"));
module.watch(require("./objectPath"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"objectPath.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ohif_core/both/utils/objectPath.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let OHIF;
module.watch(require("meteor/ohif:core"), {
  OHIF(v) {
    OHIF = v;
  }

}, 0);

class ObjectPath {
  /**
   * Set an object property based on "path" (namespace) supplied creating
   * ... intermediary objects if they do not exist.
   * @param object {Object} An object where the properties specified on path should be set.
   * @param path {String} A string representing the property to be set, e.g. "user.study.series.timepoint".
   * @param value {Any} The value of the property that will be set.
   * @return {Boolean} Returns "true" on success, "false" if any intermediate component of the supplied path
   * ... is not a valid Object, in which case the property cannot be set. No excpetions are thrown.
   */
  static set(object, path, value) {
    let components = ObjectPath.getPathComponents(path),
        length = components !== null ? components.length : 0,
        result = false;

    if (length > 0 && ObjectPath.isValidObject(object)) {
      let i = 0,
          last = length - 1,
          currentObject = object;

      while (i < last) {
        let field = components[i];

        if (field in currentObject) {
          if (!ObjectPath.isValidObject(currentObject[field])) {
            break;
          }
        } else {
          currentObject[field] = {};
        }

        currentObject = currentObject[field];
        i++;
      }

      if (i === last) {
        currentObject[components[last]] = value;
        result = true;
      }
    }

    return result;
  }
  /**
   * Get an object property based on "path" (namespace) supplied traversing the object
   * ... tree as necessary.
   * @param object {Object} An object where the properties specified might exist.
   * @param path {String} A string representing the property to be searched for, e.g. "user.study.series.timepoint".
   * @return {Any} The value of the property if found. By default, returns the special type "undefined".
   */


  static get(object, path) {
    let found,
        // undefined by default
    components = ObjectPath.getPathComponents(path),
        length = components !== null ? components.length : 0;

    if (length > 0 && ObjectPath.isValidObject(object)) {
      let i = 0,
          last = length - 1,
          currentObject = object;

      while (i < last) {
        let field = components[i];
        const isValid = ObjectPath.isValidObject(currentObject[field]);

        if (field in currentObject && isValid) {
          currentObject = currentObject[field];
          i++;
        } else {
          break;
        }
      }

      if (i === last && components[last] in currentObject) {
        found = currentObject[components[last]];
      }
    }

    return found;
  }
  /**
   * Check if the supplied argument is a real JavaScript Object instance.
   * @param object {Any} The subject to be tested.
   * @return {Boolean} Returns "true" if the object is a real Object instance and "false" otherwise.
   */


  static isValidObject(object) {
    return typeof object === 'object' && object !== null && object instanceof Object;
  }

  static getPathComponents(path) {
    return typeof path === 'string' ? path.split('.') : null;
  }

}

OHIF.utils.ObjectPath = ObjectPath;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/ohif:core/main.js");
require("/node_modules/meteor/ohif:core/server/index.js");
require("/node_modules/meteor/ohif:core/both/index.js");

/* Exports */
Package._define("ohif:core", exports);

})();

//# sourceURL=meteor://💻app/packages/ohif_core.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpjb3JlL21haW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6Y29yZS9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6Y29yZS9zZXJ2ZXIvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6Y29yZS9ib3RoL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOmNvcmUvYm90aC9zY2hlbWEuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6Y29yZS9ib3RoL2xpYi9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpjb3JlL2JvdGgvbGliL29iamVjdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2hpZjpjb3JlL2JvdGgvdXRpbHMvYWJzb2x1dGVVcmwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29oaWY6Y29yZS9ib3RoL3V0aWxzL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vaGlmOmNvcmUvYm90aC91dGlscy9vYmplY3RQYXRoLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIk9ISUYiLCJNZXRlb3IiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwibG9nIiwidWkiLCJ1dGlscyIsInZpZXdlciIsImNvcm5lcnN0b25lIiwiaXNDbGllbnQiLCJ3aW5kb3ciLCJNb25nb1V0aWxzIiwidmFsaWRhdGVVc2VyIiwidXNlcklkIiwiRXJyb3IiLCJ3cml0ZUNhbGxiYWNrIiwiZXJyb3IiLCJhZmZlY3RlZCIsIlNpbXBsZVNjaGVtYSIsImV4dGVuZE9wdGlvbnMiLCJ2YWx1ZXNMYWJlbHMiLCJNYXRjaCIsIk9wdGlvbmFsIiwiU3RyaW5nIiwidGV4dE9wdGlvbmFsIiwiQm9vbGVhbiIsImFkZFZhbGlkYXRvciIsImRlZmluaXRpb24iLCJvcHRpb25hbCIsInZhbHVlIiwibWVzc2FnZXMiLCJtYXhDb3VudCIsIm1pbkNvdW50Iiwibm90QWxsb3dlZCIsIm9iamVjdCIsImdldE5lc3RlZE9iamVjdCIsInNoYWxsb3dPYmplY3QiLCJuZXN0ZWRPYmplY3QiLCJrZXkiLCJoYXNPd25Qcm9wZXJ0eSIsInByb3BlcnR5QXJyYXkiLCJzcGxpdCIsImN1cnJlbnRPYmplY3QiLCJsZW5ndGgiLCJjdXJyZW50UHJvcGVydHkiLCJzaGlmdCIsImdldFNoYWxsb3dPYmplY3QiLCJwdXRWYWx1ZXMiLCJiYXNlS2V5IiwicmVzdWx0T2JqZWN0IiwiY3VycmVudEtleSIsImN1cnJlbnRWYWx1ZSIsIkFycmF5IiwiYWJzb2x1dGVVcmwiLCJwYXRoIiwiYWJzb2x1dGVQYXRoIiwiYWJzb2x1dGVVcmxQYXJ0cyIsInJvb3RVcmxQcmVmaXhJbmRleCIsImluZGV4T2YiLCJzdWJzdHJpbmciLCJyZXBsYWNlIiwiT2JqZWN0UGF0aCIsInNldCIsImNvbXBvbmVudHMiLCJnZXRQYXRoQ29tcG9uZW50cyIsInJlc3VsdCIsImlzVmFsaWRPYmplY3QiLCJpIiwibGFzdCIsImZpZWxkIiwiZ2V0IiwiZm91bmQiLCJpc1ZhbGlkIiwiT2JqZWN0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLFFBQUssTUFBSUE7QUFBVixDQUFkO0FBQStCLElBQUlDLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFFMUM7OztBQUlBLE1BQU1KLE9BQU87QUFDVEssT0FBSyxFQURJO0FBRVRDLE1BQUksRUFGSztBQUdUQyxTQUFPLEVBSEU7QUFJVEMsVUFBUSxFQUpDO0FBS1RDLGVBQWE7QUFMSixDQUFiLEMsQ0FRQTtBQUNBOztBQUNBLElBQUlSLE9BQU9TLFFBQVgsRUFBcUI7QUFDakJDLFNBQU9YLElBQVAsR0FBY0EsSUFBZDtBQUNILEM7Ozs7Ozs7Ozs7O0FDbEJERixPQUFPSSxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSUgsSUFBSjtBQUFTRixPQUFPSSxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDSCxPQUFLSSxDQUFMLEVBQU87QUFBQ0osV0FBS0ksQ0FBTDtBQUFPOztBQUFoQixDQUF6QyxFQUEyRCxDQUEzRDtBQUE4RCxJQUFJSCxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBR2xGO0FBQ0EsTUFBTVEsVUFBTixDQUFpQjtBQUViO0FBQ0EsU0FBT0MsWUFBUCxHQUFzQjtBQUNsQjtBQUNBLFFBQUksQ0FBQ1osT0FBT2EsTUFBUCxFQUFMLEVBQXNCO0FBQ2xCLFlBQU0sSUFBSWIsT0FBT2MsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIO0FBQ0osR0FSWSxDQVViOzs7QUFDQSxTQUFPQyxhQUFQLENBQXFCQyxLQUFyQixFQUE0QkMsUUFBNUIsRUFBc0M7QUFDbEM7QUFDQSxRQUFJRCxLQUFKLEVBQVc7QUFDUCxZQUFNLElBQUloQixPQUFPYyxLQUFYLENBQWlCLFlBQWpCLEVBQStCRSxLQUEvQixDQUFOO0FBQ0g7QUFDSjs7QUFoQlksQyxDQW9CakI7OztBQUNBakIsS0FBS1ksVUFBTCxHQUFrQkEsVUFBbEIsQzs7Ozs7Ozs7Ozs7QUN6QkFkLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxPQUFSLENBQWI7QUFBK0JMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWI7QUFBaUNMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBaEUsSUFBSWdCLFlBQUo7QUFBaUJyQixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDZ0IsZUFBYWYsQ0FBYixFQUFlO0FBQUNlLG1CQUFhZixDQUFiO0FBQWU7O0FBQWhDLENBQXBELEVBQXNGLENBQXRGOztBQUVqQjs7Ozs7Ozs7O0FBU0FlLGFBQWFDLGFBQWIsQ0FBMkI7QUFDdkJDLGdCQUFjQyxNQUFNQyxRQUFOLENBQWUsQ0FBQ0MsTUFBRCxDQUFmLENBRFM7QUFFdkJDLGdCQUFjSCxNQUFNQyxRQUFOLENBQWVHLE9BQWY7QUFGUyxDQUEzQixFLENBS0E7QUFDQTs7QUFDQVAsYUFBYVEsWUFBYixDQUEwQixZQUFXO0FBQ2pDLE1BQ0ksS0FBS0MsVUFBTCxDQUFnQkMsUUFBaEIsS0FBNkIsSUFBN0IsSUFDQSxLQUFLRCxVQUFMLENBQWdCSCxZQUFoQixLQUFpQyxJQURqQyxJQUVBLEtBQUtLLEtBQUwsS0FBZSxFQUhuQixFQUlFO0FBQ0UsV0FBTyxVQUFQO0FBQ0g7QUFDSixDQVJELEUsQ0FVQTs7QUFDQVgsYUFBYVksUUFBYixDQUFzQjtBQUNsQkMsWUFBVSxrREFEUTtBQUVsQkMsWUFBVSw4Q0FGUTtBQUdsQkMsY0FBWTtBQUhNLENBQXRCLEU7Ozs7Ozs7Ozs7O0FDN0JBcEMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlILElBQUo7QUFBU0YsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ0gsT0FBS0ksQ0FBTCxFQUFPO0FBQUNKLFdBQUtJLENBQUw7QUFBTzs7QUFBaEIsQ0FBekMsRUFBMkQsQ0FBM0Q7QUFFVEosS0FBS21DLE1BQUwsR0FBYyxFQUFkLEMsQ0FFQTs7QUFDQW5DLEtBQUttQyxNQUFMLENBQVlDLGVBQVosR0FBOEJDLGlCQUFpQjtBQUMzQyxRQUFNQyxlQUFlLEVBQXJCOztBQUNBLE9BQUssSUFBSUMsR0FBVCxJQUFnQkYsYUFBaEIsRUFBK0I7QUFDM0IsUUFBSSxDQUFDQSxjQUFjRyxjQUFkLENBQTZCRCxHQUE3QixDQUFMLEVBQXdDO0FBQ3hDLFVBQU1ULFFBQVFPLGNBQWNFLEdBQWQsQ0FBZDtBQUNBLFVBQU1FLGdCQUFnQkYsSUFBSUcsS0FBSixDQUFVLEdBQVYsQ0FBdEI7QUFDQSxRQUFJQyxnQkFBZ0JMLFlBQXBCOztBQUNBLFdBQU9HLGNBQWNHLE1BQXJCLEVBQTZCO0FBQ3pCLFlBQU1DLGtCQUFrQkosY0FBY0ssS0FBZCxFQUF4Qjs7QUFDQSxVQUFJLENBQUNMLGNBQWNHLE1BQW5CLEVBQTJCO0FBQ3ZCRCxzQkFBY0UsZUFBZCxJQUFpQ2YsS0FBakM7QUFDSCxPQUZELE1BRU87QUFDSCxZQUFJLENBQUNhLGNBQWNFLGVBQWQsQ0FBTCxFQUFxQztBQUNqQ0Ysd0JBQWNFLGVBQWQsSUFBaUMsRUFBakM7QUFDSDs7QUFFREYsd0JBQWdCQSxjQUFjRSxlQUFkLENBQWhCO0FBQ0g7QUFDSjtBQUNKOztBQUVELFNBQU9QLFlBQVA7QUFDSCxDQXRCRCxDLENBd0JBOzs7QUFDQXRDLEtBQUttQyxNQUFMLENBQVlZLGdCQUFaLEdBQStCVCxnQkFBZ0I7QUFDM0MsUUFBTUQsZ0JBQWdCLEVBQXRCOztBQUNBLFFBQU1XLFlBQVksQ0FBQ0MsT0FBRCxFQUFVWCxZQUFWLEVBQXdCWSxZQUF4QixLQUF5QztBQUN2RCxTQUFLLElBQUlYLEdBQVQsSUFBZ0JELFlBQWhCLEVBQThCO0FBQzFCLFVBQUksQ0FBQ0EsYUFBYUUsY0FBYixDQUE0QkQsR0FBNUIsQ0FBTCxFQUF1QztBQUN2QyxVQUFJWSxhQUFhRixVQUFXLEdBQUVBLE9BQVEsSUFBR1YsR0FBSSxFQUE1QixHQUFnQ0EsR0FBakQ7QUFDQSxZQUFNYSxlQUFlZCxhQUFhQyxHQUFiLENBQXJCOztBQUNBLFVBQUksT0FBT2EsWUFBUCxLQUF3QixRQUE1QixFQUFzQztBQUNsQyxZQUFJQSx3QkFBd0JDLEtBQTVCLEVBQW1DO0FBQy9CRix3QkFBYyxJQUFkO0FBQ0g7O0FBRURILGtCQUFVRyxVQUFWLEVBQXNCQyxZQUF0QixFQUFvQ0YsWUFBcEM7QUFDSCxPQU5ELE1BTU87QUFDSEEscUJBQWFDLFVBQWIsSUFBMkJDLFlBQTNCO0FBQ0g7QUFDSjtBQUNKLEdBZkQ7O0FBaUJBSixZQUFVLEVBQVYsRUFBY1YsWUFBZCxFQUE0QkQsYUFBNUI7QUFDQSxTQUFPQSxhQUFQO0FBQ0gsQ0FyQkQsQzs7Ozs7Ozs7Ozs7QUM5QkEsSUFBSXJDLElBQUo7QUFBU0YsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ0gsT0FBS0ksQ0FBTCxFQUFPO0FBQUNKLFdBQUtJLENBQUw7QUFBTzs7QUFBaEIsQ0FBekMsRUFBMkQsQ0FBM0Q7O0FBRVQ7QUFDQTtBQUNBSixLQUFLTyxLQUFMLENBQVcrQyxXQUFYLEdBQXlCLFVBQVNDLElBQVQsRUFBZTtBQUNwQyxNQUFJQyxlQUFlLEdBQW5CO0FBRUEsUUFBTUYsY0FBY3JELE9BQU9xRCxXQUFQLEVBQXBCO0FBQ0EsUUFBTUcsbUJBQW1CSCxZQUFZWixLQUFaLENBQWtCLEdBQWxCLENBQXpCOztBQUVBLE1BQUllLGlCQUFpQmIsTUFBakIsR0FBMEIsQ0FBOUIsRUFBaUM7QUFDN0IsVUFBTWMscUJBQXFCSixZQUFZSyxPQUFaLENBQW9CRixpQkFBaUIsQ0FBakIsQ0FBcEIsQ0FBM0I7QUFDQUQsb0JBQWdCRixZQUFZTSxTQUFaLENBQXNCRixrQkFBdEIsSUFBNENILElBQTVEO0FBQ0gsR0FIRCxNQUdPO0FBQ0hDLG9CQUFnQkQsSUFBaEI7QUFDSDs7QUFFRCxTQUFPQyxhQUFhSyxPQUFiLENBQXFCLFFBQXJCLEVBQStCLEdBQS9CLENBQVA7QUFDSCxDQWRELEM7Ozs7Ozs7Ozs7O0FDSkEvRCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiO0FBQXVDTCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQXZDLElBQUlILElBQUo7QUFBU0YsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ0gsT0FBS0ksQ0FBTCxFQUFPO0FBQUNKLFdBQUtJLENBQUw7QUFBTzs7QUFBaEIsQ0FBekMsRUFBMkQsQ0FBM0Q7O0FBRVQsTUFBTTBELFVBQU4sQ0FBaUI7QUFFYjs7Ozs7Ozs7O0FBU0EsU0FBT0MsR0FBUCxDQUFXNUIsTUFBWCxFQUFtQm9CLElBQW5CLEVBQXlCekIsS0FBekIsRUFBZ0M7QUFFNUIsUUFBSWtDLGFBQWFGLFdBQVdHLGlCQUFYLENBQTZCVixJQUE3QixDQUFqQjtBQUFBLFFBQ0lYLFNBQVNvQixlQUFlLElBQWYsR0FBc0JBLFdBQVdwQixNQUFqQyxHQUEwQyxDQUR2RDtBQUFBLFFBRUlzQixTQUFTLEtBRmI7O0FBSUEsUUFBSXRCLFNBQVMsQ0FBVCxJQUFja0IsV0FBV0ssYUFBWCxDQUF5QmhDLE1BQXpCLENBQWxCLEVBQW9EO0FBRWhELFVBQUlpQyxJQUFJLENBQVI7QUFBQSxVQUNJQyxPQUFPekIsU0FBUyxDQURwQjtBQUFBLFVBRUlELGdCQUFnQlIsTUFGcEI7O0FBSUEsYUFBT2lDLElBQUlDLElBQVgsRUFBaUI7QUFFYixZQUFJQyxRQUFRTixXQUFXSSxDQUFYLENBQVo7O0FBRUEsWUFBSUUsU0FBUzNCLGFBQWIsRUFBNEI7QUFDeEIsY0FBSSxDQUFDbUIsV0FBV0ssYUFBWCxDQUF5QnhCLGNBQWMyQixLQUFkLENBQXpCLENBQUwsRUFBcUQ7QUFDakQ7QUFDSDtBQUNKLFNBSkQsTUFJTztBQUNIM0Isd0JBQWMyQixLQUFkLElBQXVCLEVBQXZCO0FBQ0g7O0FBRUQzQix3QkFBZ0JBLGNBQWMyQixLQUFkLENBQWhCO0FBQ0FGO0FBRUg7O0FBRUQsVUFBSUEsTUFBTUMsSUFBVixFQUFnQjtBQUNaMUIsc0JBQWNxQixXQUFXSyxJQUFYLENBQWQsSUFBa0N2QyxLQUFsQztBQUNBb0MsaUJBQVMsSUFBVDtBQUNIO0FBRUo7O0FBRUQsV0FBT0EsTUFBUDtBQUVIO0FBRUQ7Ozs7Ozs7OztBQU9BLFNBQU9LLEdBQVAsQ0FBV3BDLE1BQVgsRUFBbUJvQixJQUFuQixFQUF5QjtBQUVyQixRQUFJaUIsS0FBSjtBQUFBLFFBQVc7QUFDUFIsaUJBQWFGLFdBQVdHLGlCQUFYLENBQTZCVixJQUE3QixDQURqQjtBQUFBLFFBRUlYLFNBQVNvQixlQUFlLElBQWYsR0FBc0JBLFdBQVdwQixNQUFqQyxHQUEwQyxDQUZ2RDs7QUFJQSxRQUFJQSxTQUFTLENBQVQsSUFBY2tCLFdBQVdLLGFBQVgsQ0FBeUJoQyxNQUF6QixDQUFsQixFQUFvRDtBQUVoRCxVQUFJaUMsSUFBSSxDQUFSO0FBQUEsVUFDSUMsT0FBT3pCLFNBQVMsQ0FEcEI7QUFBQSxVQUVJRCxnQkFBZ0JSLE1BRnBCOztBQUlBLGFBQU9pQyxJQUFJQyxJQUFYLEVBQWlCO0FBRWIsWUFBSUMsUUFBUU4sV0FBV0ksQ0FBWCxDQUFaO0FBRUEsY0FBTUssVUFBVVgsV0FBV0ssYUFBWCxDQUF5QnhCLGNBQWMyQixLQUFkLENBQXpCLENBQWhCOztBQUNBLFlBQUlBLFNBQVMzQixhQUFULElBQTBCOEIsT0FBOUIsRUFBdUM7QUFDbkM5QiwwQkFBZ0JBLGNBQWMyQixLQUFkLENBQWhCO0FBQ0FGO0FBQ0gsU0FIRCxNQUdPO0FBQ0g7QUFDSDtBQUVKOztBQUVELFVBQUlBLE1BQU1DLElBQU4sSUFBY0wsV0FBV0ssSUFBWCxLQUFvQjFCLGFBQXRDLEVBQXFEO0FBQ2pENkIsZ0JBQVE3QixjQUFjcUIsV0FBV0ssSUFBWCxDQUFkLENBQVI7QUFDSDtBQUVKOztBQUVELFdBQU9HLEtBQVA7QUFFSDtBQUVEOzs7Ozs7O0FBS0EsU0FBT0wsYUFBUCxDQUFxQmhDLE1BQXJCLEVBQTZCO0FBQ3pCLFdBQ0ksT0FBT0EsTUFBUCxLQUFrQixRQUFsQixJQUNBQSxXQUFXLElBRFgsSUFFQUEsa0JBQWtCdUMsTUFIdEI7QUFLSDs7QUFFRCxTQUFPVCxpQkFBUCxDQUF5QlYsSUFBekIsRUFBK0I7QUFDM0IsV0FBUSxPQUFPQSxJQUFQLEtBQWdCLFFBQWhCLEdBQTJCQSxLQUFLYixLQUFMLENBQVcsR0FBWCxDQUEzQixHQUE2QyxJQUFyRDtBQUNIOztBQTdHWTs7QUFpSGpCMUMsS0FBS08sS0FBTCxDQUFXdUQsVUFBWCxHQUF3QkEsVUFBeEIsQyIsImZpbGUiOiIvcGFja2FnZXMvb2hpZl9jb3JlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbi8qXG4gKiBEZWZpbmVzIHRoZSBiYXNlIE9ISUYgb2JqZWN0XG4gKi9cblxuY29uc3QgT0hJRiA9IHtcbiAgICBsb2c6IHt9LFxuICAgIHVpOiB7fSxcbiAgICB1dGlsczoge30sXG4gICAgdmlld2VyOiB7fSxcbiAgICBjb3JuZXJzdG9uZToge31cbn07XG5cbi8vIEV4cG9zZSB0aGUgT0hJRiBvYmplY3QgdG8gdGhlIGNsaWVudCBpZiBpdCBpcyBvbiBkZXZlbG9wbWVudCBtb2RlXG4vLyBAVE9ETzogcmVtb3ZlIHRoaXMgYWZ0ZXIgYXBwbHlpbmcgbmFtZXNwYWNlIHRvIHRoaXMgcGFja2FnZVxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICAgIHdpbmRvdy5PSElGID0gT0hJRjtcbn1cblxuZXhwb3J0IHsgT0hJRiB9O1xuIiwiaW1wb3J0ICcuL21vbmdvLmpzJztcbiIsImltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG4vLyBNb25nbyBkYXRhIG1hbmlwdWxhdGlvbiB1dGlsaXRpZXNcbmNsYXNzIE1vbmdvVXRpbHMge1xuXG4gICAgLy8gQ2hlY2sgaWYgdGhlcmUgaXMgYW4gdXNlciBsb2dnZWQgaW5cbiAgICBzdGF0aWMgdmFsaWRhdGVVc2VyKCkge1xuICAgICAgICAvLyBUaHJvdyBlcnJvciBpZiB0aGVyZSBpcyBubyB1c2VyIGxvZ2dlZCBpblxuICAgICAgICBpZiAoIU1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIEdlbmVyaWMgY2FsbGJhY2sgdG8gTW9uZ29EQiB3cml0ZSBvcGVyYXRpb25zXG4gICAgc3RhdGljIHdyaXRlQ2FsbGJhY2soZXJyb3IsIGFmZmVjdGVkKSB7XG4gICAgICAgIC8vIFRocm93IGVycm9yIGlmIGl0IHdhcyBub3QgcG9zc2libGUgdG8gY29tcGxldGUgdGhlIHdyaXRlIG9wZXJhdGlvblxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2RhdGEtd3JpdGUnLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbn1cblxuLy8gRXhwb3NlIHRoZSBjbGFzcyBpbiB0aGUgT0hJRiBvYmplY3Rcbk9ISUYuTW9uZ29VdGlscyA9IE1vbmdvVXRpbHM7XG4iLCJpbXBvcnQgJy4vbGliJztcbmltcG9ydCAnLi91dGlscyc7XG5cbmltcG9ydCAnLi9zY2hlbWEuanMnO1xuIiwiaW1wb3J0IHsgU2ltcGxlU2NoZW1hIH0gZnJvbSAnbWV0ZW9yL2FsZGVlZDpzaW1wbGUtc2NoZW1hJztcblxuLypcbiBFeHRlbmQgdGhlIGF2YWlsYWJsZSBvcHRpb25zIG9uIHNjaGVtYSBkZWZpbml0aW9uczpcblxuICAqIHZhbHVlc0xhYmVsczogVXNlZCBpbiBjb25qdW5jdGlvbiB3aXRoIGFsbG93ZWRWYWx1ZXMgdG8gZGVmaW5lIHRoZSB0ZXh0XG4gICAgbGFiZWwgZm9yIGVhY2ggdmFsdWUgKHVzZWQgb24gZm9ybXMpXG5cbiAgKiB0ZXh0T3B0aW9uYWw6IFVzZWQgdG8gYWxsb3cgZW1wdHkgc3RyaW5nc1xuXG4gKi9cblNpbXBsZVNjaGVtYS5leHRlbmRPcHRpb25zKHtcbiAgICB2YWx1ZXNMYWJlbHM6IE1hdGNoLk9wdGlvbmFsKFtTdHJpbmddKSxcbiAgICB0ZXh0T3B0aW9uYWw6IE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pXG59KTtcblxuLy8gQWRkIGRlZmF1bHQgcmVxdWlyZWQgdmFsaWRhdGlvbiBmb3IgZW1wdHkgc3RyaW5ncyB3aGljaCBjYW4gYmUgYnlwYXNzZWRcbi8vIHVzaW5nIHRleHRPcHRpb25hbD10cnVlIGRlZmluaXRpb25cblNpbXBsZVNjaGVtYS5hZGRWYWxpZGF0b3IoZnVuY3Rpb24oKSB7XG4gICAgaWYgKFxuICAgICAgICB0aGlzLmRlZmluaXRpb24ub3B0aW9uYWwgIT09IHRydWUgJiZcbiAgICAgICAgdGhpcy5kZWZpbml0aW9uLnRleHRPcHRpb25hbCAhPT0gdHJ1ZSAmJlxuICAgICAgICB0aGlzLnZhbHVlID09PSAnJ1xuICAgICkge1xuICAgICAgICByZXR1cm4gJ3JlcXVpcmVkJztcbiAgICB9XG59KTtcblxuLy8gSW5jbHVkaW5nIFtsYWJlbF0gZm9yIHNvbWUgbWVzc2FnZXNcblNpbXBsZVNjaGVtYS5tZXNzYWdlcyh7XG4gICAgbWF4Q291bnQ6ICdbbGFiZWxdIGNhbiBub3QgaGF2ZSBtb3JlIHRoYW4gW21heENvdW50XSB2YWx1ZXMnLFxuICAgIG1pbkNvdW50OiAnW2xhYmVsXSBtdXN0IGhhdmUgYXQgbGVhc3QgW21pbkNvdW50XSB2YWx1ZXMnLFxuICAgIG5vdEFsbG93ZWQ6ICdbbGFiZWxdIGhhcyBhbiBpbnZhbGlkIHZhbHVlOiBcIlt2YWx1ZV1cIidcbn0pO1xuIiwiaW1wb3J0ICcuL29iamVjdC5qcyc7XG4iLCJpbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG5cbk9ISUYub2JqZWN0ID0ge307XG5cbi8vIFRyYW5zZm9ybXMgYSBzaGFsbG93IG9iamVjdCB3aXRoIGtleXMgc2VwYXJhdGVkIGJ5IFwiLlwiIGludG8gYSBuZXN0ZWQgb2JqZWN0XG5PSElGLm9iamVjdC5nZXROZXN0ZWRPYmplY3QgPSBzaGFsbG93T2JqZWN0ID0+IHtcbiAgICBjb25zdCBuZXN0ZWRPYmplY3QgPSB7fTtcbiAgICBmb3IgKGxldCBrZXkgaW4gc2hhbGxvd09iamVjdCkge1xuICAgICAgICBpZiAoIXNoYWxsb3dPYmplY3QuaGFzT3duUHJvcGVydHkoa2V5KSkgY29udGludWU7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gc2hhbGxvd09iamVjdFtrZXldO1xuICAgICAgICBjb25zdCBwcm9wZXJ0eUFycmF5ID0ga2V5LnNwbGl0KCcuJyk7XG4gICAgICAgIGxldCBjdXJyZW50T2JqZWN0ID0gbmVzdGVkT2JqZWN0O1xuICAgICAgICB3aGlsZSAocHJvcGVydHlBcnJheS5sZW5ndGgpIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRQcm9wZXJ0eSA9IHByb3BlcnR5QXJyYXkuc2hpZnQoKTtcbiAgICAgICAgICAgIGlmICghcHJvcGVydHlBcnJheS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICBjdXJyZW50T2JqZWN0W2N1cnJlbnRQcm9wZXJ0eV0gPSB2YWx1ZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKCFjdXJyZW50T2JqZWN0W2N1cnJlbnRQcm9wZXJ0eV0pIHtcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudE9iamVjdFtjdXJyZW50UHJvcGVydHldID0ge307XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgY3VycmVudE9iamVjdCA9IGN1cnJlbnRPYmplY3RbY3VycmVudFByb3BlcnR5XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXN0ZWRPYmplY3Q7XG59O1xuXG4vLyBUcmFuc2Zvcm1zIGEgbmVzdGVkIG9iamVjdCBpbnRvIGEgc2hhbGxvd09iamVjdCBtZXJnaW5nIGl0cyBrZXlzIHdpdGggXCIuXCIgY2hhcmFjdGVyXG5PSElGLm9iamVjdC5nZXRTaGFsbG93T2JqZWN0ID0gbmVzdGVkT2JqZWN0ID0+IHtcbiAgICBjb25zdCBzaGFsbG93T2JqZWN0ID0ge307XG4gICAgY29uc3QgcHV0VmFsdWVzID0gKGJhc2VLZXksIG5lc3RlZE9iamVjdCwgcmVzdWx0T2JqZWN0KSA9PiB7XG4gICAgICAgIGZvciAobGV0IGtleSBpbiBuZXN0ZWRPYmplY3QpIHtcbiAgICAgICAgICAgIGlmICghbmVzdGVkT2JqZWN0Lmhhc093blByb3BlcnR5KGtleSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgbGV0IGN1cnJlbnRLZXkgPSBiYXNlS2V5ID8gYCR7YmFzZUtleX0uJHtrZXl9YCA6IGtleTtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRWYWx1ZSA9IG5lc3RlZE9iamVjdFtrZXldO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBjdXJyZW50VmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRWYWx1ZSBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRLZXkgKz0gJ1tdJztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBwdXRWYWx1ZXMoY3VycmVudEtleSwgY3VycmVudFZhbHVlLCByZXN1bHRPYmplY3QpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXN1bHRPYmplY3RbY3VycmVudEtleV0gPSBjdXJyZW50VmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcHV0VmFsdWVzKCcnLCBuZXN0ZWRPYmplY3QsIHNoYWxsb3dPYmplY3QpO1xuICAgIHJldHVybiBzaGFsbG93T2JqZWN0O1xufTtcbiIsImltcG9ydCB7IE9ISUYgfSBmcm9tICdtZXRlb3Ivb2hpZjpjb3JlJztcblxuLy8gUmV0dXJuIGFuIGFic29sdXRlIFVSTCB3aXRoIHRoZSBwYWdlIGRvbWFpbiB1c2luZyBzdWIgcGF0aCBvZiBST09UX1VSTFxuLy8gdG8gbGV0IG11bHRpcGxlIGRvbWFpbnMgZGlyZWN0ZWQgdG8gdGhlIHNhbWUgc2VydmVyIHdvcmtcbk9ISUYudXRpbHMuYWJzb2x1dGVVcmwgPSBmdW5jdGlvbihwYXRoKSB7XG4gICAgbGV0IGFic29sdXRlUGF0aCA9ICcvJztcblxuICAgIGNvbnN0IGFic29sdXRlVXJsID0gTWV0ZW9yLmFic29sdXRlVXJsKCk7XG4gICAgY29uc3QgYWJzb2x1dGVVcmxQYXJ0cyA9IGFic29sdXRlVXJsLnNwbGl0KCcvJyk7XG5cbiAgICBpZiAoYWJzb2x1dGVVcmxQYXJ0cy5sZW5ndGggPiA0KSB7XG4gICAgICAgIGNvbnN0IHJvb3RVcmxQcmVmaXhJbmRleCA9IGFic29sdXRlVXJsLmluZGV4T2YoYWJzb2x1dGVVcmxQYXJ0c1szXSk7XG4gICAgICAgIGFic29sdXRlUGF0aCArPSBhYnNvbHV0ZVVybC5zdWJzdHJpbmcocm9vdFVybFByZWZpeEluZGV4KSArIHBhdGg7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgYWJzb2x1dGVQYXRoICs9IHBhdGg7XG4gICAgfVxuXG4gICAgcmV0dXJuIGFic29sdXRlUGF0aC5yZXBsYWNlKC9cXC9cXC8rL2csICcvJyk7XG59OyIsImltcG9ydCAnLi9hYnNvbHV0ZVVybCc7XG5pbXBvcnQgJy4vb2JqZWN0UGF0aCc7XG4iLCJpbXBvcnQgeyBPSElGIH0gZnJvbSAnbWV0ZW9yL29oaWY6Y29yZSc7XG5cbmNsYXNzIE9iamVjdFBhdGgge1xuXG4gICAgLyoqXG4gICAgICogU2V0IGFuIG9iamVjdCBwcm9wZXJ0eSBiYXNlZCBvbiBcInBhdGhcIiAobmFtZXNwYWNlKSBzdXBwbGllZCBjcmVhdGluZ1xuICAgICAqIC4uLiBpbnRlcm1lZGlhcnkgb2JqZWN0cyBpZiB0aGV5IGRvIG5vdCBleGlzdC5cbiAgICAgKiBAcGFyYW0gb2JqZWN0IHtPYmplY3R9IEFuIG9iamVjdCB3aGVyZSB0aGUgcHJvcGVydGllcyBzcGVjaWZpZWQgb24gcGF0aCBzaG91bGQgYmUgc2V0LlxuICAgICAqIEBwYXJhbSBwYXRoIHtTdHJpbmd9IEEgc3RyaW5nIHJlcHJlc2VudGluZyB0aGUgcHJvcGVydHkgdG8gYmUgc2V0LCBlLmcuIFwidXNlci5zdHVkeS5zZXJpZXMudGltZXBvaW50XCIuXG4gICAgICogQHBhcmFtIHZhbHVlIHtBbnl9IFRoZSB2YWx1ZSBvZiB0aGUgcHJvcGVydHkgdGhhdCB3aWxsIGJlIHNldC5cbiAgICAgKiBAcmV0dXJuIHtCb29sZWFufSBSZXR1cm5zIFwidHJ1ZVwiIG9uIHN1Y2Nlc3MsIFwiZmFsc2VcIiBpZiBhbnkgaW50ZXJtZWRpYXRlIGNvbXBvbmVudCBvZiB0aGUgc3VwcGxpZWQgcGF0aFxuICAgICAqIC4uLiBpcyBub3QgYSB2YWxpZCBPYmplY3QsIGluIHdoaWNoIGNhc2UgdGhlIHByb3BlcnR5IGNhbm5vdCBiZSBzZXQuIE5vIGV4Y3BldGlvbnMgYXJlIHRocm93bi5cbiAgICAgKi9cbiAgICBzdGF0aWMgc2V0KG9iamVjdCwgcGF0aCwgdmFsdWUpIHtcblxuICAgICAgICBsZXQgY29tcG9uZW50cyA9IE9iamVjdFBhdGguZ2V0UGF0aENvbXBvbmVudHMocGF0aCksXG4gICAgICAgICAgICBsZW5ndGggPSBjb21wb25lbnRzICE9PSBudWxsID8gY29tcG9uZW50cy5sZW5ndGggOiAwLFxuICAgICAgICAgICAgcmVzdWx0ID0gZmFsc2U7XG5cbiAgICAgICAgaWYgKGxlbmd0aCA+IDAgJiYgT2JqZWN0UGF0aC5pc1ZhbGlkT2JqZWN0KG9iamVjdCkpIHtcblxuICAgICAgICAgICAgbGV0IGkgPSAwLFxuICAgICAgICAgICAgICAgIGxhc3QgPSBsZW5ndGggLSAxLFxuICAgICAgICAgICAgICAgIGN1cnJlbnRPYmplY3QgPSBvYmplY3Q7XG5cbiAgICAgICAgICAgIHdoaWxlIChpIDwgbGFzdCkge1xuXG4gICAgICAgICAgICAgICAgbGV0IGZpZWxkID0gY29tcG9uZW50c1tpXTtcblxuICAgICAgICAgICAgICAgIGlmIChmaWVsZCBpbiBjdXJyZW50T2JqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghT2JqZWN0UGF0aC5pc1ZhbGlkT2JqZWN0KGN1cnJlbnRPYmplY3RbZmllbGRdKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBjdXJyZW50T2JqZWN0W2ZpZWxkXSA9IHt9O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGN1cnJlbnRPYmplY3QgPSBjdXJyZW50T2JqZWN0W2ZpZWxkXTtcbiAgICAgICAgICAgICAgICBpKys7XG5cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGkgPT09IGxhc3QpIHtcbiAgICAgICAgICAgICAgICBjdXJyZW50T2JqZWN0W2NvbXBvbmVudHNbbGFzdF1dID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcblxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBhbiBvYmplY3QgcHJvcGVydHkgYmFzZWQgb24gXCJwYXRoXCIgKG5hbWVzcGFjZSkgc3VwcGxpZWQgdHJhdmVyc2luZyB0aGUgb2JqZWN0XG4gICAgICogLi4uIHRyZWUgYXMgbmVjZXNzYXJ5LlxuICAgICAqIEBwYXJhbSBvYmplY3Qge09iamVjdH0gQW4gb2JqZWN0IHdoZXJlIHRoZSBwcm9wZXJ0aWVzIHNwZWNpZmllZCBtaWdodCBleGlzdC5cbiAgICAgKiBAcGFyYW0gcGF0aCB7U3RyaW5nfSBBIHN0cmluZyByZXByZXNlbnRpbmcgdGhlIHByb3BlcnR5IHRvIGJlIHNlYXJjaGVkIGZvciwgZS5nLiBcInVzZXIuc3R1ZHkuc2VyaWVzLnRpbWVwb2ludFwiLlxuICAgICAqIEByZXR1cm4ge0FueX0gVGhlIHZhbHVlIG9mIHRoZSBwcm9wZXJ0eSBpZiBmb3VuZC4gQnkgZGVmYXVsdCwgcmV0dXJucyB0aGUgc3BlY2lhbCB0eXBlIFwidW5kZWZpbmVkXCIuXG4gICAgICovXG4gICAgc3RhdGljIGdldChvYmplY3QsIHBhdGgpIHtcblxuICAgICAgICBsZXQgZm91bmQsIC8vIHVuZGVmaW5lZCBieSBkZWZhdWx0XG4gICAgICAgICAgICBjb21wb25lbnRzID0gT2JqZWN0UGF0aC5nZXRQYXRoQ29tcG9uZW50cyhwYXRoKSxcbiAgICAgICAgICAgIGxlbmd0aCA9IGNvbXBvbmVudHMgIT09IG51bGwgPyBjb21wb25lbnRzLmxlbmd0aCA6IDA7XG5cbiAgICAgICAgaWYgKGxlbmd0aCA+IDAgJiYgT2JqZWN0UGF0aC5pc1ZhbGlkT2JqZWN0KG9iamVjdCkpIHtcblxuICAgICAgICAgICAgbGV0IGkgPSAwLFxuICAgICAgICAgICAgICAgIGxhc3QgPSBsZW5ndGggLSAxLFxuICAgICAgICAgICAgICAgIGN1cnJlbnRPYmplY3QgPSBvYmplY3Q7XG5cbiAgICAgICAgICAgIHdoaWxlIChpIDwgbGFzdCkge1xuXG4gICAgICAgICAgICAgICAgbGV0IGZpZWxkID0gY29tcG9uZW50c1tpXTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IGlzVmFsaWQgPSBPYmplY3RQYXRoLmlzVmFsaWRPYmplY3QoY3VycmVudE9iamVjdFtmaWVsZF0pO1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZCBpbiBjdXJyZW50T2JqZWN0ICYmIGlzVmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudE9iamVjdCA9IGN1cnJlbnRPYmplY3RbZmllbGRdO1xuICAgICAgICAgICAgICAgICAgICBpKys7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChpID09PSBsYXN0ICYmIGNvbXBvbmVudHNbbGFzdF0gaW4gY3VycmVudE9iamVjdCkge1xuICAgICAgICAgICAgICAgIGZvdW5kID0gY3VycmVudE9iamVjdFtjb21wb25lbnRzW2xhc3RdXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGZvdW5kO1xuXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdGhlIHN1cHBsaWVkIGFyZ3VtZW50IGlzIGEgcmVhbCBKYXZhU2NyaXB0IE9iamVjdCBpbnN0YW5jZS5cbiAgICAgKiBAcGFyYW0gb2JqZWN0IHtBbnl9IFRoZSBzdWJqZWN0IHRvIGJlIHRlc3RlZC5cbiAgICAgKiBAcmV0dXJuIHtCb29sZWFufSBSZXR1cm5zIFwidHJ1ZVwiIGlmIHRoZSBvYmplY3QgaXMgYSByZWFsIE9iamVjdCBpbnN0YW5jZSBhbmQgXCJmYWxzZVwiIG90aGVyd2lzZS5cbiAgICAgKi9cbiAgICBzdGF0aWMgaXNWYWxpZE9iamVjdChvYmplY3QpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIHR5cGVvZiBvYmplY3QgPT09ICdvYmplY3QnICYmXG4gICAgICAgICAgICBvYmplY3QgIT09IG51bGwgJiZcbiAgICAgICAgICAgIG9iamVjdCBpbnN0YW5jZW9mIE9iamVjdFxuICAgICAgICApO1xuICAgIH1cblxuICAgIHN0YXRpYyBnZXRQYXRoQ29tcG9uZW50cyhwYXRoKSB7XG4gICAgICAgIHJldHVybiAodHlwZW9mIHBhdGggPT09ICdzdHJpbmcnID8gcGF0aC5zcGxpdCgnLicpIDogbnVsbCk7XG4gICAgfVxuXG59XG5cbk9ISUYudXRpbHMuT2JqZWN0UGF0aCA9IE9iamVjdFBhdGg7XG4iXX0=
