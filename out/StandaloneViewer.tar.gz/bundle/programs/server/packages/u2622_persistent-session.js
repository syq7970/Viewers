(function () {



/* Exports */
Package._define("u2622:persistent-session");

})();
